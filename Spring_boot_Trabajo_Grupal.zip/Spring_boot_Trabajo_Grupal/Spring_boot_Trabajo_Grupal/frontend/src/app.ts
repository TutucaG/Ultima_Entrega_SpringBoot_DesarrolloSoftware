import type {
    ArcaEstadoDTO,
    ArticuloPrecioDTO,
    CatalogoDTO,
    ClienteExplorerDTO,
    FacturaCompletaDTO,
    FacturaDetalleRequestDTO,
    FacturaFiltrosDTO,
    FacturaReporteDTO,
    FacturaRequestDTO,
    ItemCatalogoDTO,
} from './models/factura.dto.js';
import { FacturaService } from './services/FacturaService.js';
import { CatalogoService } from './services/CatalogoService.js';
import { ApiError } from './services/ApiError.js';
import { ArcaService } from './services/ArcaService.js';

// =====================================================================
// Estado en memoria
// =====================================================================

/** Renglon cargado en el modal de alta/edicion (todavia no enviado al backend). */
interface ItemEnMemoria {
    articuloId: number;
    codigo: string;
    descripcion: string;
    precioUnitario: number;   // precio con el que se cargo; NO cambia solo al cambiar de lista
    cantidad: number;
    porcentajeBonificacion: number;
}

/** Como esta un renglon respecto de la lista de precios elegida. */
type EstadoItem = 'ok' | 'fuera' | 'desactualizado' | 'verificando';

interface ImportesItem {
    neto: number;
    iva: number;
    subtotal: number;
}

/** Cliente elegido con el explorer (null = Consumidor Final en el alta / "Todos" en el filtro). */
interface ClienteElegido {
    id: number;                    // 0 = Consumidor Final (sin cliente)
    texto: string;
    condicionIvaId: number | null; // condicion propia del cliente
}

const facturaService = new FacturaService();
const catalogoService = new CatalogoService();
const arcaService = new ArcaService();

// Limites (los mismos que valida FacturaService.java)
const CANTIDAD_MAXIMA = 99_999;
const DIAS_TOLERANCIA_FECHA_ARCA = 5; // igual que ArcaService.DIAS_TOLERANCIA_FECHA
const LARGO_MAXIMO_TEXTO = 255;
const CODIGO_RESPONSABLE_INSCRIPTO = '1';
const CODIGO_CONSUMIDOR_FINAL = '5';

let catalogo: CatalogoDTO | null = null;
let facturas: FacturaReporteDTO[] = [];          // filas de la grilla
let seleccionadaId: number | null = null;        // fila seleccionada en el explorer
let filtrosActuales: FacturaFiltrosDTO = {};
let estadoArca: ArcaEstadoDTO | null = null;
let ocupado = false;                             // hay una accion en curso: evita dobles envios

// ---- modal de alta / edicion ----
let items: ItemEnMemoria[] = [];
type CampoItem = 'cantidad' | 'porcentajeBonificacion';
/** Cantidades/bonificaciones editadas en la grilla con un valor invalido: se guarda lo que se tipeo
 *  por renglon (no por posicion), asi sigue a la vista aunque se agreguen o quiten otros renglones.
 *  Mientras haya alguno, no se puede guardar. */
const camposInvalidos = new Map<ItemEnMemoria, Map<CampoItem, string>>();
let idEnEdicion: number | null = null;           // null = alta, numero = edicion de un borrador
let clienteAlta: ClienteElegido | null = null;
let articuloElegido: ArticuloPrecioDTO | null = null; // articulo de la lista, antes de "Agregar item"
let preciosLista: Map<number, number> | null = null;  // articuloId -> precio en la lista elegida
let consultaPrecios = 0;                         // descarta respuestas de una lista elegida antes
let estadoInicialAlta = '';                      // para avisar si se cierra con cambios sin guardar

// ---- filtros ----
let clienteFiltro: ClienteElegido | null = null;

// =====================================================================
// Utilidades
// =====================================================================

function elemento<T extends HTMLElement>(id: string): T {
    const el = document.getElementById(id);
    if (!el) {
        throw new Error(`No existe el elemento #${id} en index.html`);
    }
    return el as T;
}

const formatoMoneda = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' });
const formatoNumero = new Intl.NumberFormat('es-AR', { maximumFractionDigits: 2 });
const moneda = (valor: number): string => formatoMoneda.format(valor);
const redondear = (valor: number): number => Math.round(valor * 100) / 100;

/** "2026-05-10" -> "10/05/2026" */
function fechaLegible(iso: string | null): string {
    if (!iso) {
        return '';
    }
    const [anio, mes, dia] = iso.split('-');
    return `${dia}/${mes}/${anio}`;
}

/** Fecha local de hoy en formato yyyy-MM-dd (para el input date). */
function hoyIso(): string {
    const hoy = new Date();
    const mes = String(hoy.getMonth() + 1).padStart(2, '0');
    const dia = String(hoy.getDate()).padStart(2, '0');
    return `${hoy.getFullYear()}-${mes}-${dia}`;
}

/** Mismo margen que controla ARCA: la fecha de emision puede estar hasta 5 dias antes o despues de hoy. */
const DIAS_TOLERANCIA_ARCA = 5;

/** Corre una fecha yyyy-MM-dd n dias (calculo en hora local, sin problemas de zona horaria). */
function sumarDias(iso: string, dias: number): string {
    const [anio, mes, dia] = iso.split('-').map(Number);
    const fecha = new Date(anio, mes - 1, dia + dias);
    return `${fecha.getFullYear()}-${String(fecha.getMonth() + 1).padStart(2, '0')}-${String(fecha.getDate()).padStart(2, '0')}`;
}

/** Aviso (no bloquea el guardado): con esa fecha ARCA va a rechazar el borrador al autorizarlo. */
function actualizarAvisoFecha(): void {
    const aviso = elemento('aviso-fecha');
    const fecha = elemento<HTMLInputElement>('alta-fecha').value;
    const desde = sumarDias(hoyIso(), -DIAS_TOLERANCIA_ARCA);
    const hasta = sumarDias(hoyIso(), DIAS_TOLERANCIA_ARCA);
    const fuera = /^\d{4}-\d{2}-\d{2}$/.test(fecha) && (fecha < desde || fecha > hasta);
    aviso.hidden = !fuera;
    aviso.textContent = fuera
        ? `ARCA solo acepta fechas entre el ${fechaLegible(desde)} y el ${fechaLegible(hasta)} `
          + `(${DIAS_TOLERANCIA_ARCA} días antes o después de hoy). Podés guardar el borrador, `
          + 'pero para autorizarlo vas a tener que cambiar la fecha.'
        : '';
}

function tieneHastaDosDecimales(valor: number): boolean {
    return Math.abs(valor * 100 - Math.round(valor * 100)) < 1e-6;
}

/** 0001-00001009 (formato de ARCA). */
function numeroComprobante(puntoVenta: number, numero: number): string {
    return `${String(puntoVenta).padStart(4, '0')}-${String(numero).padStart(8, '0')}`;
}

interface DatosComprobante {
    letra: string;
    puntoVentaNumero: number;
    numeroFactura: number | null;
    cae: string | null;
}

/** Solo es una factura valida si ARCA la autorizo (tiene CAE). */
function esFacturaValida(f: DatosComprobante): boolean {
    return !!f.cae;
}

/** "Factura A 0001-00000003", "Borrador" o "Comprobante sin CAE (0001-...)". */
function nombreComprobante(f: DatosComprobante): string {
    if (esFacturaValida(f) && f.numeroFactura !== null) {
        return `Factura ${f.letra} ${numeroComprobante(f.puntoVentaNumero, f.numeroFactura)}`;
    }
    return f.numeroFactura === null
        ? 'Borrador'
        : `Comprobante sin CAE (${numeroComprobante(f.puntoVentaNumero, f.numeroFactura)})`;
}

function celda(texto: string, clase?: string): HTMLTableCellElement {
    const td = document.createElement('td');
    td.textContent = texto; // textContent: evita inyectar HTML con datos de la base
    if (clase) {
        td.className = clase;
    }
    return td;
}

/** Celda del comprobante: el numero "0001-00000003" nunca se parte en dos lineas. */
function celdaComprobante(f: DatosComprobante): HTMLTableCellElement {
    const texto = nombreComprobante(f);
    const td = celda('', esFacturaValida(f) ? 'mono' : 'sin-numero');
    const partes = /^(.*?)(\d{4}-\d{8})(\)?)$/.exec(texto);
    if (!partes) {
        td.textContent = texto;
        return td;
    }
    const numero = document.createElement('span');
    numero.className = 'sin-corte';
    numero.textContent = partes[2];
    td.append(partes[1], numero, partes[3]);
    return td;
}

function boton(texto: string, clase: string, datos: Record<string, string>): HTMLButtonElement {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `btn btn-chico ${clase}`;
    btn.textContent = texto;
    Object.entries(datos).forEach(([clave, valor]) => (btn.dataset[clave] = valor));
    return btn;
}

function insignia(estado: string, texto = estado, clase = `estado-${estado}`): HTMLSpanElement {
    const span = document.createElement('span');
    span.className = `estado ${clase}`;
    span.textContent = texto;
    return span;
}

/** Importes de un renglon con la misma formula que FacturaService.java (vista previa). */
function calcularImportes(item: ItemEnMemoria): ImportesItem {
    const alicuota = catalogo?.alicuotaIva ?? 21;
    const bruto = item.cantidad * item.precioUnitario;
    const neto = redondear(bruto - (bruto * item.porcentajeBonificacion) / 100);
    const iva = redondear((neto * alicuota) / 100);
    return { neto, iva, subtotal: redondear(neto + iva) };
}

// =====================================================================
// Mensajes, modales y dialogo de confirmacion
// =====================================================================

let temporizadorMensaje: number | undefined;

function mostrarMensaje(texto: string, tipo: 'ok' | 'error' | 'info' = 'ok'): void {
    const caja = elemento<HTMLDivElement>('mensaje');
    caja.textContent = texto;
    caja.className = `mensaje ${tipo}`;
    // popover "manual": se dibuja por encima de los modales abiertos
    if (caja.matches(':popover-open')) {
        caja.hidePopover();
    }
    caja.showPopover();
    window.clearTimeout(temporizadorMensaje);
    temporizadorMensaje = window.setTimeout(() => caja.hidePopover(), tipo === 'error' ? 8000 : 5000);
}

function describirError(error: unknown): string {
    if (error instanceof ApiError) {
        return `${error.message} (HTTP ${error.status})`;
    }
    if (error instanceof TypeError) {
        // fetch lanza TypeError cuando no hay conexion con el servidor
        return 'No se pudo conectar con la API. ¿Está corriendo Spring Boot en http://localhost:8080?';
    }
    return error instanceof Error ? error.message : String(error);
}

function abrirModal(id: string): void {
    const modal = elemento<HTMLDialogElement>(id);
    if (!modal.open) {
        modal.showModal();
    }
}

function cerrarModal(id: string): void {
    const modal = elemento<HTMLDialogElement>(id);
    if (modal.open) {
        modal.close();
    }
}

interface OpcionesDialogo {
    titulo: string;
    mensaje: string;
    textoConfirmar: string;
    pedirMotivo?: boolean;
}

/** Abre el dialogo de confirmacion y resuelve cuando el usuario confirma o cancela. */
function confirmar(opciones: OpcionesDialogo): Promise<{ confirmado: boolean; motivo: string }> {
    const dialogo = elemento<HTMLDialogElement>('dialogo');
    const motivo = elemento<HTMLTextAreaElement>('dialogo-motivo');
    if (dialogo.open) {
        return Promise.resolve({ confirmado: false, motivo: '' }); // ya hay una confirmacion abierta
    }

    elemento('dialogo-titulo').textContent = opciones.titulo;
    elemento('dialogo-mensaje').textContent = opciones.mensaje;
    elemento('dialogo-motivo-label').hidden = !opciones.pedirMotivo;
    elemento('dialogo-confirmar').textContent = opciones.textoConfirmar;
    motivo.value = '';

    // Se escuchan los botones (y Esc) directamente en vez del evento "close",
    // que no todos los navegadores disparan de forma confiable.
    return new Promise((resolver) => {
        const terminar = (confirmado: boolean): void => {
            dialogo.removeEventListener('click', alClick);
            dialogo.removeEventListener('cancel', alCancelar);
            if (dialogo.open) {
                dialogo.close();
            }
            resolver({ confirmado, motivo: motivo.value.trim() });
        };
        const alClick = (evento: MouseEvent): void => {
            const btn = (evento.target as HTMLElement).closest<HTMLButtonElement>('button[value]');
            if (btn) {
                terminar(btn.value === 'confirmar');
            }
        };
        const alCancelar = (evento: Event): void => {
            evento.preventDefault();
            terminar(false);
        };
        dialogo.addEventListener('click', alClick);
        dialogo.addEventListener('cancel', alCancelar);
        dialogo.showModal();
        if (opciones.pedirMotivo) {
            motivo.focus();
        }
    });
}

/** Ejecuta una accion de la barra de a una por vez (evita dobles clics y envios repetidos). */
async function conBloqueo(accion: () => Promise<void>): Promise<void> {
    if (ocupado) {
        return;
    }
    ocupado = true;
    actualizarBarra();
    try {
        await accion();
    } finally {
        ocupado = false;
        actualizarBarra();
    }
}

// =====================================================================
// Catalogo (combos de filtros y del formulario)
// =====================================================================

function llenarSelect(select: HTMLSelectElement, opciones: ItemCatalogoDTO[],
                      opcionesIniciales: Array<[string, string]> = []): void {
    select.replaceChildren();
    for (const [texto, valor] of opcionesIniciales) {
        select.append(new Option(texto, valor));
    }
    for (const op of opciones) {
        select.append(new Option(op.descripcion, String(op.id)));
    }
}

async function cargarCatalogo(): Promise<void> {
    catalogo = await catalogoService.obtenerCatalogo();
    // filtros
    llenarSelect(elemento('filtro-punto-venta'), catalogo.puntosVenta, [['Todos', '']]);
    // modal de alta (cliente y articulo NO son combos: se eligen con el explorer)
    llenarSelect(elemento('alta-punto-venta'), catalogo.puntosVenta);
    llenarSelect(elemento('alta-condicion-iva'), catalogo.condicionesIva);
    llenarSelect(elemento('alta-tipo-moneda'), catalogo.tiposMoneda);
    llenarSelect(elemento('alta-lista-precio'), catalogo.listasPrecio);
    elemento('alicuota-iva').textContent = String(catalogo.alicuotaIva);
}

function idCondicion(codigo: string): number | null {
    return catalogo?.condicionesIva.find((c) => c.codigo === codigo)?.id ?? null;
}

function codigoCondicion(id: number): string | null {
    return catalogo?.condicionesIva.find((c) => c.id === id)?.codigo ?? null;
}

/**
 * La condicion de IVA no se elige a mano: es la del cliente, o Consumidor Final si no hay cliente.
 * Solo queda editable si el cliente no tiene la condicion cargada.
 */
function aplicarCondicionIva(): void {
    const select = elemento<HTMLSelectElement>('alta-condicion-iva');
    const id = clienteAlta === null ? idCondicion(CODIGO_CONSUMIDOR_FINAL) : clienteAlta.condicionIvaId;
    if (id !== null) {
        select.value = String(id);
    }
    select.disabled = id !== null;
    actualizarAyudaCondicion();
}

function actualizarAyudaCondicion(): void {
    const select = elemento<HTMLSelectElement>('alta-condicion-iva');
    const letra = codigoCondicion(Number(select.value)) === CODIGO_RESPONSABLE_INSCRIPTO ? 'A' : 'B';
    const origen = clienteAlta === null ? 'Sin cliente solo se factura a Consumidor Final'
        : select.disabled ? 'Tomada del cliente' : 'El cliente no tiene la condición cargada: elegila';
    elemento('ayuda-condicion').textContent = `${origen} · al autorizarse será Factura ${letra}`;
}

// =====================================================================
// Explorer de seleccion (clientes y articulos): grilla con buscador en un modal
// =====================================================================

interface ColumnaExplorer<T> {
    titulo: string;
    valor: (fila: T) => string;
    clase?: string;
}

interface OpcionesExplorer<T> {
    titulo: string;
    subtitulo: string;
    placeholder: string;
    columnas: ColumnaExplorer<T>[];
    buscar: (texto: string) => Promise<T[]>;
}

/** Abre el explorer y resuelve con la fila elegida (o null si se cancela). */
function abrirExplorer<T>(opciones: OpcionesExplorer<T>): Promise<T | null> {
    const dialogo = elemento<HTMLDialogElement>('modal-explorer');
    if (dialogo.open) {
        return Promise.resolve(null); // doble clic sobre "Buscar…": ya esta abierto
    }
    const busqueda = elemento<HTMLInputElement>('explorer-busqueda');
    const tabla = elemento<HTMLTableElement>('explorer-tabla');
    const cuerpo = elemento<HTMLTableSectionElement>('explorer-cuerpo');
    const estado = elemento('explorer-estado');
    const btnSeleccionar = elemento<HTMLButtonElement>('explorer-seleccionar');

    elemento('explorer-titulo').textContent = opciones.titulo;
    elemento('explorer-subtitulo').textContent = opciones.subtitulo;
    busqueda.placeholder = opciones.placeholder;
    busqueda.value = '';

    const cabecera = elemento<HTMLTableSectionElement>('explorer-cabecera');
    cabecera.replaceChildren();
    const filaCabecera = cabecera.insertRow();
    for (const col of opciones.columnas) {
        const th = document.createElement('th');
        th.textContent = col.titulo;
        if (col.clase) {
            th.className = col.clase;
        }
        filaCabecera.append(th);
    }

    let filas: T[] = [];
    let indice = -1;
    let consulta = 0; // descarta respuestas viejas si el usuario sigue escribiendo
    let temporizador: number | undefined;

    const marcar = (nuevo: number): void => {
        indice = nuevo;
        cuerpo.querySelectorAll<HTMLTableRowElement>('tr[data-indice]').forEach((tr) => {
            const activa = Number(tr.dataset.indice) === indice;
            tr.setAttribute('aria-selected', String(activa));
            if (activa) {
                tr.scrollIntoView({ block: 'nearest' });
            }
        });
        btnSeleccionar.disabled = indice < 0;
    };

    const render = (): void => {
        cuerpo.replaceChildren();
        if (filas.length === 0) {
            const td = celda('Sin resultados.', 'vacia');
            td.colSpan = opciones.columnas.length;
            cuerpo.insertRow().append(td);
        }
        filas.forEach((fila, i) => {
            const tr = cuerpo.insertRow();
            tr.dataset.id = String(i); // para el estilo de fila seleccionable
            tr.dataset.indice = String(i);
            for (const col of opciones.columnas) {
                tr.append(celda(col.valor(fila), col.clase));
            }
        });
        marcar(filas.length > 0 ? 0 : -1);
    };

    const buscar = async (): Promise<void> => {
        const numero = ++consulta;
        estado.textContent = 'Buscando…';
        try {
            const resultado = await opciones.buscar(busqueda.value.trim());
            if (numero !== consulta) {
                return;
            }
            filas = resultado;
            render();
            estado.textContent = `${filas.length} resultado(s)`;
        } catch (error) {
            if (numero === consulta) {
                filas = [];
                render();
                estado.textContent = describirError(error);
            }
        }
    };

    return new Promise((resolver) => {
        const control = new AbortController();
        const opcion = { signal: control.signal };

        const terminar = (fila: T | null): void => {
            control.abort(); // quita todos los listeners de esta apertura
            window.clearTimeout(temporizador);
            consulta++;
            if (dialogo.open) {
                dialogo.close();
            }
            resolver(fila);
        };
        const confirmarSeleccion = (): void => {
            if (indice >= 0) {
                terminar(filas[indice]);
            }
        };
        const mover = (paso: number): void => {
            if (filas.length > 0) {
                marcar(Math.min(Math.max(indice + paso, 0), filas.length - 1));
            }
        };
        const teclas = (e: KeyboardEvent): void => {
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                mover(e.key === 'ArrowDown' ? 1 : -1);
            } else if (e.key === 'Enter') {
                e.preventDefault();
                confirmarSeleccion();
            }
        };

        busqueda.addEventListener('input', () => {
            window.clearTimeout(temporizador);
            temporizador = window.setTimeout(() => void buscar(), 250);
        }, opcion);
        busqueda.addEventListener('keydown', teclas, opcion);
        tabla.addEventListener('keydown', teclas, opcion);
        cuerpo.addEventListener('click', (e) => {
            const tr = (e.target as HTMLElement).closest<HTMLTableRowElement>('tr[data-indice]');
            if (tr) {
                marcar(Number(tr.dataset.indice));
            }
        }, opcion);
        cuerpo.addEventListener('dblclick', (e) => {
            const tr = (e.target as HTMLElement).closest<HTMLTableRowElement>('tr[data-indice]');
            if (tr) {
                marcar(Number(tr.dataset.indice));
                confirmarSeleccion();
            }
        }, opcion);
        btnSeleccionar.addEventListener('click', confirmarSeleccion, opcion);
        dialogo.querySelectorAll('[data-explorer="cancelar"]').forEach((b) =>
            b.addEventListener('click', () => terminar(null), opcion));
        dialogo.addEventListener('cancel', (e) => {
            e.preventDefault();
            terminar(null);
        }, opcion);

        filas = [];
        render();
        dialogo.showModal();
        busqueda.focus();
        void buscar();
    });
}

const CONSUMIDOR_FINAL: ClienteExplorerDTO = {
    id: 0, cuitCuil: '—', denominacion: 'Consumidor Final (sin cliente)', domicilio: null, email: null,
    telefono: null, condicionIvaId: null, condicionIva: 'Consumidor Final',
};

/** Explorer de clientes. La primera fila "Consumidor Final" permite facturar sin cliente. */
function explorarClientes(titulo: string): Promise<ClienteExplorerDTO | null> {
    return abrirExplorer<ClienteExplorerDTO>({
        titulo,
        subtitulo: 'Buscá por razón social o CUIT. Doble clic o Enter para seleccionar.',
        placeholder: 'Ej. Empresa Tech o 30-12345678-1',
        columnas: [
            { titulo: 'CUIT / CUIL', valor: (c) => c.cuitCuil, clase: 'mono sin-corte' },
            { titulo: 'Razón social', valor: (c) => c.denominacion },
            { titulo: 'Condición IVA', valor: (c) => c.condicionIva ?? 'Sin cargar' },
            { titulo: 'Domicilio', valor: (c) => c.domicilio ?? '' },
            { titulo: 'Contacto', valor: (c) => [c.email, c.telefono].filter(Boolean).join(' · ') },
        ],
        buscar: async (texto) => {
            const clientes = await catalogoService.buscarClientes(texto);
            const incluirCf = texto === '' || 'consumidor final'.includes(texto.toLowerCase());
            return incluirCf ? [CONSUMIDOR_FINAL, ...clientes] : clientes;
        },
    });
}

function clienteElegido(c: ClienteExplorerDTO): ClienteElegido {
    return {
        id: c.id,
        texto: c.id === 0 ? 'Consumidor Final' : `${c.denominacion} (${c.cuitCuil})`,
        condicionIvaId: c.condicionIvaId,
    };
}

// =====================================================================
// Grilla principal con seleccion
// =====================================================================

async function cargarFacturas(): Promise<void> {
    const resumen = elemento('resumen-listado');
    try {
        facturas = await facturaService.obtenerFacturas(filtrosActuales);
        if (!facturas.some((f) => f.id === seleccionadaId)) {
            seleccionadaId = null; // la seleccionada ya no esta (borrada o filtrada)
        }
        renderFacturas();
        const validas = facturas.filter((f) => f.estado === 'EMITIDA' && esFacturaValida(f));
        const total = validas.reduce((suma, f) => suma + f.importeTotal, 0);
        const borradores = facturas.filter((f) => f.estado === 'BORRADOR').length;
        resumen.textContent = `${facturas.length} comprobante(s) · ${borradores} borrador(es) sin autorizar · `
            + `Total facturado (emitidas con CAE): ${moneda(total)}`;
    } catch (error) {
        facturas = [];
        seleccionadaId = null;
        renderFacturas();
        resumen.textContent = 'No se pudo cargar el listado.';
        mostrarMensaje(describirError(error), 'error');
    }
    actualizarLinksReporte();
}

function renderFacturas(): void {
    const cuerpo = elemento<HTMLTableSectionElement>('facturas-cuerpo');
    cuerpo.replaceChildren();

    if (facturas.length === 0) {
        const td = celda('No hay comprobantes que coincidan con los filtros.', 'vacia');
        td.colSpan = 8;
        cuerpo.insertRow().append(td);
    }

    for (const f of facturas) {
        const fila = cuerpo.insertRow();
        fila.dataset.id = String(f.id);
        fila.setAttribute('aria-selected', String(f.id === seleccionadaId));
        if (f.estado === 'ANULADA') {
            fila.classList.add('anulada');
        }

        fila.append(
            celdaComprobante(f),
            celda(fechaLegible(f.fechaEmision)),
            celda(f.clienteDenominacion),
            celda(f.condicionIva),
            celda(String(f.cantidadItems), 'num'),
            celda(moneda(f.importeTotal), 'num importe'),
        );
        const tdEstado = celda('');
        tdEstado.append(insignia(f.estado));
        if (f.estado === 'BORRADOR' && f.resultadoAfip === 'R') {
            tdEstado.append(' ', insignia('RECHAZADA', 'Rechazado por ARCA'));
        }
        if (f.estado !== 'BORRADOR' && !esFacturaValida(f)) {
            tdEstado.append(' ', insignia('RECHAZADA', 'Sin CAE'));
        }
        fila.append(tdEstado, celda(f.cae ?? '—', 'mono'));
    }
    actualizarBarra();
}

function facturaSeleccionada(): FacturaReporteDTO | undefined {
    return facturas.find((f) => f.id === seleccionadaId);
}

function seleccionar(id: number | null): void {
    seleccionadaId = id;
    for (const fila of elemento('facturas-cuerpo').querySelectorAll<HTMLTableRowElement>('tr[data-id]')) {
        const activa = Number(fila.dataset.id) === id;
        fila.setAttribute('aria-selected', String(activa));
        if (activa) {
            fila.scrollIntoView({ block: 'nearest' });
        }
    }
    actualizarBarra();
}

/** Habilita cada accion segun el estado del comprobante seleccionado. */
function actualizarBarra(): void {
    const f = facturaSeleccionada();
    const estado = f?.estado;
    const reglas: Record<string, boolean> = {
        'btn-ver': !!f,
        'btn-imprimir': !!f,
        'btn-editar': estado === 'BORRADOR',      // solo se edita lo que no tiene numero
        'btn-autorizar': estado === 'BORRADOR',   // ARCA asigna numero y CAE
        'btn-eliminar': estado === 'BORRADOR',    // sin numero -> se puede borrar
        'btn-anular': estado === 'EMITIDA',       // con numero -> solo se anula
    };
    for (const [id, habilitado] of Object.entries(reglas)) {
        elemento<HTMLButtonElement>(id).disabled = ocupado || !habilitado;
    }

    const info = elemento('info-seleccion');
    if (!f) {
        info.textContent = 'Seleccioná un comprobante de la grilla para habilitar las acciones.';
    } else if (f.estado === 'BORRADOR' && f.resultadoAfip === 'R') {
        info.textContent = 'ARCA rechazó el último envío de este borrador (el motivo está en "Ver"). '
            + 'Corregilo con "Editar" y volvé a autorizarlo, o eliminalo.';
    } else if (f.estado === 'BORRADOR') {
        info.textContent = 'Borrador sin número ni CAE: todavía no es una factura válida. Se puede editar, '
            + `eliminar o autorizar en ARCA (se emitirá como Factura ${f.letra}).`;
    } else if (f.estado === 'EMITIDA' && esFacturaValida(f)) {
        info.textContent = `${nombreComprobante(f)} autorizada por ARCA: tiene número de comprobante, `
            + 'por eso no se elimina; solo puede anularse.';
    } else if (f.estado === 'EMITIDA') {
        info.textContent = `${nombreComprobante(f)}: tiene número pero no tiene CAE, así que no es una factura `
            + 'válida. Como tiene número no se elimina; puede anularse.';
    } else {
        info.textContent = 'Comprobante anulado: queda registrado solo para consulta e impresión.';
    }
}

function alClickGrilla(evento: MouseEvent): void {
    const fila = (evento.target as HTMLElement).closest<HTMLTableRowElement>('tr[data-id]');
    if (fila) {
        seleccionar(Number(fila.dataset.id));
    }
}

function alDobleClickGrilla(evento: MouseEvent): void {
    const fila = (evento.target as HTMLElement).closest<HTMLTableRowElement>('tr[data-id]');
    if (fila) {
        seleccionar(Number(fila.dataset.id));
        void conBloqueo(verFactura);
    }
}

/** Teclado en la grilla: flechas mueven la seleccion, Enter abre, Supr elimina. */
function alTeclaGrilla(evento: KeyboardEvent): void {
    if (facturas.length === 0) {
        return;
    }
    const indice = facturas.findIndex((f) => f.id === seleccionadaId);
    if (evento.key === 'ArrowDown' || evento.key === 'ArrowUp') {
        evento.preventDefault();
        const paso = evento.key === 'ArrowDown' ? 1 : -1;
        const nuevo = indice === -1 ? 0 : Math.min(Math.max(indice + paso, 0), facturas.length - 1);
        seleccionar(facturas[nuevo].id);
    } else if (evento.key === 'Enter' && indice !== -1) {
        evento.preventDefault();
        void conBloqueo(verFactura);
    } else if (evento.key === 'Delete' && !elemento<HTMLButtonElement>('btn-eliminar').disabled) {
        evento.preventDefault();
        void conBloqueo(eliminarSeleccionada);
    }
}

// =====================================================================
// Acciones de la barra de herramientas
// =====================================================================

async function verFactura(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f) {
        return;
    }
    try {
        const factura = await facturaService.obtenerFactura(f.id);
        renderVer(factura);
        abrirModal('modal-ver');
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
        if (error instanceof ApiError && error.status === 404) {
            await cargarFacturas();
        }
    }
}

function renderVer(f: FacturaCompletaDTO): void {
    elemento('ver-titulo').textContent = f.numeroFactura === null ? 'Borrador (sin número ni CAE)' : nombreComprobante(f);

    const tipo = esFacturaValida(f)
        ? `Factura ${f.letra} (código ARCA ${String(f.codigoComprobante).padStart(2, '0')})`
        : f.numeroFactura === null
            ? `Todavía no es una factura · al autorizarse será Factura ${f.letra}`
            : 'Sin CAE: no es válido como factura';
    const datos: Array<[string, string]> = [
        ['Estado', f.estado],
        ['Tipo de comprobante', tipo],
        ['Fecha de emisión', fechaLegible(f.fechaEmision)],
        ['Punto de venta', `${String(f.puntoVentaNumero).padStart(4, '0')} - ${f.puntoVentaDescripcion}`],
        ['Cliente', f.clienteDenominacion + (f.clienteCuitCuil ? ` (CUIT ${f.clienteCuitCuil.replace(/-/g, '‑')})` : '')],
        ['Condición de IVA', f.condicionIva],
        ['Moneda', f.tipoMoneda],
        ['Lista de precios', f.listaPrecio ?? '—'],
    ];
    if (f.fechaAnulacion) {
        datos.push(['Fecha de anulación', fechaLegible(f.fechaAnulacion)]);
    }
    if (f.estado === 'BORRADOR' && f.motivoRechazo) {
        datos.push(['Último envío a ARCA', f.motivoRechazo]);
    }
    if (f.observaciones) {
        datos.push(['Observaciones', f.observaciones]);
    }
    const ficha = elemento('ver-cabecera');
    ficha.replaceChildren();
    for (const [etiqueta, valor] of datos) {
        const div = document.createElement('div');
        const span = document.createElement('div');
        span.className = 'etiqueta';
        span.textContent = etiqueta;
        div.append(span);
        if (etiqueta === 'Estado') {
            div.append(insignia(valor));
        } else {
            div.append(document.createTextNode(valor));
        }
        ficha.append(div);
    }

    const cuerpo = elemento<HTMLTableSectionElement>('ver-items');
    cuerpo.replaceChildren();
    for (const d of f.detalles) {
        cuerpo.insertRow().append(
            celda(d.articuloCodigo, 'mono'),
            celda(d.descripcion),
            celda(formatoNumero.format(d.cantidad), 'num'),
            celda(moneda(d.precioUnitario), 'num'),
            celda(formatoNumero.format(d.porcentajeBonificacion), 'num'),
            celda(moneda(d.importeNeto), 'num'),
            celda(moneda(d.importeIva), 'num'),
            celda(moneda(d.importeSubtotal), 'num'),
        );
    }

    const totales = elemento<HTMLTableSectionElement>('ver-totales');
    totales.replaceChildren();
    const fila = totales.insertRow();
    const etiqueta = document.createElement('th');
    etiqueta.colSpan = 5;
    etiqueta.textContent = 'Totales';
    fila.append(etiqueta);
    for (const valor of [f.importeNeto, f.importeIva, f.importeTotal]) {
        const th = document.createElement('th');
        th.className = 'num';
        th.textContent = moneda(valor);
        fila.append(th);
    }

    if (f.cae) {
        elemento('ver-cae').textContent = `CAE ${f.cae}`
            + (f.caeFechaVencimiento ? ` · Vencimiento ${fechaLegible(f.caeFechaVencimiento)}` : '');
    } else {
        elemento('ver-cae').textContent = f.numeroFactura === null
            ? 'Sin CAE: el borrador todavía no fue autorizado en ARCA, no es una factura válida.'
            : 'Sin CAE: este comprobante no fue autorizado por ARCA y no es una factura válida.';
    }
    elemento('ver-imprimir').dataset.id = String(f.id);
}

function imprimir(id: number): void {
    window.open(facturaService.urlComprobantePdf(id), '_blank', 'noopener');
}

async function autorizarSeleccionada(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f || f.estado !== 'BORRADOR') {
        return;
    }
    const destino = estadoArca?.modo === 'homologacion'
        ? 'a los servidores de homologación de ARCA (WSFEv1)'
        : 'a ARCA (modo simulado)';
    // ARCA acepta fechas de hasta 5 dias antes o despues de hoy: se avisa antes de enviar
    const dias = Math.round((Date.parse(f.fechaEmision) - Date.parse(hoyIso())) / 86_400_000);
    const avisoFecha = Math.abs(dias) > DIAS_TOLERANCIA_FECHA_ARCA
        ? ` Atención: la fecha del borrador (${fechaLegible(f.fechaEmision)}) está fuera de los `
            + `${DIAS_TOLERANCIA_FECHA_ARCA} días que acepta ARCA, así que lo va a rechazar; conviene editar la fecha antes.`
        : '';
    const { confirmado } = await confirmar({
        titulo: 'Autorizar borrador en ARCA',
        mensaje: `Se envía el borrador de ${f.clienteDenominacion} por ${moneda(f.importeTotal)} ${destino}. `
            + `Si ARCA lo aprueba se emite como Factura ${f.letra} con el próximo número de comprobante y un CAE, `
            + 'y ya no podrá editarse ni eliminarse.' + avisoFecha,
        textoConfirmar: 'Autorizar',
    });
    if (!confirmado) {
        return;
    }
    try {
        const autorizada = await facturaService.autorizarFactura(f.id);
        mostrarMensaje(`Autorizado: ${nombreComprobante(autorizada)} · CAE ${autorizada.cae}`);
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
        if (error instanceof ApiError && (error.status === 409 || error.status === 404)) {
            await cargarFacturas(); // muestra la marca "Rechazado por ARCA" o quita lo que ya no existe
        }
    }
}

async function anularSeleccionada(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f || f.estado !== 'EMITIDA') {
        return;
    }
    const nombre = nombreComprobante(f);
    const { confirmado, motivo } = await confirmar({
        titulo: `Anular ${nombre}`,
        mensaje: 'El comprobante queda registrado con estado ANULADA y la fecha de anulación de hoy. '
            + 'No podrá volver a modificarse.',
        textoConfirmar: 'Anular',
        pedirMotivo: true,
    });
    if (!confirmado) {
        return;
    }
    if (motivo.length > LARGO_MAXIMO_TEXTO) {
        mostrarMensaje(`El motivo no puede superar ${LARGO_MAXIMO_TEXTO} caracteres`, 'error');
        return;
    }
    try {
        await facturaService.actualizarEstado(f.id, 'ANULADA', motivo || undefined);
        mostrarMensaje(`Se anuló ${nombre}`);
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
        await cargarFacturas();
    }
}

async function eliminarSeleccionada(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f || f.estado !== 'BORRADOR') {
        return;
    }
    const { confirmado } = await confirmar({
        titulo: 'Eliminar borrador',
        mensaje: `Se borra definitivamente el borrador de ${f.clienteDenominacion} por ${moneda(f.importeTotal)} `
            + 'y todos sus ítems. Como no tiene número de comprobante, puede eliminarse.',
        textoConfirmar: 'Eliminar',
    });
    if (!confirmado) {
        return;
    }
    try {
        await facturaService.eliminarFactura(f.id);
        seleccionadaId = null;
        mostrarMensaje('Borrador eliminado');
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
        await cargarFacturas(); // ya no existe o cambio de estado: refrescar la grilla
    }
}

// =====================================================================
// Modal de alta / edicion: cabecera
// =====================================================================

/** Foto del formulario para detectar cambios sin guardar. */
function estadoFormularioAlta(): string {
    const valor = (id: string): string => elemento<HTMLInputElement | HTMLSelectElement>(id).value;
    return JSON.stringify({
        fecha: valor('alta-fecha'), pv: valor('alta-punto-venta'), cliente: clienteAlta?.id ?? null,
        condicion: valor('alta-condicion-iva'), moneda: valor('alta-tipo-moneda'), lista: valor('alta-lista-precio'),
        obs: valor('alta-observaciones').trim(), items,
    });
}

function prepararFormularioAlta(): void {
    elemento<HTMLFormElement>('form-alta').reset();
    elegirArticulo(null);
    elemento<HTMLInputElement>('item-cantidad').value = '1';
    elemento<HTMLInputElement>('item-bonificacion').value = '0';
}

async function abrirAlta(): Promise<void> {
    idEnEdicion = null;
    prepararFormularioAlta();
    elemento('modal-factura-titulo').textContent = 'Nuevo borrador';
    elemento<HTMLInputElement>('alta-fecha').value = hoyIso();
    actualizarAvisoFecha();
    elegirClienteAlta(null);
    items = [];
    camposInvalidos.clear();
    renderItems();
    abrirModal('modal-factura');
    await cargarPreciosLista();
    estadoInicialAlta = estadoFormularioAlta();
}

async function abrirEdicion(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f || f.estado !== 'BORRADOR') {
        return;
    }
    try {
        const factura = await facturaService.obtenerFactura(f.id);
        if (factura.estado !== 'BORRADOR') {
            mostrarMensaje('El comprobante ya no es un borrador: no se puede editar', 'error');
            await cargarFacturas();
            return;
        }
        idEnEdicion = factura.id;
        prepararFormularioAlta();
        elemento('modal-factura-titulo').textContent = 'Editar borrador';
        elemento<HTMLInputElement>('alta-fecha').value = factura.fechaEmision;
        actualizarAvisoFecha();
        elemento<HTMLSelectElement>('alta-punto-venta').value = String(factura.puntoVentaId);
        elemento<HTMLSelectElement>('alta-tipo-moneda').value = String(factura.tipoMonedaId);
        elemento<HTMLInputElement>('alta-observaciones').value = factura.observaciones ?? '';
        elemento<HTMLSelectElement>('alta-condicion-iva').value = String(factura.condicionIvaId);
        clienteAlta = factura.clienteId === null ? null : {
            id: factura.clienteId,
            texto: `${factura.clienteDenominacion} (${factura.clienteCuitCuil ?? ''})`,
            condicionIvaId: factura.clienteCondicionIvaId,
        };
        elemento<HTMLInputElement>('alta-cliente-texto').value = clienteAlta?.texto ?? '';
        aplicarCondicionIva();
        const condicionCorregida = elemento<HTMLSelectElement>('alta-condicion-iva').value !== String(factura.condicionIvaId);

        // Los renglones se muestran tal como estan guardados (no se recalculan solos)
        items = factura.detalles.map((d) => ({
            articuloId: d.articuloId,
            codigo: d.articuloCodigo,
            descripcion: d.descripcion,
            precioUnitario: d.precioUnitario,
            cantidad: d.cantidad,
            porcentajeBonificacion: d.porcentajeBonificacion,
        }));
        camposInvalidos.clear();
        if (factura.listaPrecioId !== null) {
            elemento<HTMLSelectElement>('alta-lista-precio').value = String(factura.listaPrecioId);
        }
        renderItems();
        abrirModal('modal-factura');
        estadoInicialAlta = estadoFormularioAlta();
        await cargarPreciosLista();
        if (condicionCorregida) {
            mostrarMensaje('La condición de IVA del borrador no coincidía con la del cliente: se ajustó. '
                + 'Guardá para aplicar el cambio.', 'info');
        }
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
        if (error instanceof ApiError && (error.status === 404 || error.status === 409)) {
            await cargarFacturas(); // lo borraron o autorizaron desde otra pestaña: la grilla muestra el estado real
        }
    }
}

function elegirClienteAlta(cliente: ClienteElegido | null): void {
    clienteAlta = cliente;
    elemento<HTMLInputElement>('alta-cliente-texto').value = cliente?.texto ?? '';
    aplicarCondicionIva();
}

async function buscarClienteAlta(): Promise<void> {
    const elegido = await explorarClientes('Seleccionar cliente');
    if (elegido) {
        elegirClienteAlta(elegido.id === 0 ? null : clienteElegido(elegido));
    }
}

/** Cerrar el modal (X, Cancelar o Esc): si hay cambios sin guardar, pide confirmacion. */
async function intentarCerrarAlta(): Promise<void> {
    if (estadoFormularioAlta() !== estadoInicialAlta) {
        const { confirmado } = await confirmar({
            titulo: 'Descartar cambios',
            mensaje: 'Hay cambios sin guardar en el borrador. Si cerrás, se pierden.',
            textoConfirmar: 'Descartar cambios',
        });
        if (!confirmado) {
            return;
        }
    }
    cerrarModal('modal-factura');
}

// =====================================================================
// Modal de alta / edicion: lista de precios e items
// =====================================================================

function elegirArticulo(articulo: ArticuloPrecioDTO | null): void {
    articuloElegido = articulo;
    elemento<HTMLInputElement>('item-articulo-texto').value = articulo
        ? `${articulo.codigo} - ${articulo.denominacion} · ${moneda(articulo.precio)}`
        : '';
}

function listaElegida(): { id: number; nombre: string } {
    const select = elemento<HTMLSelectElement>('alta-lista-precio');
    return { id: Number(select.value), nombre: select.selectedOptions[0]?.text ?? '' };
}

/** Trae los precios de la lista elegida para marcar los renglones que no coinciden con ella. */
async function cargarPreciosLista(): Promise<void> {
    const { id } = listaElegida();
    const numero = ++consultaPrecios;
    preciosLista = null;
    renderItems();
    if (!id) {
        return;
    }
    try {
        const articulos = await catalogoService.buscarArticulos(id, '');
        if (numero !== consultaPrecios) {
            return; // mientras tanto se eligio otra lista
        }
        preciosLista = new Map(articulos.map((a) => [a.articuloId, a.precio] as const));
        renderItems();
    } catch (error) {
        if (numero === consultaPrecios) {
            mostrarMensaje(`No se pudieron leer los precios de la lista: ${describirError(error)}`, 'error');
        }
    }
}

function estadoItem(item: ItemEnMemoria): EstadoItem {
    if (preciosLista === null) {
        return 'verificando';
    }
    const precio = preciosLista.get(item.articuloId);
    if (precio === undefined) {
        return 'fuera';
    }
    return Math.abs(precio - item.precioUnitario) < 0.005 ? 'ok' : 'desactualizado';
}

/** Primero se determina la lista de precios y despues se elige un articulo DE ESA lista. */
async function buscarArticulo(): Promise<void> {
    const lista = listaElegida();
    if (!lista.id) {
        mostrarMensaje('Elegí primero la lista de precios', 'error');
        elemento('alta-lista-precio').focus();
        return;
    }
    const elegido = await abrirExplorer<ArticuloPrecioDTO>({
        titulo: `Artículos de ${lista.nombre}`,
        subtitulo: 'Solo se muestran los artículos de la lista de precios elegida, con su precio neto (sin IVA).',
        placeholder: 'Código, descripción, rubro o marca',
        columnas: [
            { titulo: 'Código', valor: (a) => a.codigo, clase: 'mono' },
            { titulo: 'Descripción', valor: (a) => a.denominacion },
            { titulo: 'Rubro', valor: (a) => a.rubro ?? '' },
            { titulo: 'Marca', valor: (a) => a.marca ?? '' },
            { titulo: 'Precio', valor: (a) => moneda(a.precio), clase: 'num' },
        ],
        buscar: (texto) => catalogoService.buscarArticulos(lista.id, texto),
    });
    // si mientras el explorer estaba abierto se cambio de lista, el articulo ya no corresponde
    if (elegido && listaElegida().id === lista.id) {
        elegirArticulo(elegido);
        elemento<HTMLInputElement>('item-cantidad').select();
    }
}

/**
 * Cambio de lista: los renglones NO se recalculan ni se quitan solos (se perderia lo cargado).
 * Se marcan los que no estan en la lista nueva o tienen otro precio; el usuario decide.
 */
async function alCambiarListaPrecio(): Promise<void> {
    elegirArticulo(null); // el articulo elegido era de la otra lista
    await cargarPreciosLista();
    const fuera = items.filter((i) => estadoItem(i) === 'fuera').length;
    if (fuera > 0) {
        mostrarMensaje(`${fuera} ítem(s) no están en ${listaElegida().nombre}. No se quitaron ni se recalcularon: `
            + 'quitalos a mano o volvé a la lista anterior.', 'info');
    }
}

function recalcularConLista(): void {
    if (preciosLista === null || items.some((i) => estadoItem(i) === 'fuera')) {
        return;
    }
    const precios = preciosLista;
    let cambiados = 0;
    for (const item of items) {
        const precio = precios.get(item.articuloId);
        if (precio !== undefined && Math.abs(precio - item.precioUnitario) >= 0.005) {
            item.precioUnitario = precio;
            cambiados++;
        }
    }
    renderItems();
    mostrarMensaje(`Se recalcularon ${cambiados} ítem(s) con los precios de ${listaElegida().nombre}`);
}

function validarCantidad(valor: number): string | null {
    if (!Number.isFinite(valor) || valor <= 0) {
        return 'La cantidad debe ser mayor a 0';
    }
    if (valor > CANTIDAD_MAXIMA) {
        return `La cantidad no puede superar ${formatoNumero.format(CANTIDAD_MAXIMA)}`;
    }
    // los articulos se venden por unidad: no se vende media botella de agua
    return Number.isInteger(valor) ? null : 'La cantidad tiene que ser un número entero (los artículos se venden por unidad)';
}

function validarBonificacion(valor: number): string | null {
    if (!Number.isFinite(valor) || valor < 0 || valor > 100) {
        return 'La bonificación debe estar entre 0 y 100';
    }
    return tieneHastaDosDecimales(valor) ? null : 'La bonificación admite hasta 2 decimales';
}

function agregarItem(): void {
    const inputCantidad = elemento<HTMLInputElement>('item-cantidad');
    const inputBonif = elemento<HTMLInputElement>('item-bonificacion');
    const articulo = articuloElegido;

    if (!articulo) {
        mostrarMensaje('Buscá y seleccioná un artículo de la lista de precios', 'error');
        elemento('btn-item-articulo').focus();
        return;
    }
    const existente = items.findIndex((i) => i.articuloId === articulo.articuloId);
    if (existente !== -1) {
        mostrarMensaje(`${articulo.codigo} ya está cargado: modificá la cantidad de ese renglón`, 'error');
        elemento('items-cuerpo').querySelector<HTMLInputElement>(
            `input[data-indice="${existente}"][data-campo="cantidad"]`)?.select();
        return;
    }
    const cantidad = Number(inputCantidad.value);
    const errorCantidad = inputCantidad.value.trim() === '' ? 'Indicá la cantidad' : validarCantidad(cantidad);
    if (errorCantidad) {
        mostrarMensaje(errorCantidad, 'error');
        inputCantidad.select();
        return;
    }
    const bonificacion = Number(inputBonif.value || 0);
    const errorBonif = validarBonificacion(bonificacion);
    if (errorBonif) {
        mostrarMensaje(errorBonif, 'error');
        inputBonif.select();
        return;
    }

    items.push({
        articuloId: articulo.articuloId,
        codigo: articulo.codigo,
        descripcion: articulo.denominacion,
        precioUnitario: articulo.precio,
        cantidad,
        porcentajeBonificacion: bonificacion,
    });
    inputCantidad.value = '1';
    inputBonif.value = '0';
    elegirArticulo(null);
    renderItems();
    elemento('btn-item-articulo').focus();
}

/** Si el renglon tiene un valor invalido pendiente en ese campo, lo vuelve a mostrar en rojo. */
function marcarPendiente(input: HTMLInputElement, item: ItemEnMemoria): HTMLInputElement {
    const texto = camposInvalidos.get(item)?.get(input.dataset.campo as CampoItem);
    if (texto !== undefined) {
        input.value = texto;
        input.classList.add('invalido');
        input.setAttribute('aria-invalid', 'true');
    }
    return input;
}

function inputNumerico(valor: number, indice: number, campo: CampoItem,
                       min: number, max: number): HTMLInputElement {
    const input = document.createElement('input');
    input.type = 'number';
    input.step = campo === 'cantidad' ? '1' : '0.01'; // cantidad entera; bonificacion con 2 decimales
    input.min = String(min);
    input.max = String(max);
    input.value = String(valor);
    input.dataset.indice = String(indice);
    input.dataset.campo = campo;
    input.setAttribute('aria-label', campo === 'cantidad' ? 'Cantidad' : 'Bonificación %');
    return input;
}

function renderItems(): void {
    const cuerpo = elemento<HTMLTableSectionElement>('items-cuerpo');
    cuerpo.replaceChildren();
    // los valores invalidos de renglones que ya no estan (quitados) se descartan;
    // los de los renglones que siguen se vuelven a mostrar en rojo (no se pierden en silencio)
    for (const item of [...camposInvalidos.keys()]) {
        if (!items.includes(item)) {
            camposInvalidos.delete(item);
        }
    }

    if (items.length === 0) {
        const td = celda('Todavía no agregaste ítems.', 'vacia');
        td.colSpan = 8;
        cuerpo.insertRow().append(td);
    }

    const nombreLista = listaElegida().nombre;
    let totalNeto = 0;
    let totalIva = 0;
    let total = 0;
    let fuera = 0;
    let desactualizados = 0;

    items.forEach((item, indice) => {
        const { neto, iva, subtotal } = calcularImportes(item);
        totalNeto += neto;
        totalIva += iva;
        total += subtotal;

        const estado = estadoItem(item);
        const fila = cuerpo.insertRow();
        const tdArticulo = celda(`${item.codigo} - ${item.descripcion}`);
        if (estado === 'fuera') {
            fuera++;
            fila.className = 'item-fuera';
            const nota = document.createElement('span');
            nota.className = 'item-nota';
            nota.textContent = `No está en ${nombreLista}`;
            tdArticulo.append(nota);
        } else if (estado === 'desactualizado') {
            desactualizados++;
            fila.className = 'item-desactualizado';
            const nota = document.createElement('span');
            nota.className = 'item-nota';
            nota.textContent = `Precio de otra lista · en ${nombreLista}: ${moneda(preciosLista?.get(item.articuloId) ?? 0)}`;
            tdArticulo.append(nota);
        }
        fila.append(tdArticulo);

        const tdCantidad = celda('', 'num');
        tdCantidad.append(marcarPendiente(inputNumerico(item.cantidad, indice, 'cantidad', 1, CANTIDAD_MAXIMA), item));
        fila.append(tdCantidad);

        fila.append(celda(moneda(item.precioUnitario), 'num'));

        const tdBonif = celda('', 'num');
        tdBonif.append(marcarPendiente(inputNumerico(item.porcentajeBonificacion, indice, 'porcentajeBonificacion', 0, 100), item));
        fila.append(tdBonif);

        fila.append(celda(moneda(neto), 'num'), celda(moneda(iva), 'num'), celda(moneda(subtotal), 'num'));

        const tdQuitar = celda('');
        tdQuitar.append(boton('Quitar', 'btn-peligro', { accion: 'quitar', indice: String(indice) }));
        fila.append(tdQuitar);
    });

    elemento('total-neto').textContent = moneda(redondear(totalNeto));
    elemento('total-iva').textContent = moneda(redondear(totalIva));
    elemento('total-general').textContent = moneda(redondear(total));

    // Aviso de renglones que no coinciden con la lista elegida
    const aviso = elemento('aviso-lista');
    const texto = elemento('aviso-lista-texto');
    const btnRecalcular = elemento<HTMLButtonElement>('btn-recalcular');
    aviso.hidden = fuera === 0 && desactualizados === 0;
    aviso.classList.toggle('error', fuera > 0);
    btnRecalcular.hidden = fuera > 0;
    btnRecalcular.textContent = `Recalcular con ${nombreLista}`;
    if (fuera > 0) {
        texto.textContent = `${fuera} ítem(s) no están en ${nombreLista}. No se quitan ni se recalculan solos: `
            + 'quitalos con "Quitar" o volvé a la lista anterior. Los importes siguen siendo los cargados.';
    } else if (desactualizados > 0) {
        texto.textContent = `${desactualizados} ítem(s) tienen el precio de otra lista. `
            + 'Recalculá para aplicar los precios de la lista elegida antes de guardar.';
    }
}

/** Edicion en linea de cantidad / bonificacion. */
function alCambiarItem(evento: Event): void {
    const input = evento.target as HTMLInputElement;
    const item = items[Number(input.dataset.indice)];
    const campo = input.dataset.campo;
    if (!item || (campo !== 'cantidad' && campo !== 'porcentajeBonificacion')) {
        return;
    }
    const valor = Number(input.value);
    const error = input.value.trim() === '' ? 'El valor no puede quedar vacío'
        : campo === 'cantidad' ? validarCantidad(valor) : validarBonificacion(valor);
    const pendientes = camposInvalidos.get(item);
    if (error) {
        // el valor invalido queda a la vista (marcado en rojo) y no se puede guardar hasta corregirlo:
        // asi no se descarta en silencio lo que el usuario escribio
        camposInvalidos.set(item, (pendientes ?? new Map<CampoItem, string>()).set(campo, input.value));
        input.classList.add('invalido');
        input.setAttribute('aria-invalid', 'true');
        mostrarMensaje(error, 'error');
        return;
    }
    pendientes?.delete(campo);
    if (pendientes?.size === 0) {
        camposInvalidos.delete(item);
    }
    item[campo] = valor;
    renderItems();
}

function alClickItems(evento: Event): void {
    const btn = (evento.target as HTMLElement).closest<HTMLButtonElement>('button[data-accion="quitar"]');
    if (btn) {
        items.splice(Number(btn.dataset.indice), 1);
        renderItems();
    }
}

/** Enter dentro del formulario NO guarda: en cantidad/bonificacion agrega el item, en el resto no hace nada. */
function alTeclaFormularioAlta(evento: KeyboardEvent): void {
    const objetivo = evento.target as HTMLElement;
    if (evento.key !== 'Enter' || objetivo.tagName !== 'INPUT') {
        return;
    }
    evento.preventDefault();
    if (objetivo.id === 'item-cantidad' || objetivo.id === 'item-bonificacion') {
        agregarItem();
    } else if (objetivo.closest('#items-cuerpo')) {
        objetivo.dispatchEvent(new Event('change', { bubbles: true }));
    }
}

function validarFormularioAlta(): string | null {
    const fecha = elemento<HTMLInputElement>('alta-fecha').value;
    if (!fecha) {
        return 'Indicá la fecha de emisión';
    }
    if (fecha < '2000-01-01' || fecha > '2099-12-31') {
        return 'La fecha de emisión no es válida';
    }
    if (!elemento<HTMLSelectElement>('alta-condicion-iva').value) {
        return 'Elegí la condición de IVA';
    }
    if (elemento<HTMLInputElement>('alta-observaciones').value.trim().length > LARGO_MAXIMO_TEXTO) {
        return `Las observaciones no pueden superar ${LARGO_MAXIMO_TEXTO} caracteres`;
    }
    if (items.length === 0) {
        return 'Agregá al menos un ítem';
    }
    if (camposInvalidos.size > 0) {
        return 'Hay una cantidad o bonificación inválida (marcada en rojo): corregila antes de guardar';
    }
    // borradores viejos pueden traer cantidades con decimales: se avisa antes de mandar al servidor
    const conDecimales = items.find((i) => validarCantidad(i.cantidad) !== null);
    if (conDecimales) {
        return `${conDecimales.codigo}: ${validarCantidad(conDecimales.cantidad)}`;
    }
    const estados = items.map(estadoItem);
    if (estados.includes('verificando')) {
        return 'Todavía se están verificando los precios de la lista; esperá un momento';
    }
    if (estados.includes('fuera')) {
        return `Hay ítems que no están en ${listaElegida().nombre}: quitalos o volvé a la lista anterior`;
    }
    if (estados.includes('desactualizado')) {
        return 'Hay ítems con precios de otra lista: tocá "Recalcular" antes de guardar';
    }
    return null;
}

async function guardarFactura(evento: SubmitEvent): Promise<void> {
    evento.preventDefault();
    const btn = elemento<HTMLButtonElement>('btn-guardar');
    if (btn.disabled) {
        return;
    }
    const error = validarFormularioAlta();
    if (error) {
        mostrarMensaje(error, 'error');
        return;
    }

    const observaciones = elemento<HTMLInputElement>('alta-observaciones').value.trim();
    const detalles: FacturaDetalleRequestDTO[] = items.map((item) => ({
        articuloId: item.articuloId,
        cantidad: item.cantidad,
        porcentajeBonificacion: item.porcentajeBonificacion,
    }));
    const factura: FacturaRequestDTO = {
        fechaEmision: elemento<HTMLInputElement>('alta-fecha').value,
        puntoVentaId: Number(elemento<HTMLSelectElement>('alta-punto-venta').value),
        condicionIvaId: Number(elemento<HTMLSelectElement>('alta-condicion-iva').value),
        tipoMonedaId: Number(elemento<HTMLSelectElement>('alta-tipo-moneda').value),
        listaPrecioId: listaElegida().id,
        detalles,
    };

    btn.disabled = true;
    try {
        let guardada: FacturaReporteDTO;
        if (idEnEdicion === null) {
            factura.clienteId = clienteAlta?.id ?? null;
            factura.observaciones = observaciones || undefined;
            guardada = await facturaService.crearFactura(factura);
            mostrarMensaje(`Borrador guardado por ${moneda(guardada.importeTotal)}. `
                + 'Todavía no es una factura: usá "Autorizar en ARCA" para obtener número y CAE.');
        } else {
            factura.clienteId = clienteAlta?.id ?? 0; // en PUT, 0 = Consumidor Final
            factura.observaciones = observaciones; // "" borra las observaciones
            guardada = await facturaService.actualizarFactura(idEnEdicion, factura);
            mostrarMensaje(`Borrador actualizado (${moneda(guardada.importeTotal)})`);
        }
        cerrarModal('modal-factura');
        seleccionadaId = guardada.id;
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(`No se pudo guardar: ${describirError(error)}`, 'error');
        if (idEnEdicion !== null && error instanceof ApiError && (error.status === 404 || error.status === 409)) {
            await cargarFacturas(); // el borrador pudo cambiar en otra pestaña: refrescar la grilla de fondo
        }
    } finally {
        btn.disabled = false;
    }
}

// =====================================================================
// Filtros
// =====================================================================

function leerFiltros(): FacturaFiltrosDTO | null {
    const valor = (id: string): string => elemento<HTMLInputElement | HTMLSelectElement>(id).value.trim();
    const fechaDesde = valor('filtro-fecha-desde');
    const fechaHasta = valor('filtro-fecha-hasta');
    const numero = valor('filtro-numero');
    const montoMinimo = valor('filtro-monto-minimo');
    const montoMaximo = valor('filtro-monto-maximo');

    // un input date/number con texto invalido devuelve "": se avisa en vez de ignorarlo
    for (const id of ['filtro-fecha-desde', 'filtro-fecha-hasta', 'filtro-numero', 'filtro-monto-minimo', 'filtro-monto-maximo']) {
        if (elemento<HTMLInputElement>(id).validity.badInput) {
            mostrarMensaje('Hay un filtro con un valor inválido: corregilo o borralo', 'error');
            return null;
        }
    }
    if (fechaDesde && fechaHasta && fechaDesde > fechaHasta) {
        mostrarMensaje('"Fecha desde" no puede ser posterior a "Fecha hasta"', 'error');
        return null;
    }
    if (numero && !(Number.isInteger(Number(numero)) && Number(numero) >= 1 && Number(numero) <= 99_999_999)) {
        mostrarMensaje('El número de comprobante tiene que ser un entero entre 1 y 99.999.999', 'error');
        return null;
    }
    for (const [texto, nombre] of [[montoMinimo, 'mínimo'], [montoMaximo, 'máximo']]) {
        if (texto && !(Number.isFinite(Number(texto)) && Number(texto) >= 0)) {
            mostrarMensaje(`El monto ${nombre} tiene que ser un número mayor o igual a 0`, 'error');
            return null;
        }
    }
    if (montoMinimo && montoMaximo && Number(montoMinimo) > Number(montoMaximo)) {
        mostrarMensaje('El monto mínimo no puede ser mayor al monto máximo', 'error');
        return null;
    }

    const filtros: FacturaFiltrosDTO = {};
    if (fechaDesde) filtros.fechaDesde = fechaDesde;
    if (fechaHasta) filtros.fechaHasta = fechaHasta;
    if (valor('filtro-estado')) filtros.estado = valor('filtro-estado');
    if (clienteFiltro) filtros.clienteId = clienteFiltro.id; // 0 = solo Consumidor Final
    if (valor('filtro-punto-venta')) filtros.puntoVentaId = Number(valor('filtro-punto-venta'));
    if (numero) filtros.numero = Number(numero);
    if (montoMinimo) filtros.montoMinimo = Number(montoMinimo);
    if (montoMaximo) filtros.montoMaximo = Number(montoMaximo);
    return filtros;
}

function elegirClienteFiltro(cliente: ClienteElegido | null): void {
    clienteFiltro = cliente;
    elemento<HTMLInputElement>('filtro-cliente-texto').value = cliente?.texto ?? '';
}

async function buscarClienteFiltro(): Promise<void> {
    const elegido = await explorarClientes('Filtrar por cliente');
    if (elegido) {
        elegirClienteFiltro(clienteElegido(elegido));
    }
}

function actualizarLinksReporte(): void {
    elemento<HTMLAnchorElement>('link-pdf').href = facturaService.urlReporte('pdf', filtrosActuales);
    elemento<HTMLAnchorElement>('link-excel').href = facturaService.urlReporte('excel', filtrosActuales);
}

// =====================================================================
// Estado de ARCA (indicador del encabezado)
// =====================================================================

async function cargarEstadoArca(): Promise<void> {
    const indicador = elemento('estado-arca');
    try {
        estadoArca = await arcaService.obtenerEstado();
        if (estadoArca.modo === 'simulado') {
            indicador.textContent = 'ARCA: modo simulado';
            indicador.className = 'indicador-arca';
        } else {
            indicador.textContent = estadoArca.servidoresOk
                ? `ARCA homologación · CUIT ${estadoArca.cuit} · servidores OK`
                : 'ARCA homologación · sin conexión';
            indicador.className = `indicador-arca ${estadoArca.servidoresOk ? 'ok' : 'error'}`;
        }
        indicador.title = estadoArca.detalle;
    } catch {
        indicador.textContent = 'ARCA: estado desconocido';
        indicador.className = 'indicador-arca error';
    }
}

// =====================================================================
// Inicio: conectar eventos y cargar datos
// =====================================================================

function conectarEventos(): void {
    // filtros
    const formFiltros = elemento<HTMLFormElement>('form-filtros');
    formFiltros.addEventListener('submit', (e) => {
        e.preventDefault();
        const filtros = leerFiltros();
        if (filtros) {
            filtrosActuales = filtros;
            void cargarFacturas();
        }
    });
    formFiltros.addEventListener('reset', () => {
        elegirClienteFiltro(null);
        filtrosActuales = {};
        void cargarFacturas();
    });
    elemento('btn-filtro-cliente').addEventListener('click', () => void buscarClienteFiltro());
    elemento('btn-filtro-cliente-quitar').addEventListener('click', () => elegirClienteFiltro(null));

    // grilla
    const grilla = elemento<HTMLTableElement>('tabla-facturas');
    grilla.addEventListener('click', alClickGrilla);
    grilla.addEventListener('dblclick', alDobleClickGrilla);
    grilla.addEventListener('keydown', alTeclaGrilla);

    // barra de herramientas (de a una accion por vez)
    elemento('btn-nueva').addEventListener('click', () => void conBloqueo(abrirAlta));
    elemento('btn-ver').addEventListener('click', () => void conBloqueo(verFactura));
    elemento('btn-editar').addEventListener('click', () => void conBloqueo(abrirEdicion));
    elemento('btn-autorizar').addEventListener('click', () => void conBloqueo(autorizarSeleccionada));
    elemento('btn-imprimir').addEventListener('click', () => seleccionadaId !== null && imprimir(seleccionadaId));
    elemento('btn-anular').addEventListener('click', () => void conBloqueo(anularSeleccionada));
    elemento('btn-eliminar').addEventListener('click', () => void conBloqueo(eliminarSeleccionada));

    // modal de alta/edicion
    const formAlta = elemento<HTMLFormElement>('form-alta');
    formAlta.addEventListener('submit', (e) => void guardarFactura(e));
    formAlta.addEventListener('keydown', alTeclaFormularioAlta);
    elemento('btn-alta-cliente').addEventListener('click', () => void buscarClienteAlta());
    elemento('btn-alta-cliente-quitar').addEventListener('click', () => elegirClienteAlta(null));
    elemento('alta-condicion-iva').addEventListener('change', actualizarAyudaCondicion);
    elemento('alta-lista-precio').addEventListener('change', () => void alCambiarListaPrecio());
    elemento('alta-fecha').addEventListener('input', actualizarAvisoFecha);
    elemento('alta-fecha').addEventListener('change', actualizarAvisoFecha);
    elemento('btn-item-articulo').addEventListener('click', () => void buscarArticulo());
    elemento('btn-agregar-item').addEventListener('click', agregarItem);
    elemento('btn-recalcular').addEventListener('click', recalcularConLista);
    elemento('items-cuerpo').addEventListener('change', alCambiarItem);
    elemento('items-cuerpo').addEventListener('click', alClickItems);
    const modalAlta = elemento<HTMLDialogElement>('modal-factura');
    modalAlta.addEventListener('cancel', (e) => {
        e.preventDefault(); // Esc: pasa por la confirmacion de cambios sin guardar
        void intentarCerrarAlta();
    });
    modalAlta.querySelectorAll('[data-cerrar]').forEach((b) =>
        b.addEventListener('click', () => void intentarCerrarAlta()));

    // modal ver
    elemento('ver-imprimir').addEventListener('click', (e) => {
        imprimir(Number((e.currentTarget as HTMLElement).dataset.id));
    });

    // botones "Cerrar" / X del resto de los modales
    for (const btn of document.querySelectorAll<HTMLButtonElement>('[data-cerrar]')) {
        if (!btn.closest('#modal-factura')) {
            btn.addEventListener('click', () => btn.closest('dialog')?.close());
        }
    }
}

async function iniciar(): Promise<void> {
    conectarEventos();
    renderItems();
    void cargarEstadoArca();
    try {
        await cargarCatalogo();
    } catch (error) {
        mostrarMensaje(`No se pudieron cargar los datos del formulario: ${describirError(error)}`, 'error');
    }
    await cargarFacturas();
}

void iniciar();
