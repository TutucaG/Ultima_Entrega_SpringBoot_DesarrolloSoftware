import type {
    ArcaEstadoDTO,
    ArticuloPrecioDTO,
    CatalogoDTO,
    ClienteExplorerDTO,
    FacturaCompletaDTO,
    FacturaDetalleRequestDTO,
    FacturaFiltrosDTO,
    FacturaReporteDTO,
    FacturaRequestDTO,
    ItemCatalogoDTO,
} from './models/factura.dto.js';
import { FacturaService } from './services/FacturaService.js';
import { CatalogoService } from './services/CatalogoService.js';
import { ApiError } from './services/ApiError.js';
import { ArcaService } from './services/ArcaService.js';

// =====================================================================
// Estado en memoria
// =====================================================================

/** Renglon cargado en el modal de alta/edicion (todavia no enviado al backend). */
interface ItemEnMemoria {
    articuloId: number;
    descripcion: string;
    precioUnitario: number;
    cantidad: number;
    porcentajeBonificacion: number;
}

interface ImportesItem {
    neto: number;
    iva: number;
    subtotal: number;
}

const facturaService = new FacturaService();
const catalogoService = new CatalogoService();
const arcaService = new ArcaService();

let catalogo: CatalogoDTO | null = null;
let facturas: FacturaReporteDTO[] = [];          // filas de la grilla
let seleccionadaId: number | null = null;        // fila seleccionada en el explorer
let items: ItemEnMemoria[] = [];                 // items del modal de alta/edicion
let idEnEdicion: number | null = null;           // null = alta, numero = edicion de un borrador
let filtrosActuales: FacturaFiltrosDTO = {};
let estadoArca: ArcaEstadoDTO | null = null;

/** Cliente elegido con el explorer (null = Consumidor Final en el alta / "Todos" en el filtro). */
interface ClienteElegido {
    id: number;        // 0 = Consumidor Final (sin cliente)
    texto: string;
}
let clienteAlta: ClienteElegido | null = null;
let clienteFiltro: ClienteElegido | null = null;
let articuloElegido: ArticuloPrecioDTO | null = null; // articulo de la lista, antes de "Agregar item"
let listaPrecioActual: number | null = null;          // lista con la que estan cotizados los items

// =====================================================================
// Utilidades
// =====================================================================

function elemento<T extends HTMLElement>(id: string): T {
    const el = document.getElementById(id);
    if (!el) {
        throw new Error(`No existe el elemento #${id} en index.html`);
    }
    return el as T;
}

const formatoMoneda = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' });
const moneda = (valor: number): string => formatoMoneda.format(valor);
const redondear = (valor: number): number => Math.round(valor * 100) / 100;

/** "2026-05-10" -> "10/05/2026" */
function fechaLegible(iso: string | null): string {
    if (!iso) {
        return '';
    }
    const [anio, mes, dia] = iso.split('-');
    return `${dia}/${mes}/${anio}`;
}

/** Fecha local de hoy en formato yyyy-MM-dd (para el input date). */
function hoyIso(): string {
    const hoy = new Date();
    const mes = String(hoy.getMonth() + 1).padStart(2, '0');
    const dia = String(hoy.getDate()).padStart(2, '0');
    return `${hoy.getFullYear()}-${mes}-${dia}`;
}

/** 0001-00001009 (formato de ARCA) o null si todavia no tiene numero. */
function numeroComprobante(puntoVenta: number, numero: number | null): string | null {
    if (numero === null) {
        return null;
    }
    return `${String(puntoVenta).padStart(4, '0')}-${String(numero).padStart(8, '0')}`;
}

/** "B 0001-00001009" (letra + numero) o null si es un borrador sin numero. */
function comprobante(letra: string, puntoVenta: number, numero: number | null): string | null {
    const n = numeroComprobante(puntoVenta, numero);
    return n === null ? null : `${letra} ${n}`;
}

function celda(texto: string, clase?: string): HTMLTableCellElement {
    const td = document.createElement('td');
    td.textContent = texto; // textContent: evita inyectar HTML con datos de la base
    if (clase) {
        td.className = clase;
    }
    return td;
}

function boton(texto: string, clase: string, datos: Record<string, string>): HTMLButtonElement {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `btn btn-chico ${clase}`;
    btn.textContent = texto;
    Object.entries(datos).forEach(([clave, valor]) => (btn.dataset[clave] = valor));
    return btn;
}

function insignia(estado: string): HTMLSpanElement {
    const span = document.createElement('span');
    span.className = `estado estado-${estado}`;
    span.textContent = estado;
    return span;
}

/** Importes de un renglon con la misma formula que FacturaService.java (vista previa). */
function calcularImportes(item: ItemEnMemoria): ImportesItem {
    const alicuota = catalogo?.alicuotaIva ?? 21;
    const bruto = item.cantidad * item.precioUnitario;
    const neto = redondear(bruto - (bruto * item.porcentajeBonificacion) / 100);
    const iva = redondear((neto * alicuota) / 100);
    return { neto, iva, subtotal: redondear(neto + iva) };
}

// =====================================================================
// Mensajes, modales y dialogo de confirmacion
// =====================================================================

let temporizadorMensaje: number | undefined;

function mostrarMensaje(texto: string, tipo: 'ok' | 'error' | 'info' = 'ok'): void {
    const caja = elemento<HTMLDivElement>('mensaje');
    caja.textContent = texto;
    caja.className = `mensaje ${tipo}`;
    // popover "manual": se dibuja por encima de los modales abiertos
    if (caja.matches(':popover-open')) {
        caja.hidePopover();
    }
    caja.showPopover();
    window.clearTimeout(temporizadorMensaje);
    temporizadorMensaje = window.setTimeout(() => caja.hidePopover(), tipo === 'error' ? 7000 : 4500);
}

function describirError(error: unknown): string {
    if (error instanceof ApiError) {
        return `${error.message} (HTTP ${error.status})`;
    }
    if (error instanceof TypeError) {
        // fetch lanza TypeError cuando no hay conexion con el servidor
        return 'No se pudo conectar con la API. ¿Está corriendo Spring Boot en http://localhost:8080?';
    }
    return error instanceof Error ? error.message : String(error);
}

function abrirModal(id: string): void {
    const modal = elemento<HTMLDialogElement>(id);
    if (!modal.open) {
        modal.showModal();
    }
}

function cerrarModal(id: string): void {
    const modal = elemento<HTMLDialogElement>(id);
    if (modal.open) {
        modal.close();
    }
}

interface OpcionesDialogo {
    titulo: string;
    mensaje: string;
    textoConfirmar: string;
    pedirMotivo?: boolean;
}

/** Abre el dialogo de confirmacion y resuelve cuando el usuario confirma o cancela. */
function confirmar(opciones: OpcionesDialogo): Promise<{ confirmado: boolean; motivo: string }> {
    const dialogo = elemento<HTMLDialogElement>('dialogo');
    const motivo = elemento<HTMLTextAreaElement>('dialogo-motivo');

    elemento('dialogo-titulo').textContent = opciones.titulo;
    elemento('dialogo-mensaje').textContent = opciones.mensaje;
    elemento('dialogo-motivo-label').hidden = !opciones.pedirMotivo;
    elemento('dialogo-confirmar').textContent = opciones.textoConfirmar;
    motivo.value = '';

    // Se escuchan los botones (y Esc) directamente en vez del evento "close",
    // que no todos los navegadores disparan de forma confiable.
    return new Promise((resolver) => {
        const terminar = (confirmado: boolean): void => {
            dialogo.removeEventListener('click', alClick);
            dialogo.removeEventListener('cancel', alCancelar);
            if (dialogo.open) {
                dialogo.close();
            }
            resolver({ confirmado, motivo: motivo.value.trim() });
        };
        const alClick = (evento: MouseEvent): void => {
            const btn = (evento.target as HTMLElement).closest<HTMLButtonElement>('button[value]');
            if (btn) {
                terminar(btn.value === 'confirmar');
            }
        };
        const alCancelar = (evento: Event): void => {
            evento.preventDefault();
            terminar(false);
        };
        dialogo.addEventListener('click', alClick);
        dialogo.addEventListener('cancel', alCancelar);
        dialogo.showModal();
        if (opciones.pedirMotivo) {
            motivo.focus();
        }
    });
}

// =====================================================================
// Catalogo (combos de filtros y del formulario)
// =====================================================================

function llenarSelect(select: HTMLSelectElement, opciones: ItemCatalogoDTO[],
                      opcionesIniciales: Array<[string, string]> = []): void {
    select.replaceChildren();
    for (const [texto, valor] of opcionesIniciales) {
        select.append(new Option(texto, valor));
    }
    for (const op of opciones) {
        select.append(new Option(op.descripcion, String(op.id)));
    }
}

async function cargarCatalogo(): Promise<void> {
    catalogo = await catalogoService.obtenerCatalogo();
    // filtros
    llenarSelect(elemento('filtro-punto-venta'), catalogo.puntosVenta, [['Todos', '']]);
    // modal de alta (cliente y articulo NO son combos: se eligen con el explorer)
    llenarSelect(elemento('alta-punto-venta'), catalogo.puntosVenta);
    llenarSelect(elemento('alta-condicion-iva'), catalogo.condicionesIva);
    llenarSelect(elemento('alta-tipo-moneda'), catalogo.tiposMoneda);
    llenarSelect(elemento('alta-lista-precio'), catalogo.listasPrecio);
    elemento('alicuota-iva').textContent = String(catalogo.alicuotaIva);
    sugerirCondicionIva();
}

/** Si se elige Consumidor Final, propone esa condicion de IVA (ARCA exige CUIT para Resp. Inscripto). */
function sugerirCondicionIva(): void {
    const condicion = elemento<HTMLSelectElement>('alta-condicion-iva');
    if (clienteAlta === null) {
        const consumidorFinal = catalogo?.condicionesIva.find((c) => /consumidor final/i.test(c.descripcion));
        if (consumidorFinal) {
            condicion.value = String(consumidorFinal.id);
        }
    }
}

// =====================================================================
// Explorer de seleccion (clientes y articulos): grilla con buscador en un modal
// =====================================================================

interface ColumnaExplorer<T> {
    titulo: string;
    valor: (fila: T) => string;
    clase?: string;
}

interface OpcionesExplorer<T> {
    titulo: string;
    subtitulo: string;
    placeholder: string;
    columnas: ColumnaExplorer<T>[];
    buscar: (texto: string) => Promise<T[]>;
}

/** Abre el explorer y resuelve con la fila elegida (o null si se cancela). */
function abrirExplorer<T>(opciones: OpcionesExplorer<T>): Promise<T | null> {
    const dialogo = elemento<HTMLDialogElement>('modal-explorer');
    const busqueda = elemento<HTMLInputElement>('explorer-busqueda');
    const tabla = elemento<HTMLTableElement>('explorer-tabla');
    const cuerpo = elemento<HTMLTableSectionElement>('explorer-cuerpo');
    const estado = elemento('explorer-estado');
    const btnSeleccionar = elemento<HTMLButtonElement>('explorer-seleccionar');

    elemento('explorer-titulo').textContent = opciones.titulo;
    elemento('explorer-subtitulo').textContent = opciones.subtitulo;
    busqueda.placeholder = opciones.placeholder;
    busqueda.value = '';

    const cabecera = elemento<HTMLTableSectionElement>('explorer-cabecera');
    cabecera.replaceChildren();
    const filaCabecera = cabecera.insertRow();
    for (const col of opciones.columnas) {
        const th = document.createElement('th');
        th.textContent = col.titulo;
        if (col.clase) {
            th.className = col.clase;
        }
        filaCabecera.append(th);
    }

    let filas: T[] = [];
    let indice = -1;
    let consulta = 0; // descarta respuestas viejas si el usuario sigue escribiendo
    let temporizador: number | undefined;

    const marcar = (nuevo: number): void => {
        indice = nuevo;
        cuerpo.querySelectorAll<HTMLTableRowElement>('tr[data-indice]').forEach((tr) => {
            const activa = Number(tr.dataset.indice) === indice;
            tr.setAttribute('aria-selected', String(activa));
            if (activa) {
                tr.scrollIntoView({ block: 'nearest' });
            }
        });
        btnSeleccionar.disabled = indice < 0;
    };

    const render = (): void => {
        cuerpo.replaceChildren();
        if (filas.length === 0) {
            const td = celda('Sin resultados.', 'vacia');
            td.colSpan = opciones.columnas.length;
            cuerpo.insertRow().append(td);
        }
        filas.forEach((fila, i) => {
            const tr = cuerpo.insertRow();
            tr.dataset.id = String(i); // para el estilo de fila seleccionable
            tr.dataset.indice = String(i);
            for (const col of opciones.columnas) {
                tr.append(celda(col.valor(fila), col.clase));
            }
        });
        marcar(filas.length > 0 ? 0 : -1);
    };

    const buscar = async (): Promise<void> => {
        const numero = ++consulta;
        estado.textContent = 'Buscando…';
        try {
            const resultado = await opciones.buscar(busqueda.value.trim());
            if (numero !== consulta) {
                return;
            }
            filas = resultado;
            render();
            estado.textContent = `${filas.length} resultado(s)`;
        } catch (error) {
            if (numero === consulta) {
                filas = [];
                render();
                estado.textContent = describirError(error);
            }
        }
    };

    return new Promise((resolver) => {
        const control = new AbortController();
        const opcion = { signal: control.signal };

        const terminar = (fila: T | null): void => {
            control.abort(); // quita todos los listeners de esta apertura
            window.clearTimeout(temporizador);
            consulta++;
            if (dialogo.open) {
                dialogo.close();
            }
            resolver(fila);
        };
        const confirmarSeleccion = (): void => {
            if (indice >= 0) {
                terminar(filas[indice]);
            }
        };
        const mover = (paso: number): void => {
            if (filas.length > 0) {
                marcar(Math.min(Math.max(indice + paso, 0), filas.length - 1));
            }
        };
        const teclas = (e: KeyboardEvent): void => {
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                mover(e.key === 'ArrowDown' ? 1 : -1);
            } else if (e.key === 'Enter') {
                e.preventDefault();
                confirmarSeleccion();
            }
        };

        busqueda.addEventListener('input', () => {
            window.clearTimeout(temporizador);
            temporizador = window.setTimeout(() => void buscar(), 250);
        }, opcion);
        busqueda.addEventListener('keydown', teclas, opcion);
        tabla.addEventListener('keydown', teclas, opcion);
        cuerpo.addEventListener('click', (e) => {
            const tr = (e.target as HTMLElement).closest<HTMLTableRowElement>('tr[data-indice]');
            if (tr) {
                marcar(Number(tr.dataset.indice));
            }
        }, opcion);
        cuerpo.addEventListener('dblclick', (e) => {
            const tr = (e.target as HTMLElement).closest<HTMLTableRowElement>('tr[data-indice]');
            if (tr) {
                marcar(Number(tr.dataset.indice));
                confirmarSeleccion();
            }
        }, opcion);
        btnSeleccionar.addEventListener('click', confirmarSeleccion, opcion);
        dialogo.querySelectorAll('[data-explorer="cancelar"]').forEach((b) =>
            b.addEventListener('click', () => terminar(null), opcion));
        dialogo.addEventListener('cancel', (e) => {
            e.preventDefault();
            terminar(null);
        }, opcion);

        filas = [];
        render();
        dialogo.showModal();
        busqueda.focus();
        void buscar();
    });
}

const CONSUMIDOR_FINAL: ClienteExplorerDTO = {
    id: 0, cuitCuil: '—', denominacion: 'Consumidor Final (sin cliente)', domicilio: null, email: null, telefono: null,
};

/** Explorer de clientes. La primera fila "Consumidor Final" permite facturar sin cliente. */
function explorarClientes(titulo: string): Promise<ClienteExplorerDTO | null> {
    return abrirExplorer<ClienteExplorerDTO>({
        titulo,
        subtitulo: 'Buscá por razón social o CUIT. Doble clic o Enter para seleccionar.',
        placeholder: 'Ej. Empresa Tech o 30-12345678-9',
        columnas: [
            { titulo: 'CUIT / CUIL', valor: (c) => c.cuitCuil, clase: 'mono' },
            { titulo: 'Razón social', valor: (c) => c.denominacion },
            { titulo: 'Domicilio', valor: (c) => c.domicilio ?? '' },
            { titulo: 'Contacto', valor: (c) => [c.email, c.telefono].filter(Boolean).join(' · ') },
        ],
        buscar: async (texto) => {
            const clientes = await catalogoService.buscarClientes(texto);
            const incluirCf = texto === '' || 'consumidor final'.includes(texto.toLowerCase());
            return incluirCf ? [CONSUMIDOR_FINAL, ...clientes] : clientes;
        },
    });
}

function textoCliente(c: ClienteExplorerDTO): string {
    return c.id === 0 ? 'Consumidor Final' : `${c.denominacion} (${c.cuitCuil})`;
}

// =====================================================================
// Explorer: grilla con seleccion
// =====================================================================

async function cargarFacturas(): Promise<void> {
    const resumen = elemento('resumen-listado');
    try {
        facturas = await facturaService.obtenerFacturas(filtrosActuales);
        if (!facturas.some((f) => f.id === seleccionadaId)) {
            seleccionadaId = null; // la seleccionada ya no esta (borrada o filtrada)
        }
        renderFacturas();
        const emitidas = facturas.filter((f) => f.estado === 'EMITIDA');
        const total = emitidas.reduce((suma, f) => suma + f.importeTotal, 0);
        const borradores = facturas.filter((f) => f.estado === 'BORRADOR').length;
        resumen.textContent = `${facturas.length} comprobante(s) · ${borradores} borrador(es) sin autorizar · `
            + `Total facturado (emitidas): ${moneda(total)}`;
    } catch (error) {
        facturas = [];
        seleccionadaId = null;
        renderFacturas();
        resumen.textContent = 'No se pudo cargar el listado.';
        mostrarMensaje(describirError(error), 'error');
    }
    actualizarLinksReporte();
}

function renderFacturas(): void {
    const cuerpo = elemento<HTMLTableSectionElement>('facturas-cuerpo');
    cuerpo.replaceChildren();

    if (facturas.length === 0) {
        const td = celda('No hay comprobantes que coincidan con los filtros.', 'vacia');
        td.colSpan = 8;
        cuerpo.insertRow().append(td);
    }

    for (const f of facturas) {
        const fila = cuerpo.insertRow();
        fila.dataset.id = String(f.id);
        fila.setAttribute('aria-selected', String(f.id === seleccionadaId));
        if (f.estado === 'ANULADA') {
            fila.classList.add('anulada');
        }

        const numero = comprobante(f.letra, f.puntoVentaNumero, f.numeroFactura);
        fila.append(
            numero ? celda(numero, 'mono') : celda(`${f.letra} · sin número`, 'sin-numero'),
            celda(fechaLegible(f.fechaEmision)),
            celda(f.clienteDenominacion),
            celda(f.condicionIva),
            celda(String(f.cantidadItems), 'num'),
            celda(moneda(f.importeTotal), 'num importe'),
        );
        const tdEstado = celda('');
        tdEstado.append(insignia(f.estado));
        if (f.estado === 'BORRADOR' && f.resultadoAfip === 'R') {
            const rechazo = document.createElement('span');
            rechazo.className = 'estado estado-RECHAZADA';
            rechazo.textContent = 'Rechazada por ARCA';
            tdEstado.append(' ', rechazo);
        }
        fila.append(tdEstado, celda(f.cae ?? '—', 'mono'));
    }
    actualizarBarra();
}

function facturaSeleccionada(): FacturaReporteDTO | undefined {
    return facturas.find((f) => f.id === seleccionadaId);
}

function seleccionar(id: number | null): void {
    seleccionadaId = id;
    for (const fila of elemento('facturas-cuerpo').querySelectorAll<HTMLTableRowElement>('tr[data-id]')) {
        const activa = Number(fila.dataset.id) === id;
        fila.setAttribute('aria-selected', String(activa));
        if (activa) {
            fila.scrollIntoView({ block: 'nearest' });
        }
    }
    actualizarBarra();
}

/** Habilita cada accion segun el estado de la factura seleccionada. */
function actualizarBarra(): void {
    const f = facturaSeleccionada();
    const estado = f?.estado;
    const reglas: Record<string, boolean> = {
        'btn-ver': !!f,
        'btn-imprimir': !!f,
        'btn-editar': estado === 'BORRADOR',      // solo se edita lo que no tiene numero
        'btn-autorizar': estado === 'BORRADOR',   // ARCA asigna numero y CAE
        'btn-eliminar': estado === 'BORRADOR',    // sin numero -> se puede borrar
        'btn-anular': estado === 'EMITIDA',       // con numero -> solo se anula
    };
    for (const [id, habilitado] of Object.entries(reglas)) {
        elemento<HTMLButtonElement>(id).disabled = !habilitado;
    }

    const info = elemento('info-seleccion');
    if (!f) {
        info.textContent = 'Seleccioná una factura de la grilla para habilitar las acciones.';
    } else if (f.estado === 'BORRADOR' && f.resultadoAfip === 'R') {
        info.textContent = 'ARCA rechazó el último envío de este borrador (el motivo está en "Ver"). '
            + 'Corregilo con "Editar" y volvé a autorizarlo, o eliminalo.';
    } else if (f.estado === 'BORRADOR') {
        info.textContent = `Borrador de Factura ${f.letra} sin número: se puede editar, eliminar o autorizar en ARCA `
            + 'para obtener número y CAE.';
    } else if (f.estado === 'EMITIDA') {
        info.textContent = `Factura ${comprobante(f.letra, f.puntoVentaNumero, f.numeroFactura)} autorizada: `
            + 'tiene número de comprobante, por eso no se elimina; solo puede anularse.';
    } else {
        info.textContent = 'Factura anulada: queda registrada solo para consulta e impresión.';
    }
}

function alClickGrilla(evento: MouseEvent): void {
    const fila = (evento.target as HTMLElement).closest<HTMLTableRowElement>('tr[data-id]');
    if (fila) {
        seleccionar(Number(fila.dataset.id));
    }
}

function alDobleClickGrilla(evento: MouseEvent): void {
    const fila = (evento.target as HTMLElement).closest<HTMLTableRowElement>('tr[data-id]');
    if (fila) {
        seleccionar(Number(fila.dataset.id));
        void verFactura();
    }
}

/** Teclado en la grilla: flechas mueven la seleccion, Enter abre, Supr elimina. */
function alTeclaGrilla(evento: KeyboardEvent): void {
    if (facturas.length === 0) {
        return;
    }
    const indice = facturas.findIndex((f) => f.id === seleccionadaId);
    if (evento.key === 'ArrowDown' || evento.key === 'ArrowUp') {
        evento.preventDefault();
        const paso = evento.key === 'ArrowDown' ? 1 : -1;
        const nuevo = indice === -1 ? 0 : Math.min(Math.max(indice + paso, 0), facturas.length - 1);
        seleccionar(facturas[nuevo].id);
    } else if (evento.key === 'Enter' && indice !== -1) {
        evento.preventDefault();
        void verFactura();
    } else if (evento.key === 'Delete' && !elemento<HTMLButtonElement>('btn-eliminar').disabled) {
        evento.preventDefault();
        void eliminarSeleccionada();
    }
}

// =====================================================================
// Acciones de la barra de herramientas
// =====================================================================

async function verFactura(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f) {
        return;
    }
    try {
        const factura = await facturaService.obtenerFactura(f.id);
        renderVer(factura);
        abrirModal('modal-ver');
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
    }
}

function renderVer(f: FacturaCompletaDTO): void {
    const numero = comprobante(f.letra, f.puntoVentaNumero, f.numeroFactura);
    elemento('ver-titulo').textContent = numero ? `Factura ${numero}` : `Factura ${f.letra} (borrador sin número)`;

    const datos: Array<[string, string]> = [
        ['Estado', f.estado],
        ['Tipo de comprobante', `Factura ${f.letra} (código ARCA ${String(f.codigoComprobante).padStart(2, '0')})`],
        ['Fecha de emisión', fechaLegible(f.fechaEmision)],
        ['Punto de venta', `${String(f.puntoVentaNumero).padStart(4, '0')} - ${f.puntoVentaDescripcion}`],
        ['Cliente', f.clienteDenominacion + (f.clienteCuitCuil ? ` (CUIT ${f.clienteCuitCuil})` : '')],
        ['Condición de IVA', f.condicionIva],
        ['Moneda', f.tipoMoneda],
        ['Lista de precios', f.listaPrecio ?? '—'],
    ];
    if (f.fechaAnulacion) {
        datos.push(['Fecha de anulación', fechaLegible(f.fechaAnulacion)]);
    }
    if (f.estado === 'BORRADOR' && f.motivoRechazo) {
        datos.push(['Último envío a ARCA', f.motivoRechazo]);
    }
    if (f.observaciones) {
        datos.push(['Observaciones', f.observaciones]);
    }
    const ficha = elemento('ver-cabecera');
    ficha.replaceChildren();
    for (const [etiqueta, valor] of datos) {
        const div = document.createElement('div');
        const span = document.createElement('div');
        span.className = 'etiqueta';
        span.textContent = etiqueta;
        div.append(span);
        if (etiqueta === 'Estado') {
            div.append(insignia(valor));
        } else {
            div.append(document.createTextNode(valor));
        }
        ficha.append(div);
    }

    const cuerpo = elemento<HTMLTableSectionElement>('ver-items');
    cuerpo.replaceChildren();
    for (const d of f.detalles) {
        cuerpo.insertRow().append(
            celda(d.articuloCodigo, 'mono'),
            celda(d.descripcion),
            celda(String(d.cantidad), 'num'),
            celda(moneda(d.precioUnitario), 'num'),
            celda(String(d.porcentajeBonificacion), 'num'),
            celda(moneda(d.importeNeto), 'num'),
            celda(moneda(d.importeIva), 'num'),
            celda(moneda(d.importeSubtotal), 'num'),
        );
    }

    const totales = elemento<HTMLTableSectionElement>('ver-totales');
    totales.replaceChildren();
    const fila = totales.insertRow();
    const etiqueta = document.createElement('th');
    etiqueta.colSpan = 5;
    etiqueta.textContent = 'Totales';
    fila.append(etiqueta);
    for (const valor of [f.importeNeto, f.importeIva, f.importeTotal]) {
        const th = document.createElement('th');
        th.className = 'num';
        th.textContent = moneda(valor);
        fila.append(th);
    }

    if (f.cae) {
        elemento('ver-cae').textContent = `CAE ${f.cae}`
            + (f.caeFechaVencimiento ? ` · Vencimiento ${fechaLegible(f.caeFechaVencimiento)}` : '');
    } else {
        elemento('ver-cae').textContent = f.numeroFactura === null
            ? 'Sin CAE: el comprobante todavía no fue autorizado en ARCA.'
            : 'Comprobante sin CAE registrado.';
    }
    elemento('ver-imprimir').dataset.id = String(f.id);
}

function imprimir(id: number): void {
    window.open(facturaService.urlComprobantePdf(id), '_blank', 'noopener');
}

async function autorizarSeleccionada(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f || f.estado !== 'BORRADOR') {
        return;
    }
    const destino = estadoArca?.modo === 'homologacion'
        ? 'a los servidores de homologación de ARCA (WSFEv1)'
        : 'a ARCA (modo simulado)';
    const { confirmado } = await confirmar({
        titulo: `Autorizar Factura ${f.letra} en ARCA`,
        mensaje: `Se envía el borrador de ${f.clienteDenominacion} por ${moneda(f.importeTotal)} ${destino}. `
            + 'Si se aprueba, se le asigna el próximo número de comprobante y un CAE, y ya no podrá editarse ni eliminarse.',
        textoConfirmar: 'Autorizar',
    });
    if (!confirmado) {
        return;
    }
    try {
        const autorizada = await facturaService.autorizarFactura(f.id);
        mostrarMensaje(`Autorizada: Factura ${comprobante(autorizada.letra, autorizada.puntoVentaNumero, autorizada.numeroFactura)}`
            + ` · CAE ${autorizada.cae}`);
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
        if (error instanceof ApiError && error.status === 409) {
            await cargarFacturas(); // muestra la marca "Rechazada por ARCA"
        }
    }
}

async function anularSeleccionada(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f || f.estado !== 'EMITIDA') {
        return;
    }
    const numero = comprobante(f.letra, f.puntoVentaNumero, f.numeroFactura);
    const { confirmado, motivo } = await confirmar({
        titulo: `Anular factura ${numero}`,
        mensaje: 'La factura queda registrada con estado ANULADA y la fecha de anulación de hoy. No podrá volver a modificarse.',
        textoConfirmar: 'Anular',
        pedirMotivo: true,
    });
    if (!confirmado) {
        return;
    }
    try {
        await facturaService.actualizarEstado(f.id, 'ANULADA', motivo || undefined);
        mostrarMensaje(`Factura ${numero} anulada`);
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
    }
}

async function eliminarSeleccionada(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f || f.estado !== 'BORRADOR') {
        return;
    }
    const { confirmado } = await confirmar({
        titulo: 'Eliminar borrador',
        mensaje: `Se borra definitivamente el borrador de ${f.clienteDenominacion} por ${moneda(f.importeTotal)} `
            + 'y todos sus ítems. Como no tiene número de comprobante, puede eliminarse.',
        textoConfirmar: 'Eliminar',
    });
    if (!confirmado) {
        return;
    }
    try {
        await facturaService.eliminarFactura(f.id);
        seleccionadaId = null;
        mostrarMensaje('Borrador eliminado');
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
        if (error instanceof ApiError && error.status === 404) {
            await cargarFacturas(); // ya no existe: refrescar la grilla
        }
    }
}

// =====================================================================
// Modal de alta / edicion con items dinamicos
// =====================================================================

function abrirAlta(): void {
    idEnEdicion = null;
    elemento<HTMLFormElement>('form-alta').reset();
    elemento('modal-factura-titulo').textContent = 'Nueva factura';
    elemento<HTMLInputElement>('alta-fecha').value = hoyIso();
    elegirClienteAlta(null);
    elegirArticulo(null);
    listaPrecioActual = Number(elemento<HTMLSelectElement>('alta-lista-precio').value) || null;
    items = [];
    renderItems();
    abrirModal('modal-factura');
}

function elegirClienteAlta(cliente: ClienteElegido | null): void {
    clienteAlta = cliente;
    elemento<HTMLInputElement>('alta-cliente-texto').value = cliente?.texto ?? '';
    sugerirCondicionIva();
}

async function buscarClienteAlta(): Promise<void> {
    const elegido = await explorarClientes('Seleccionar cliente');
    if (elegido) {
        elegirClienteAlta(elegido.id === 0 ? null : { id: elegido.id, texto: textoCliente(elegido) });
    }
}

function elegirArticulo(articulo: ArticuloPrecioDTO | null): void {
    articuloElegido = articulo;
    elemento<HTMLInputElement>('item-articulo-texto').value = articulo
        ? `${articulo.codigo} - ${articulo.denominacion} · ${moneda(articulo.precio)}`
        : '';
}

/** Primero se determina la lista de precios y despues se elige un articulo DE ESA lista. */
async function buscarArticulo(): Promise<void> {
    const select = elemento<HTMLSelectElement>('alta-lista-precio');
    const listaId = Number(select.value);
    if (!listaId) {
        mostrarMensaje('Elegí primero la lista de precios', 'error');
        select.focus();
        return;
    }
    const nombreLista = select.selectedOptions[0]?.text ?? '';
    const elegido = await abrirExplorer<ArticuloPrecioDTO>({
        titulo: `Artículos de ${nombreLista}`,
        subtitulo: 'Solo se muestran los artículos de la lista de precios elegida, con su precio neto (sin IVA).',
        placeholder: 'Código, descripción, rubro o marca',
        columnas: [
            { titulo: 'Código', valor: (a) => a.codigo, clase: 'mono' },
            { titulo: 'Descripción', valor: (a) => a.denominacion },
            { titulo: 'Rubro', valor: (a) => a.rubro ?? '' },
            { titulo: 'Marca', valor: (a) => a.marca ?? '' },
            { titulo: 'Precio', valor: (a) => moneda(a.precio), clase: 'num' },
        ],
        buscar: (texto) => catalogoService.buscarArticulos(listaId, texto),
    });
    if (elegido) {
        elegirArticulo(elegido);
        elemento<HTMLInputElement>('item-cantidad').focus();
    }
}

/**
 * Vuelve a cotizar los items cargados con los precios de otra lista.
 * Los articulos que no estan en esa lista se quitan. Devuelve las descripciones quitadas.
 */
async function recotizarItems(listaId: number): Promise<string[]> {
    const precios = new Map((await catalogoService.buscarArticulos(listaId, ''))
        .map((a) => [a.articuloId, a.precio] as const));
    const quitados = items.filter((i) => !precios.has(i.articuloId)).map((i) => i.descripcion);
    items = items.filter((i) => precios.has(i.articuloId));
    for (const item of items) {
        item.precioUnitario = precios.get(item.articuloId) ?? item.precioUnitario;
    }
    listaPrecioActual = listaId;
    renderItems();
    return quitados;
}

async function alCambiarListaPrecio(): Promise<void> {
    const select = elemento<HTMLSelectElement>('alta-lista-precio');
    const listaId = Number(select.value);
    elegirArticulo(null); // el articulo elegido era de la otra lista
    if (items.length === 0 || listaId === listaPrecioActual) {
        listaPrecioActual = listaId;
        return;
    }
    try {
        const quitados = await recotizarItems(listaId);
        mostrarMensaje(quitados.length === 0
            ? `Ítems recotizados con ${select.selectedOptions[0]?.text}`
            : `Ítems recotizados. Se quitaron por no estar en la lista: ${quitados.join(', ')}`,
        quitados.length === 0 ? 'ok' : 'info');
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
    }
}

async function abrirEdicion(): Promise<void> {
    const f = facturaSeleccionada();
    if (!f || f.estado !== 'BORRADOR') {
        return;
    }
    try {
        const factura = await facturaService.obtenerFactura(f.id);
        idEnEdicion = factura.id;
        elemento('modal-factura-titulo').textContent = 'Editar borrador';
        elemento<HTMLInputElement>('alta-fecha').value = factura.fechaEmision;
        elemento<HTMLSelectElement>('alta-punto-venta').value = String(factura.puntoVentaId);
        elemento<HTMLSelectElement>('alta-condicion-iva').value = String(factura.condicionIvaId);
        clienteAlta = factura.clienteId === null ? null
            : { id: factura.clienteId, texto: `${factura.clienteDenominacion} (${factura.clienteCuitCuil ?? ''})` };
        elemento<HTMLInputElement>('alta-cliente-texto').value = clienteAlta?.texto ?? '';
        elegirArticulo(null);
        elemento<HTMLSelectElement>('alta-tipo-moneda').value = String(factura.tipoMonedaId);
        elemento<HTMLInputElement>('alta-observaciones').value = factura.observaciones ?? '';
        items = factura.detalles.map((d) => ({
            articuloId: d.articuloId,
            descripcion: `${d.articuloCodigo} - ${d.descripcion}`,
            precioUnitario: d.precioUnitario,
            cantidad: d.cantidad,
            porcentajeBonificacion: d.porcentajeBonificacion,
        }));
        const select = elemento<HTMLSelectElement>('alta-lista-precio');
        if (factura.listaPrecioId !== null) {
            select.value = String(factura.listaPrecioId);
        }
        // Al guardar, el servidor toma el precio vigente de la lista:
        // la vista previa usa ese mismo precio para que los importes coincidan.
        await recotizarItems(Number(select.value));
        abrirModal('modal-factura');
    } catch (error) {
        mostrarMensaje(describirError(error), 'error');
    }
}

function agregarItem(): void {
    const inputCantidad = elemento<HTMLInputElement>('item-cantidad');
    const inputBonif = elemento<HTMLInputElement>('item-bonificacion');

    const articulo = articuloElegido;
    const cantidad = Number(inputCantidad.value);
    const bonificacion = Number(inputBonif.value || 0);

    if (!articulo) {
        mostrarMensaje('Buscá y seleccioná un artículo de la lista de precios', 'error');
        elemento('btn-item-articulo').focus();
        return;
    }
    if (!(cantidad > 0)) {
        mostrarMensaje('La cantidad debe ser mayor a 0', 'error');
        inputCantidad.focus();
        return;
    }
    if (bonificacion < 0 || bonificacion > 100) {
        mostrarMensaje('La bonificación debe estar entre 0 y 100', 'error');
        inputBonif.focus();
        return;
    }

    items.push({
        articuloId: articulo.articuloId,
        descripcion: `${articulo.codigo} - ${articulo.denominacion}`,
        precioUnitario: articulo.precio,
        cantidad,
        porcentajeBonificacion: bonificacion,
    });
    listaPrecioActual = Number(elemento<HTMLSelectElement>('alta-lista-precio').value);
    inputCantidad.value = '1';
    inputBonif.value = '0';
    elegirArticulo(null);
    renderItems();
}

function inputNumerico(valor: number, indice: number, campo: 'cantidad' | 'porcentajeBonificacion',
                       min: number, max?: number): HTMLInputElement {
    const input = document.createElement('input');
    input.type = 'number';
    input.step = '0.01';
    input.min = String(min);
    if (max !== undefined) {
        input.max = String(max);
    }
    input.value = String(valor);
    input.dataset.indice = String(indice);
    input.dataset.campo = campo;
    input.setAttribute('aria-label', campo === 'cantidad' ? 'Cantidad' : 'Bonificación %');
    return input;
}

function renderItems(): void {
    const cuerpo = elemento<HTMLTableSectionElement>('items-cuerpo');
    cuerpo.replaceChildren();

    if (items.length === 0) {
        const td = celda('Todavía no agregaste ítems.', 'vacia');
        td.colSpan = 8;
        cuerpo.insertRow().append(td);
    }

    let totalNeto = 0;
    let totalIva = 0;
    let total = 0;

    items.forEach((item, indice) => {
        const { neto, iva, subtotal } = calcularImportes(item);
        totalNeto += neto;
        totalIva += iva;
        total += subtotal;

        const fila = cuerpo.insertRow();
        fila.append(celda(item.descripcion));

        const tdCantidad = celda('', 'num');
        tdCantidad.append(inputNumerico(item.cantidad, indice, 'cantidad', 0.01));
        fila.append(tdCantidad);

        fila.append(celda(moneda(item.precioUnitario), 'num'));

        const tdBonif = celda('', 'num');
        tdBonif.append(inputNumerico(item.porcentajeBonificacion, indice, 'porcentajeBonificacion', 0, 100));
        fila.append(tdBonif);

        fila.append(celda(moneda(neto), 'num'), celda(moneda(iva), 'num'), celda(moneda(subtotal), 'num'));

        const tdQuitar = celda('');
        tdQuitar.append(boton('Quitar', 'btn-peligro', { accion: 'quitar', indice: String(indice) }));
        fila.append(tdQuitar);
    });

    elemento('total-neto').textContent = moneda(redondear(totalNeto));
    elemento('total-iva').textContent = moneda(redondear(totalIva));
    elemento('total-general').textContent = moneda(redondear(total));
}

/** Edicion en linea de cantidad / bonificacion. */
function alCambiarItem(evento: Event): void {
    const input = evento.target as HTMLInputElement;
    const item = items[Number(input.dataset.indice)];
    const campo = input.dataset.campo;
    if (!item || (campo !== 'cantidad' && campo !== 'porcentajeBonificacion')) {
        return;
    }
    const valor = Number(input.value);
    const valido = campo === 'cantidad' ? valor > 0 : valor >= 0 && valor <= 100;
    if (valido) {
        item[campo] = valor;
    } else {
        mostrarMensaje(campo === 'cantidad'
            ? 'La cantidad debe ser mayor a 0'
            : 'La bonificación debe estar entre 0 y 100', 'error');
    }
    renderItems();
}

function alClickItems(evento: Event): void {
    const btn = (evento.target as HTMLElement).closest<HTMLButtonElement>('button[data-accion="quitar"]');
    if (btn) {
        items.splice(Number(btn.dataset.indice), 1);
        renderItems();
    }
}

async function guardarFactura(evento: SubmitEvent): Promise<void> {
    evento.preventDefault();
    const fecha = elemento<HTMLInputElement>('alta-fecha').value;
    if (!fecha) {
        mostrarMensaje('Indicá la fecha de emisión', 'error');
        return;
    }
    if (items.length === 0) {
        mostrarMensaje('Agregá al menos un ítem a la factura', 'error');
        return;
    }

    const observaciones = elemento<HTMLInputElement>('alta-observaciones').value.trim();
    const detalles: FacturaDetalleRequestDTO[] = items.map((item) => ({
        articuloId: item.articuloId,
        cantidad: item.cantidad,
        porcentajeBonificacion: item.porcentajeBonificacion,
    }));

    const factura: FacturaRequestDTO = {
        fechaEmision: fecha,
        puntoVentaId: Number(elemento<HTMLSelectElement>('alta-punto-venta').value),
        condicionIvaId: Number(elemento<HTMLSelectElement>('alta-condicion-iva').value),
        tipoMonedaId: Number(elemento<HTMLSelectElement>('alta-tipo-moneda').value),
        listaPrecioId: Number(elemento<HTMLSelectElement>('alta-lista-precio').value),
        detalles,
    };

    const btn = elemento<HTMLButtonElement>('btn-guardar');
    btn.disabled = true;
    try {
        let guardada: FacturaReporteDTO;
        if (idEnEdicion === null) {
            factura.clienteId = clienteAlta?.id ?? null;
            factura.observaciones = observaciones || undefined;
            guardada = await facturaService.crearFactura(factura);
            mostrarMensaje(`Borrador guardado por ${moneda(guardada.importeTotal)}. `
                + 'Usá "Autorizar en ARCA" para obtener número y CAE.');
        } else {
            factura.clienteId = clienteAlta?.id ?? 0; // en PUT, 0 = Consumidor Final
            factura.observaciones = observaciones; // "" borra las observaciones
            guardada = await facturaService.actualizarFactura(idEnEdicion, factura);
            mostrarMensaje(`Borrador actualizado (${moneda(guardada.importeTotal)})`);
        }
        cerrarModal('modal-factura');
        seleccionadaId = guardada.id;
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(`No se pudo guardar: ${describirError(error)}`, 'error');
    } finally {
        btn.disabled = false;
    }
}

// =====================================================================
// Filtros
// =====================================================================

function leerFiltros(): FacturaFiltrosDTO | null {
    const valor = (id: string): string => elemento<HTMLInputElement | HTMLSelectElement>(id).value.trim();
    const fechaDesde = valor('filtro-fecha-desde');
    const fechaHasta = valor('filtro-fecha-hasta');
    const montoMinimo = valor('filtro-monto-minimo');
    const montoMaximo = valor('filtro-monto-maximo');

    if (fechaDesde && fechaHasta && fechaDesde > fechaHasta) {
        mostrarMensaje('"Fecha desde" no puede ser posterior a "Fecha hasta"', 'error');
        return null;
    }
    if (montoMinimo && montoMaximo && Number(montoMinimo) > Number(montoMaximo)) {
        mostrarMensaje('El monto mínimo no puede ser mayor al monto máximo', 'error');
        return null;
    }

    const filtros: FacturaFiltrosDTO = {};
    if (fechaDesde) filtros.fechaDesde = fechaDesde;
    if (fechaHasta) filtros.fechaHasta = fechaHasta;
    if (valor('filtro-estado')) filtros.estado = valor('filtro-estado');
    if (clienteFiltro) filtros.clienteId = clienteFiltro.id; // 0 = solo Consumidor Final
    if (valor('filtro-punto-venta')) filtros.puntoVentaId = Number(valor('filtro-punto-venta'));
    if (valor('filtro-numero')) filtros.numero = Number(valor('filtro-numero'));
    if (montoMinimo) filtros.montoMinimo = Number(montoMinimo);
    if (montoMaximo) filtros.montoMaximo = Number(montoMaximo);
    return filtros;
}

function elegirClienteFiltro(cliente: ClienteElegido | null): void {
    clienteFiltro = cliente;
    elemento<HTMLInputElement>('filtro-cliente-texto').value = cliente?.texto ?? '';
}

async function buscarClienteFiltro(): Promise<void> {
    const elegido = await explorarClientes('Filtrar por cliente');
    if (elegido) {
        elegirClienteFiltro({ id: elegido.id, texto: textoCliente(elegido) });
    }
}

function actualizarLinksReporte(): void {
    elemento<HTMLAnchorElement>('link-pdf').href = facturaService.urlReporte('pdf', filtrosActuales);
    elemento<HTMLAnchorElement>('link-excel').href = facturaService.urlReporte('excel', filtrosActuales);
}

// =====================================================================
// Estado de ARCA (indicador del encabezado)
// =====================================================================

async function cargarEstadoArca(): Promise<void> {
    const indicador = elemento('estado-arca');
    try {
        estadoArca = await arcaService.obtenerEstado();
        if (estadoArca.modo === 'simulado') {
            indicador.textContent = 'ARCA: modo simulado';
            indicador.className = 'indicador-arca';
        } else {
            indicador.textContent = estadoArca.servidoresOk
                ? `ARCA homologación · CUIT ${estadoArca.cuit} · servidores OK`
                : 'ARCA homologación · sin conexión';
            indicador.className = `indicador-arca ${estadoArca.servidoresOk ? 'ok' : 'error'}`;
        }
        indicador.title = estadoArca.detalle;
    } catch {
        indicador.textContent = 'ARCA: estado desconocido';
        indicador.className = 'indicador-arca error';
    }
}

// =====================================================================
// Inicio: conectar eventos y cargar datos
// =====================================================================

function conectarEventos(): void {
    // filtros
    const formFiltros = elemento<HTMLFormElement>('form-filtros');
    formFiltros.addEventListener('submit', (e) => {
        e.preventDefault();
        const filtros = leerFiltros();
        if (filtros) {
            filtrosActuales = filtros;
            void cargarFacturas();
        }
    });
    formFiltros.addEventListener('reset', () => {
        elegirClienteFiltro(null);
        filtrosActuales = {};
        void cargarFacturas();
    });

    // grilla
    const grilla = elemento<HTMLTableElement>('tabla-facturas');
    grilla.addEventListener('click', alClickGrilla);
    grilla.addEventListener('dblclick', alDobleClickGrilla);
    grilla.addEventListener('keydown', alTeclaGrilla);

    // barra de herramientas
    elemento('btn-nueva').addEventListener('click', abrirAlta);
    elemento('btn-ver').addEventListener('click', () => void verFactura());
    elemento('btn-editar').addEventListener('click', () => void abrirEdicion());
    elemento('btn-autorizar').addEventListener('click', () => void autorizarSeleccionada());
    elemento('btn-imprimir').addEventListener('click', () => seleccionadaId !== null && imprimir(seleccionadaId));
    elemento('btn-anular').addEventListener('click', () => void anularSeleccionada());
    elemento('btn-eliminar').addEventListener('click', () => void eliminarSeleccionada());

    // modal de alta/edicion
    elemento('btn-alta-cliente').addEventListener('click', () => void buscarClienteAlta());
    elemento('btn-alta-cliente-quitar').addEventListener('click', () => elegirClienteAlta(null));
    elemento('alta-lista-precio').addEventListener('change', () => void alCambiarListaPrecio());
    elemento('btn-item-articulo').addEventListener('click', () => void buscarArticulo());
    elemento('btn-filtro-cliente').addEventListener('click', () => void buscarClienteFiltro());
    elemento('btn-filtro-cliente-quitar').addEventListener('click', () => elegirClienteFiltro(null));
    elemento('btn-agregar-item').addEventListener('click', agregarItem);
    elemento('items-cuerpo').addEventListener('change', alCambiarItem);
    elemento('items-cuerpo').addEventListener('click', alClickItems);
    elemento<HTMLFormElement>('form-alta').addEventListener('submit', (e) => void guardarFactura(e));

    // modal ver
    elemento('ver-imprimir').addEventListener('click', (e) => {
        imprimir(Number((e.currentTarget as HTMLElement).dataset.id));
    });

    // botones "Cerrar" / "Cancelar" / X de los modales
    for (const btn of document.querySelectorAll<HTMLButtonElement>('[data-cerrar]')) {
        btn.addEventListener('click', () => btn.closest('dialog')?.close());
    }
}

async function iniciar(): Promise<void> {
    conectarEventos();
    renderItems();
    void cargarEstadoArca();
    try {
        await cargarCatalogo();
    } catch (error) {
        mostrarMensaje(`No se pudieron cargar los datos del formulario: ${describirError(error)}`, 'error');
    }
    await cargarFacturas();
}

void iniciar();
