// =====================================================================
// Interfaces espejo de los DTOs de Spring Boot (paquete com.example.dto)
// Mismos nombres de campo que en Java. Equivalencias de tipos:
//   Long / long / int / Double / double -> number
//   String                              -> string
//   Date / LocalDate (yyyy-MM-dd)       -> string  (Jackson la serializa como texto)
//   List<T>                             -> T[]
//   Campo que puede venir null          -> "| null"  (o opcional "?" en los request)
// =====================================================================

/** BORRADOR (sin numero) -> EMITIDA (autorizada por ARCA) -> ANULADA */
export type EstadoFactura = 'BORRADOR' | 'EMITIDA' | 'ANULADA';

/** Espejo de FacturaReporteDTO (fila del listado; respuesta de POST, PUT y autorizar). */
export interface FacturaReporteDTO {
    id: number;                      // Long
    letra: 'A' | 'B';                // String (tipo de comprobante segun la condicion de IVA del receptor)
    numeroFactura: number | null;    // Long (null mientras es BORRADOR)
    fechaEmision: string;            // Date -> "yyyy-MM-dd"
    clienteDenominacion: string;     // String ("Consumidor Final" si no tiene cliente)
    condicionIva: string;            // String
    puntoVentaDescripcion: string;   // String
    puntoVentaNumero: number;        // int
    importeTotal: number;            // double
    cantidadItems: number;           // long
    estado: EstadoFactura;           // String
    observaciones: string | null;    // String
    cae: string | null;              // String
    resultadoAfip: string | null;    // String (A = aprobada, R = ultimo intento rechazado, null = sin enviar)
}

/** Espejo de FacturaItemDTO (renglon de una factura guardada). */
export interface FacturaItemDTO {
    listaPrecioArticuloId: number;   // Long
    articuloId: number;              // Long
    articuloCodigo: string;          // String
    descripcion: string;             // String
    cantidad: number;                // double
    precioUnitario: number;          // double
    porcentajeBonificacion: number;  // double
    importeNeto: number;             // double
    importeIva: number;              // double
    importeSubtotal: number;         // double
}

/** Espejo de FacturaCompletaDTO (GET /api/facturas/{id}: cabecera + items). */
export interface FacturaCompletaDTO {
    id: number;
    letra: 'A' | 'B';
    codigoComprobante: number;       // int (1 = Factura A, 6 = Factura B)
    numeroFactura: number | null;
    estado: EstadoFactura;
    fechaEmision: string;
    puntoVentaId: number;
    puntoVentaNumero: number;
    puntoVentaDescripcion: string;
    clienteId: number | null;
    clienteDenominacion: string;
    clienteCuitCuil: string | null;
    clienteDomicilio: string | null;
    condicionIvaId: number;
    condicionIva: string;
    tipoMonedaId: number;
    tipoMoneda: string;
    simboloMoneda: string;
    listaPrecioId: number | null;
    listaPrecio: string | null;
    importeNeto: number;
    importeIva: number;
    importeTotal: number;
    cae: string | null;
    resultadoAfip: string | null;
    motivoRechazo: string | null;
    caeFechaVencimiento: string | null;
    fechaAnulacion: string | null;
    observaciones: string | null;
    detalles: FacturaItemDTO[];
}

/** Espejo de FacturaDetalleRequestDTO (un renglon del POST / PUT). */
export interface FacturaDetalleRequestDTO {
    articuloId: number;              // Long
    cantidad: number;                // Double
    porcentajeBonificacion?: number; // Double (opcional, 0 por defecto)
    descripcion?: string;            // String (opcional)
}

/**
 * Espejo de FacturaRequestDTO (cuerpo de POST y PUT).
 * POST: puntoVentaId, condicionIvaId, tipoMonedaId y detalles son obligatorios.
 * PUT : todo es opcional; el backend solo cambia lo que viene.
 */
export interface FacturaRequestDTO {
    fechaEmision?: string;           // LocalDate -> "yyyy-MM-dd"
    clienteId?: number | null;       // Long (null = Consumidor Final; en PUT 0 = pasar a Consumidor Final)
    condicionIvaId?: number;         // Long
    puntoVentaId?: number;           // Long
    tipoMonedaId?: number;           // Long
    listaPrecioId?: number;          // Long (lista de la que salen los articulos de los detalles)
    estado?: string;                 // String
    observaciones?: string;          // String
    detalles?: FacturaDetalleRequestDTO[]; // List<FacturaDetalleRequestDTO>
}

/** Espejo de FacturaFiltrosDTO (query params de GET /api/facturas). */
export interface FacturaFiltrosDTO {
    fechaDesde?: string;             // Date -> "yyyy-MM-dd"
    fechaHasta?: string;             // Date -> "yyyy-MM-dd"
    estado?: string;                 // String
    montoMinimo?: number;            // Double
    montoMaximo?: number;            // Double
    clienteId?: number;              // Long (0 = solo Consumidor Final)
    puntoVentaId?: number;           // Long
    numero?: number;                 // Long
}

/** Espejo de ItemCatalogoDTO (opcion de un combo). */
export interface ItemCatalogoDTO {
    id: number;                      // Long
    descripcion: string;             // String
}

/** Espejo de CatalogoDTO (respuesta de GET /api/catalogos). */
export interface CatalogoDTO {
    condicionesIva: ItemCatalogoDTO[];
    puntosVenta: ItemCatalogoDTO[];
    tiposMoneda: ItemCatalogoDTO[];
    listasPrecio: ItemCatalogoDTO[];
    alicuotaIva: number;             // double
}

/** Espejo de ClienteExplorerDTO (fila del explorer de clientes: GET /api/clientes?q=). */
export interface ClienteExplorerDTO {
    id: number;                      // Long
    cuitCuil: string;                // String
    denominacion: string;            // String
    domicilio: string | null;        // String
    email: string | null;            // String
    telefono: string | null;         // String
}

/** Espejo de ArticuloPrecioDTO (fila del explorer de articulos: GET /api/listas-precio/{id}/articulos?q=). */
export interface ArticuloPrecioDTO {
    listaPrecioArticuloId: number;   // Long
    articuloId: number;              // Long
    codigo: string;                  // String
    denominacion: string;            // String
    rubro: string | null;            // String
    marca: string | null;            // String
    precio: number;                  // double (neto, en la lista elegida)
}

/** Espejo de ArcaEstadoDTO (GET /api/arca/estado). */
export interface ArcaEstadoDTO {
    modo: 'simulado' | 'homologacion'; // String
    cuit: number | null;             // Long
    wsfeUrl: string | null;          // String
    servidoresOk: boolean | null;    // Boolean (resultado de FEDummy)
    detalle: string;                 // String
}

/** Cuerpo de error que arma GlobalExceptionHandler. */
export interface ErrorApiDTO {
    timestamp: string;
    status: number;
    error: string;
    mensaje: string;
}
