import type { ArticuloPrecioDTO, CatalogoDTO, ClienteExplorerDTO } from '../models/factura.dto.js';
import { ApiError } from './ApiError.js';

/** Combos del formulario y busquedas de los explorers de clientes y articulos. */
export class CatalogoService {

    constructor(private readonly baseUrl: string = 'http://localhost:8080/api') {}

    /** GET /api/catalogos -> condiciones de IVA, puntos de venta, monedas y listas de precios. */
    async obtenerCatalogo(): Promise<CatalogoDTO> {
        return this.get<CatalogoDTO>(`${this.baseUrl}/catalogos`);
    }

    /** GET /api/clientes?q= -> explorer de clientes (razon social o CUIT). */
    async buscarClientes(texto: string): Promise<ClienteExplorerDTO[]> {
        return this.get<ClienteExplorerDTO[]>(`${this.baseUrl}/clientes?q=${encodeURIComponent(texto)}`);
    }

    /** GET /api/listas-precio/{id}/articulos?q= -> articulos de esa lista con su precio. */
    async buscarArticulos(listaPrecioId: number, texto: string): Promise<ArticuloPrecioDTO[]> {
        return this.get<ArticuloPrecioDTO[]>(
            `${this.baseUrl}/listas-precio/${listaPrecioId}/articulos?q=${encodeURIComponent(texto)}`);
    }

    private async get<T>(url: string): Promise<T> {
        const respuesta = await fetch(url);
        await ApiError.verificar(respuesta);
        return (await respuesta.json()) as T;
    }
}
