import type { ArcaEstadoDTO } from '../models/factura.dto.js';
import { ApiError } from './ApiError.js';

/** Estado de la conexión con ARCA (GET /api/arca/estado). */
export class ArcaService {

    constructor(private readonly baseUrl: string = 'http://localhost:8080/api/arca') {}

    async obtenerEstado(): Promise<ArcaEstadoDTO> {
        const respuesta = await fetch(`${this.baseUrl}/estado`);
        await ApiError.verificar(respuesta);
        return (await respuesta.json()) as ArcaEstadoDTO;
    }
}
