import type {
    FacturaCompletaDTO,
    FacturaFiltrosDTO,
    FacturaReporteDTO,
    FacturaRequestDTO,
} from '../models/factura.dto.js';
import { ApiError } from './ApiError.js';

/**
 * Cliente HTTP de la API de facturas.
 * Centraliza todas las llamadas a http://localhost:8080/api/facturas usando fetch + async/await.
 */
export class FacturaService {

    private static readonly JSON_HEADERS = { 'Content-Type': 'application/json' };

    constructor(private readonly baseUrl: string = 'http://localhost:8080/api/facturas') {}

    // ---------------- Metodos pedidos en la consigna ----------------

    /** GET /api/facturas?filtros -> 200 OK con la lista. */
    async obtenerFacturas(filtros: FacturaFiltrosDTO = {}): Promise<FacturaReporteDTO[]> {
        const respuesta = await fetch(this.urlConFiltros(this.baseUrl, filtros));
        await ApiError.verificar(respuesta);
        return (await respuesta.json()) as FacturaReporteDTO[];
    }

    /** POST /api/facturas -> 201 Created con la factura creada (queda como BORRADOR, sin numero). */
    async crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        return this.enviar<FacturaReporteDTO>(this.baseUrl, 'POST', factura);
    }

    /** PUT /api/facturas/{id} con { estado, observaciones } -> 200 OK (se usa para anular). */
    async actualizarEstado(id: number, estado: string, observaciones?: string): Promise<FacturaReporteDTO> {
        const cuerpo: FacturaRequestDTO = { estado };
        if (observaciones !== undefined) {
            cuerpo.observaciones = observaciones;
        }
        return this.enviar<FacturaReporteDTO>(`${this.baseUrl}/${id}`, 'PUT', cuerpo);
    }

    /** DELETE /api/facturas/{id} -> 204 No Content (solo facturas sin numero). */
    async eliminarFactura(id: number): Promise<void> {
        const respuesta = await fetch(`${this.baseUrl}/${id}`, { method: 'DELETE' });
        await ApiError.verificar(respuesta);
    }

    // ---------------- Metodos adicionales del explorer ----------------

    /** GET /api/facturas/{id} -> cabecera + items. */
    async obtenerFactura(id: number): Promise<FacturaCompletaDTO> {
        const respuesta = await fetch(`${this.baseUrl}/${id}`);
        await ApiError.verificar(respuesta);
        return (await respuesta.json()) as FacturaCompletaDTO;
    }

    /** PUT /api/facturas/{id} con cabecera y/o items (edicion de un borrador). */
    async actualizarFactura(id: number, factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        return this.enviar<FacturaReporteDTO>(`${this.baseUrl}/${id}`, 'PUT', factura);
    }

    /** POST /api/facturas/{id}/autorizar -> ARCA asigna numero y CAE. */
    async autorizarFactura(id: number): Promise<FacturaReporteDTO> {
        return this.enviar<FacturaReporteDTO>(`${this.baseUrl}/${id}/autorizar`, 'POST');
    }

    /** URL del PDF de una factura (GET /api/facturas/{id}/pdf). */
    urlComprobantePdf(id: number): string {
        return `${this.baseUrl}/${id}/pdf`;
    }

    /** URL de descarga del reporte (GET /api/facturas/pdf | /excel) con los mismos filtros. */
    urlReporte(formato: 'pdf' | 'excel', filtros: FacturaFiltrosDTO = {}): string {
        return this.urlConFiltros(`${this.baseUrl}/${formato}`, filtros);
    }

    // ---------------- Auxiliares ----------------

    private async enviar<T>(url: string, method: 'POST' | 'PUT', cuerpo?: unknown): Promise<T> {
        const respuesta = await fetch(url, {
            method,
            headers: FacturaService.JSON_HEADERS,
            body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
        });
        await ApiError.verificar(respuesta);
        return (await respuesta.json()) as T;
    }

    /** Arma la query string omitiendo los filtros vacios. */
    private urlConFiltros(url: string, filtros: FacturaFiltrosDTO): string {
        const params = new URLSearchParams();
        for (const [clave, valor] of Object.entries(filtros)) {
            if (valor !== undefined && valor !== null && String(valor).trim() !== '') {
                params.append(clave, String(valor));
            }
        }
        const query = params.toString();
        return query ? `${url}?${query}` : url;
    }
}
