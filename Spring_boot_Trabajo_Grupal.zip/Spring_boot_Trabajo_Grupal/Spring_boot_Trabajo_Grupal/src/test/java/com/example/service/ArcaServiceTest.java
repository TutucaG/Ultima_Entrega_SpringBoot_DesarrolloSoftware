package com.example.service;

import com.example.arca.ArcaConfig;
import com.example.arca.WsaaClient;
import com.example.arca.WsfeClient;
import com.example.entidades.*;
import com.example.exception.ReglaNegocioException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

// Flujo de homologacion de la guia (WSAA -> FECompUltimoAutorizado -> FECAESolicitar) con clientes simulados
class ArcaServiceTest {

    private WsaaClient wsaa;
    private WsfeClient wsfe;
    private ArcaService service;
    private final WsaaClient.TicketAcceso ticket =
            new WsaaClient.TicketAcceso("token", "sign", Instant.now().plusSeconds(3600));

    @BeforeEach
    void preparar() {
        ArcaConfig config = mock(ArcaConfig.class);
        when(config.esModoReal()).thenReturn(true);
        wsaa = mock(WsaaClient.class);
        wsfe = mock(WsfeClient.class);
        when(wsaa.obtenerTicket()).thenReturn(ticket);
        service = new ArcaService(config, wsaa, wsfe);
    }

    private FacturaVenta factura(int codigoCondicionIva, String cuitCliente) {
        PuntoVenta pv = new PuntoVenta();
        pv.setId(1L);
        pv.setNumero(2);
        CondicionIva ci = new CondicionIva();
        ci.setCodigoAfip(codigoCondicionIva);
        TipoMoneda pesos = new TipoMoneda();
        pesos.setCodigoAfip("PES");

        FacturaVenta f = new FacturaVenta();
        f.setPuntoVenta(pv);
        f.setCondicionIva(ci);
        f.setTipoMoneda(pesos);
        f.setFechaEmision(java.sql.Date.valueOf(LocalDate.now()));
        if (cuitCliente != null) {
            Cliente c = new Cliente();
            c.setCuitCuil(cuitCliente);
            f.setCliente(c);
        }
        FacturaVentaDetalle d = new FacturaVentaDetalle();
        d.setImporteNeto(1000.0);
        d.setImporteIva(210.0);
        d.setImporteSubtotal(1210.0);
        f.setDetalles(new ArrayList<>(List.of(d)));
        f.setImporteTotal(1210.0);
        return f;
    }

    @Test
    void homologacion_facturaA_pideUltimoNumeroYSolicitaCaeConCuit() {
        when(wsfe.ultimoAutorizado(ticket, 2, 1)).thenReturn(41L);
        when(wsfe.solicitarCae(eq(ticket), any())).thenReturn(new WsfeClient.RespuestaCae(
                "A", "76440000000001", LocalDate.now().plusDays(10), 42, List.of()));

        ArcaService.Autorizacion a = service.autorizar(factura(1, "30-12345678-9"), () -> fail("no usa la numeración local"));

        assertEquals(42, a.numero());
        assertEquals("76440000000001", a.cae());

        ArgumentCaptor<WsfeClient.SolicitudCae> captor = ArgumentCaptor.forClass(WsfeClient.SolicitudCae.class);
        verify(wsfe).solicitarCae(eq(ticket), captor.capture());
        WsfeClient.SolicitudCae s = captor.getValue();
        assertEquals(1, s.tipoComprobante());           // Factura A
        assertEquals(42, s.numero());                   // ultimo + 1
        assertEquals(WsfeClient.DOC_CUIT, s.docTipo());
        assertEquals(30123456789L, s.docNro());
        assertEquals(1000.0, s.neto());
        assertEquals(210.0, s.iva());
        assertEquals("PES", s.moneda());
    }

    @Test
    void homologacion_consumidorFinal_esFacturaBSinDocumento() {
        when(wsfe.ultimoAutorizado(ticket, 2, 6)).thenReturn(0L);
        when(wsfe.solicitarCae(eq(ticket), any())).thenReturn(new WsfeClient.RespuestaCae(
                "A", "76440000000002", LocalDate.now().plusDays(10), 1, List.of()));

        service.autorizar(factura(5, null), () -> 0);

        ArgumentCaptor<WsfeClient.SolicitudCae> captor = ArgumentCaptor.forClass(WsfeClient.SolicitudCae.class);
        verify(wsfe).solicitarCae(eq(ticket), captor.capture());
        assertEquals(6, captor.getValue().tipoComprobante());
        assertEquals(WsfeClient.DOC_SIN_IDENTIFICAR, captor.getValue().docTipo());
        assertEquals(0, captor.getValue().docNro());
        assertEquals(5, captor.getValue().condicionIvaReceptor());
    }

    @Test
    void homologacion_rechazoDeArca_lanzaReglaNegocioConLosMensajes() {
        when(wsfe.ultimoAutorizado(any(), anyInt(), anyInt())).thenReturn(0L);
        when(wsfe.solicitarCae(any(), any())).thenReturn(new WsfeClient.RespuestaCae(
                "R", null, null, 0, List.of("10016 - La fecha del comprobante es invalida")));

        ReglaNegocioException e = assertThrows(ReglaNegocioException.class,
                () -> service.autorizar(factura(5, null), () -> 0));
        assertTrue(e.getMessage().contains("10016"));
    }

    @Test
    void facturaASinCuit_seRechazaAntesDeLlamarAArca() {
        assertThrows(ReglaNegocioException.class, () -> service.autorizar(factura(1, null), () -> 0));
        verifyNoInteractions(wsaa, wsfe);
    }
}
