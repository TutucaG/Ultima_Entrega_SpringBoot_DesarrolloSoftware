package com.example.arca;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.bouncycastle.openssl.jcajce.JcaPKCS8Generator;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.Writer;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Base64;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

// Prueba la parte criptografica de WSAA con un certificado autofirmado (sin conectarse a ARCA)
class WsaaClientTest {

    private static KeyPair claves;
    private static X509Certificate certificado;

    @BeforeAll
    static void generarCertificadoDePrueba() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        KeyPairGenerator generador = KeyPairGenerator.getInstance("RSA");
        generador.initialize(2048);
        claves = generador.generateKeyPair();

        X500Name sujeto = new X500Name("C=AR, O=TEST, CN=TEST, SERIALNUMBER=CUIT 20111111112");
        Instant ahora = Instant.now();
        X509CertificateHolder holder = new JcaX509v3CertificateBuilder(sujeto, BigInteger.ONE,
                Date.from(ahora.minusSeconds(60)), Date.from(ahora.plusSeconds(3600)), sujeto, claves.getPublic())
                .build(new JcaContentSignerBuilder("SHA256withRSA").build(claves.getPrivate()));
        certificado = new JcaX509CertificateConverter().getCertificate(holder);
    }

    @Test
    void generarTra_tieneServicioYVentanaDeValidez() {
        ZonedDateTime ahora = ZonedDateTime.of(2026, 11, 3, 10, 0, 0, 0, ZoneId.of("America/Argentina/Buenos_Aires"));
        String tra = WsaaClient.generarTra(ahora, "wsfe");

        assertTrue(tra.contains("<service>wsfe</service>"));
        assertTrue(tra.contains("<generationTime>2026-11-03T09:55:00-03:00</generationTime>"));
        assertTrue(tra.contains("<expirationTime>2026-11-03T10:10:00-03:00</expirationTime>"));
        assertTrue(tra.contains("<uniqueId>" + ahora.toEpochSecond() + "</uniqueId>"));
    }

    @Test
    void firmarCms_generaUnaFirmaValidaQueContieneElTra() throws Exception {
        String tra = WsaaClient.generarTra(ZonedDateTime.now(), "wsfe");

        String cmsBase64 = WsaaClient.firmarCms(tra, claves.getPrivate(), certificado);

        CMSSignedData cms = new CMSSignedData(Base64.getDecoder().decode(cmsBase64));
        assertEquals(tra, new String((byte[]) cms.getSignedContent().getContent(), StandardCharsets.UTF_8));
        assertEquals(1, cms.getCertificates().getMatches(null).size(), "incluye el certificado");
        SignerInformation firmante = cms.getSignerInfos().getSigners().iterator().next();
        assertTrue(firmante.verify(new JcaSimpleSignerInfoVerifierBuilder().setProvider("BC").build(certificado)));
    }

    @Test
    void leerRespuestaLogin_extraeTokenSignYVencimiento() {
        String ticket = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><loginTicketResponse version=\"1.0\">"
                + "<header><source>CN=wsaahomo</source><expirationTime>2026-11-03T22:00:00.000-03:00</expirationTime></header>"
                + "<credentials><token>TOKEN123</token><sign>SIGN456</sign></credentials></loginTicketResponse>";
        String escapado = ticket.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        String soap = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body>"
                + "<loginCmsResponse xmlns=\"http://wsaa.view.sua.dvadac.desein.afip.gov\"><loginCmsReturn>"
                + escapado + "</loginCmsReturn></loginCmsResponse></soapenv:Body></soapenv:Envelope>";

        WsaaClient.TicketAcceso t = WsaaClient.leerRespuestaLogin(soap);

        assertEquals("TOKEN123", t.token());
        assertEquals("SIGN456", t.sign());
        assertEquals(Instant.parse("2026-11-04T01:00:00Z"), t.expiracion());
    }

    @Test
    void cargarClavePrivada_aceptaFormatoPkcs8() throws Exception {
        Path archivo = tempDir.resolve("privada_test.key");
        try (Writer w = Files.newBufferedWriter(archivo); JcaPEMWriter pem = new JcaPEMWriter(w)) {
            pem.writeObject(new JcaPKCS8Generator(claves.getPrivate(), null));
        }
        PrivateKey leida = WsaaClient.cargarClavePrivada(archivo);
        assertArrayEquals(claves.getPrivate().getEncoded(), leida.getEncoded());
    }

    @Test
    void cargarClavePrivada_aceptaFormatoRsaPkcs1() throws Exception {
        Path archivo = tempDir.resolve("privada_rsa.key");
        try (Writer w = Files.newBufferedWriter(archivo); JcaPEMWriter pem = new JcaPEMWriter(w)) {
            pem.writeObject(claves); // "BEGIN RSA PRIVATE KEY" (formato de OpenSSL 1.x)
        }
        PrivateKey leida = WsaaClient.cargarClavePrivada(archivo);
        assertArrayEquals(claves.getPrivate().getEncoded(), leida.getEncoded());
    }

    @Test
    void cargarCertificado_archivoInexistente_lanzaArcaException() {
        assertThrows(ArcaException.class, () -> WsaaClient.cargarCertificado(tempDir.resolve("no_existe.crt")));
    }

    @TempDir
    Path tempDir;
}
