package com.example.arca;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

// Armado y lectura de los mensajes SOAP de WSFEv1 (con respuestas de ejemplo, sin conectarse)
class WsfeClientTest {

    private static String sobre(String cuerpo) {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                + "<soap:Body>" + cuerpo + "</soap:Body></soap:Envelope>";
    }

    @Test
    void cuerpoSolicitarCae_tieneLosCamposEnElOrdenDelWsdl() {
        WsfeClient.SolicitudCae s = new WsfeClient.SolicitudCae(1, 6, 15, LocalDate.of(2026, 11, 3),
                WsfeClient.DOC_SIN_IDENTIFICAR, 0, 5, 1500.0, 315.0, "PES");

        String xml = WsfeClient.cuerpoSolicitarCae("<ar:Auth/>", s);

        assertTrue(xml.contains("<ar:PtoVta>1</ar:PtoVta><ar:CbteTipo>6</ar:CbteTipo>"));
        assertTrue(xml.contains("<ar:DocTipo>99</ar:DocTipo><ar:DocNro>0</ar:DocNro>"));
        assertTrue(xml.contains("<ar:CbteDesde>15</ar:CbteDesde><ar:CbteHasta>15</ar:CbteHasta>"));
        assertTrue(xml.contains("<ar:CbteFch>20261103</ar:CbteFch>"));
        assertTrue(xml.contains("<ar:ImpTotal>1815.00</ar:ImpTotal>"));
        assertTrue(xml.contains("<ar:ImpNeto>1500.00</ar:ImpNeto>"));
        assertTrue(xml.contains("<ar:ImpIVA>315.00</ar:ImpIVA>"));
        assertTrue(xml.contains("<ar:CondicionIVAReceptorId>5</ar:CondicionIVAReceptorId>"));
        assertTrue(xml.contains("<ar:Id>5</ar:Id><ar:BaseImp>1500.00</ar:BaseImp><ar:Importe>315.00</ar:Importe>"));

        // orden exigido por el esquema: ImpIVA ... MonId, MonCotiz, CondicionIVAReceptorId, Iva
        assertTrue(xml.indexOf("ImpIVA") < xml.indexOf("MonId"));
        assertTrue(xml.indexOf("MonCotiz") < xml.indexOf("CondicionIVAReceptorId"));
        assertTrue(xml.indexOf("CondicionIVAReceptorId") < xml.indexOf("<ar:Iva>"));
    }

    @Test
    void leerRespuestaCae_aprobada() {
        String respuesta = sobre("<FECAESolicitarResponse xmlns=\"http://ar.gov.afip.dif.FEV1/\"><FECAESolicitarResult>"
                + "<FeCabResp><Cuit>20111111112</Cuit><PtoVta>1</PtoVta><CbteTipo>6</CbteTipo><Resultado>A</Resultado></FeCabResp>"
                + "<FeDetResp><FECAEDetResponse><Concepto>1</Concepto><CbteDesde>15</CbteDesde><CbteHasta>15</CbteHasta>"
                + "<Resultado>A</Resultado><CAE>76441234567890</CAE><CAEFchVto>20261113</CAEFchVto></FECAEDetResponse></FeDetResp>"
                + "</FECAESolicitarResult></FECAESolicitarResponse>");

        WsfeClient.RespuestaCae r = WsfeClient.leerRespuestaCae(respuesta);

        assertTrue(r.aprobada());
        assertEquals("76441234567890", r.cae());
        assertEquals(LocalDate.of(2026, 11, 13), r.vencimientoCae());
        assertEquals(15, r.numero());
        assertTrue(r.mensajes().isEmpty());
    }

    @Test
    void leerRespuestaCae_rechazadaConObservacionesYErrores() {
        String respuesta = sobre("<FECAESolicitarResponse xmlns=\"http://ar.gov.afip.dif.FEV1/\"><FECAESolicitarResult>"
                + "<FeCabResp><Resultado>R</Resultado></FeCabResp>"
                + "<FeDetResp><FECAEDetResponse><Resultado>R</Resultado><CAE></CAE><CAEFchVto></CAEFchVto>"
                + "<Observaciones><Obs><Code>10016</Code><Msg>La fecha del comprobante no puede ser anterior a N dias</Msg></Obs></Observaciones>"
                + "</FECAEDetResponse></FeDetResp>"
                + "<Errors><Err><Code>10015</Code><Msg>Campo DocNro invalido</Msg></Err></Errors>"
                + "</FECAESolicitarResult></FECAESolicitarResponse>");

        WsfeClient.RespuestaCae r = WsfeClient.leerRespuestaCae(respuesta);

        assertFalse(r.aprobada());
        assertNull(r.cae());
        assertEquals(2, r.mensajes().size());
        assertTrue(r.mensajes().get(0).startsWith("10015"));
        assertTrue(r.mensajes().get(1).startsWith("10016"));
    }

    @Test
    void leerUltimoAutorizado_devuelveElNumero() {
        String respuesta = sobre("<FECompUltimoAutorizadoResponse xmlns=\"http://ar.gov.afip.dif.FEV1/\">"
                + "<FECompUltimoAutorizadoResult><PtoVta>1</PtoVta><CbteTipo>6</CbteTipo><CbteNro>14</CbteNro>"
                + "</FECompUltimoAutorizadoResult></FECompUltimoAutorizadoResponse>");
        assertEquals(14, WsfeClient.leerUltimoAutorizado(respuesta));
    }

    @Test
    void leerUltimoAutorizado_conErrorDeAutenticacion_lanzaArcaException() {
        String respuesta = sobre("<FECompUltimoAutorizadoResponse xmlns=\"http://ar.gov.afip.dif.FEV1/\">"
                + "<FECompUltimoAutorizadoResult><Errors><Err><Code>600</Code><Msg>ValidacionDeToken: No validaron las fechas del token</Msg></Err></Errors>"
                + "</FECompUltimoAutorizadoResult></FECompUltimoAutorizadoResponse>");
        ArcaException e = assertThrows(ArcaException.class, () -> WsfeClient.leerUltimoAutorizado(respuesta));
        assertTrue(e.getMessage().contains("600"));
    }

    @Test
    void leerEstado_respuestaRealDeFeDummy() {
        // respuesta copiada de https://wswhomo.afip.gov.ar/wsfev1/service.asmx (FEDummy)
        String respuesta = sobre("<FEDummyResponse xmlns=\"http://ar.gov.afip.dif.FEV1/\"><FEDummyResult>"
                + "<AppServer>OK</AppServer><DbServer>OK</DbServer><AuthServer>OK</AuthServer>"
                + "</FEDummyResult></FEDummyResponse>");
        assertTrue(WsfeClient.leerEstado(respuesta).todosOk());
    }

    @Test
    void parsear_rechazaXmlConDoctype() {
        String malicioso = "<?xml version=\"1.0\"?><!DOCTYPE x [<!ENTITY e SYSTEM \"file:///etc/passwd\">]><x>&e;</x>";
        assertThrows(ArcaException.class, () -> Soap.parsear(malicioso));
    }
}
