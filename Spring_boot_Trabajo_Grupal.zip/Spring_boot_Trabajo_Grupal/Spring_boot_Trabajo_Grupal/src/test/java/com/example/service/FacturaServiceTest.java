package com.example.service;

import com.example.arca.ArcaConfig;
import com.example.arca.TipoComprobante;
import com.example.arca.WsaaClient;
import com.example.arca.WsfeClient;
import com.example.dto.FacturaDetalleRequestDTO;
import com.example.dto.FacturaReporteDTO;
import com.example.dto.FacturaRequestDTO;
import com.example.entidades.*;
import com.example.exception.RecursoNoEncontradoException;
import com.example.exception.ReglaNegocioException;
import com.example.repository.CatalogoRepository;
import com.example.repository.FacturaVentaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

// Pruebas de las reglas de negocio de FacturaService (sin base de datos: repositorios simulados)
class FacturaServiceTest {

    private FacturaVentaRepository facturaRepo;
    private CatalogoRepository catalogoRepo;
    private FacturaService service;

    private PuntoVenta puntoVenta;
    private CondicionIva responsableInscripto;
    private TipoMoneda pesos;
    private Cliente cliente;
    private ListaPrecioArticulo precioGeneral;

    @BeforeEach
    void preparar() {
        facturaRepo = mock(FacturaVentaRepository.class);
        catalogoRepo = mock(CatalogoRepository.class);
        ArcaConfig configSimulada = mock(ArcaConfig.class); // esModoReal() = false -> modo simulado
        ArcaService arca = new ArcaService(configSimulada, mock(WsaaClient.class), mock(WsfeClient.class));
        service = new FacturaService(facturaRepo, catalogoRepo, arca);

        puntoVenta = new PuntoVenta();
        puntoVenta.setId(1L);
        puntoVenta.setNumero(1);
        responsableInscripto = new CondicionIva();
        responsableInscripto.setId(1L);
        responsableInscripto.setCodigoAfip(1);
        pesos = new TipoMoneda();
        pesos.setId(1L);
        cliente = new Cliente();
        cliente.setId(2L);

        Articulo articulo = new Articulo();
        articulo.setId(10L);
        articulo.setDenominacion("Gaseosa 500ml");
        Articulo cerveza = new Articulo();
        cerveza.setId(11L);
        cerveza.setCodigo("ART-004");

        ListaPrecio general = new ListaPrecio();
        general.setId(1L);
        general.setDenominacion("Lista General");
        ListaPrecio mayorista = new ListaPrecio();
        mayorista.setId(2L);
        mayorista.setDenominacion("Lista Mayorista");

        precioGeneral = new ListaPrecioArticulo();
        precioGeneral.setListaPrecio(general);
        precioGeneral.setArticulo(articulo);
        precioGeneral.setPrecioVenta(750.0);
        ListaPrecioArticulo precioMayorista = new ListaPrecioArticulo();
        precioMayorista.setListaPrecio(mayorista);
        precioMayorista.setArticulo(articulo);
        precioMayorista.setPrecioVenta(600.0);

        when(catalogoRepo.buscarPorId(PuntoVenta.class, 1L)).thenReturn(Optional.of(puntoVenta));
        when(catalogoRepo.buscarPorId(CondicionIva.class, 1L)).thenReturn(Optional.of(responsableInscripto));
        when(catalogoRepo.buscarPorId(TipoMoneda.class, 1L)).thenReturn(Optional.of(pesos));
        when(catalogoRepo.buscarPorId(Cliente.class, 2L)).thenReturn(Optional.of(cliente));
        when(catalogoRepo.buscarPorId(Articulo.class, 10L)).thenReturn(Optional.of(articulo));
        when(catalogoRepo.buscarPorId(eq(Cliente.class), eq(99L))).thenReturn(Optional.empty());
        when(catalogoRepo.buscarPorId(Articulo.class, 11L)).thenReturn(Optional.of(cerveza));
        when(catalogoRepo.buscarPorId(ListaPrecio.class, 1L)).thenReturn(Optional.of(general));
        when(catalogoRepo.buscarPorId(ListaPrecio.class, 2L)).thenReturn(Optional.of(mayorista));
        when(catalogoRepo.buscarPrecio(1L, 10L)).thenReturn(Optional.of(precioGeneral));
        when(catalogoRepo.buscarPrecio(2L, 10L)).thenReturn(Optional.of(precioMayorista));
        when(catalogoRepo.buscarPrecio(2L, 11L)).thenReturn(Optional.empty()); // la cerveza no esta en la mayorista
        when(catalogoRepo.primero(Usuario.class)).thenReturn(Optional.of(new Usuario()));
        when(facturaRepo.buscarReportePorId(any())).thenReturn(Optional.of(new FacturaReporteDTO()));
    }

    private FacturaRequestDTO requestValido() {
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setFechaEmision(LocalDate.now());
        dto.setClienteId(2L);
        dto.setPuntoVentaId(1L);
        dto.setCondicionIvaId(1L);
        dto.setTipoMonedaId(1L);
        dto.setListaPrecioId(1L);
        dto.setDetalles(List.of(
                new FacturaDetalleRequestDTO(10L, 2.0, null, null),
                new FacturaDetalleRequestDTO(10L, 3.0, 10.0, null)));
        return dto;
    }

    private FacturaVenta facturaEnEstado(String estado, Long numero) {
        FacturaVenta f = new FacturaVenta();
        f.setId(5L);
        f.setEstado(estado);
        f.setNumero(numero);
        f.setPuntoVenta(puntoVenta);
        f.setCondicionIva(responsableInscripto);
        f.setCliente(cliente);
        f.setFechaEmision(java.sql.Date.valueOf(LocalDate.now()));
        f.setImporteTotal(1815.0);
        FacturaVentaDetalle detalle = new FacturaVentaDetalle();
        detalle.setListaPrecioArticulo(precioGeneral);
        detalle.setCantidad(2);
        detalle.setPrecioUnitario(750.0);
        detalle.setImporteNeto(1500.0);
        detalle.setImporteIva(315.0);
        detalle.setImporteSubtotal(1815.0);
        List<FacturaVentaDetalle> detalles = new ArrayList<>();
        detalles.add(detalle);
        f.setDetalles(detalles);
        when(facturaRepo.buscarPorId(5L)).thenReturn(Optional.of(f));
        return f;
    }

    // ------------------------------------------------------------------ crear

    @Test
    void crear_calculaNetoIvaYTotal_yQuedaComoBorradorSinNumero() {
        service.crear(requestValido());

        ArgumentCaptor<FacturaVenta> captor = ArgumentCaptor.forClass(FacturaVenta.class);
        verify(facturaRepo).guardar(captor.capture());
        FacturaVenta guardada = captor.getValue();

        assertEquals(FacturaService.BORRADOR, guardada.getEstado());
        assertNull(guardada.getNumero(), "el numero lo asigna ARCA al autorizar");
        assertNull(guardada.getCae());
        assertEquals(2, guardada.getDetalles().size());

        // renglon 1: 2 x 750 = 1500 neto, IVA 315, subtotal 1815
        FacturaVentaDetalle d1 = guardada.getDetalles().get(0);
        assertEquals(1500.0, d1.getImporteNeto());
        assertEquals(315.0, d1.getImporteIva());
        assertEquals(1815.0, d1.getImporteSubtotal());
        assertSame(guardada, d1.getFactura(), "relacion bidireccional para el cascade");

        // renglon 2: 3 x 750 = 2250 - 10% = 2025 neto, IVA 425.25
        FacturaVentaDetalle d2 = guardada.getDetalles().get(1);
        assertEquals(2025.0, d2.getImporteNeto());
        assertEquals(425.25, d2.getImporteIva());

        assertEquals(4265.25, guardada.getImporteTotal());
        assertEquals(4265.25, guardada.getImporteSaldo());
    }

    @Test
    void crear_sinDetalles_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setDetalles(List.of());
        assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
        verify(facturaRepo, never()).guardar(any());
    }

    @Test
    void crear_cantidadCero_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 0.0, null, null)));
        assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
    }

    @Test
    void crear_clienteInexistente_lanzaRecursoNoEncontrado() {
        FacturaRequestDTO dto = requestValido();
        dto.setClienteId(99L);
        assertThrows(RecursoNoEncontradoException.class, () -> service.crear(dto));
    }

    // ------------------------------------------------------------------ autorizar

    @Test
    void autorizar_borrador_asignaNumeroCorrelativoYCae() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        cliente.setCuitCuil("30-12345678-9");
        when(facturaRepo.siguienteNumero(1L, TipoComprobante.FACTURA_A)).thenReturn(1008L);

        service.autorizar(5L);

        assertEquals(FacturaService.EMITIDA, f.getEstado());
        assertEquals(1008L, f.getNumero());
        assertNotNull(f.getCae());
        assertEquals(14, f.getCae().length());
        assertEquals(java.sql.Date.valueOf(LocalDate.now().plusDays(10)), f.getCaeFechaVencimiento());
        assertEquals("A", f.getResultadoAfip());
    }

    @Test
    void autorizar_facturaYaEmitida_lanzaReglaNegocio() {
        facturaEnEstado(FacturaService.EMITIDA, 1001L);
        assertThrows(ReglaNegocioException.class, () -> service.autorizar(5L));
    }

    @Test
    void autorizar_responsableInscriptoSinCliente_esRechazadaPorArca() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        f.setCliente(null);
        assertThrows(ReglaNegocioException.class, () -> service.autorizar(5L));
        assertNull(f.getNumero(), "si ARCA rechaza no se consume numero");
        assertEquals(FacturaService.BORRADOR, f.getEstado());
        assertEquals("R", f.getResultadoAfip(), "se registra el rechazo");
        assertNotNull(f.getMotivoRechazo());
    }

    @Test
    void autorizar_fechaFueraDelRangoDeArca_esRechazada() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        cliente.setCuitCuil("30-12345678-9");
        f.setFechaEmision(java.sql.Date.valueOf(LocalDate.now().minusDays(20)));
        ReglaNegocioException e = assertThrows(ReglaNegocioException.class, () -> service.autorizar(5L));
        assertTrue(e.getMessage().contains("fecha"));
    }

    @Test
    void autorizar_consumidorFinal_usaNumeracionDeFacturaB() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        CondicionIva consumidorFinal = new CondicionIva();
        consumidorFinal.setCodigoAfip(5);
        f.setCondicionIva(consumidorFinal);
        f.setCliente(null);
        when(facturaRepo.siguienteNumero(1L, TipoComprobante.FACTURA_B)).thenReturn(1007L);

        service.autorizar(5L);

        assertEquals(1007L, f.getNumero());
        assertEquals(FacturaService.EMITIDA, f.getEstado());
    }

    // ------------------------------------------------------------------ eliminar

    @Test
    void eliminar_borradorSinNumero_borraLaFactura() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        service.eliminar(5L);
        verify(facturaRepo).eliminar(f);
    }

    @Test
    void eliminar_facturaConNumero_lanzaReglaNegocioYNoBorra() {
        facturaEnEstado(FacturaService.EMITIDA, 1001L);
        assertThrows(ReglaNegocioException.class, () -> service.eliminar(5L));
        verify(facturaRepo, never()).eliminar(any());
    }

    @Test
    void eliminar_inexistente_lanzaRecursoNoEncontrado() {
        when(facturaRepo.buscarPorId(77L)).thenReturn(Optional.empty());
        assertThrows(RecursoNoEncontradoException.class, () -> service.eliminar(77L));
    }

    // ------------------------------------------------------------------ actualizar / anular

    @Test
    void anular_facturaEmitida_cambiaEstadoYFechaAnulacion() {
        FacturaVenta f = facturaEnEstado(FacturaService.EMITIDA, 1001L);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setEstado("anulada");
        dto.setObservaciones("Error de carga");

        service.actualizar(5L, dto);

        assertEquals(FacturaService.ANULADA, f.getEstado());
        assertNotNull(f.getFechaAnulacion());
        assertEquals("Error de carga", f.getObservaciones());
    }

    @Test
    void anular_borradorSinNumero_lanzaReglaNegocio() {
        facturaEnEstado(FacturaService.BORRADOR, null);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setEstado("ANULADA");
        assertThrows(ReglaNegocioException.class, () -> service.actualizar(5L, dto));
    }

    @Test
    void actualizar_itemsDeFacturaEmitida_lanzaReglaNegocio() {
        facturaEnEstado(FacturaService.EMITIDA, 1001L);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 1.0, null, null)));
        assertThrows(ReglaNegocioException.class, () -> service.actualizar(5L, dto));
    }

    @Test
    void actualizar_facturaAnulada_lanzaReglaNegocio() {
        facturaEnEstado(FacturaService.ANULADA, 1001L);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setObservaciones("x");
        assertThrows(ReglaNegocioException.class, () -> service.actualizar(5L, dto));
    }

    @Test
    void actualizar_itemsDeBorrador_reemplazaYRecalcula() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 4.0, null, null)));

        service.actualizar(5L, dto);

        assertEquals(1, f.getDetalles().size());
        assertEquals(3630.0, f.getImporteTotal()); // 4 x 750 = 3000 + 21%
    }

    @Test
    void actualizar_estadoInvalido_lanzaIllegalArgument() {
        facturaEnEstado(FacturaService.EMITIDA, 1001L);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setEstado("PAGADA");
        assertThrows(IllegalArgumentException.class, () -> service.actualizar(5L, dto));
    }

    // ------------------------------------------------------------------ lista de precios

    @Test
    void crear_sinListaDePrecios_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setListaPrecioId(null);
        assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
    }

    @Test
    void crear_usaElPrecioYLaListaPrecioArticuloDeLaListaElegida() {
        FacturaRequestDTO dto = requestValido();
        dto.setListaPrecioId(2L); // mayorista: 600 en vez de 750
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 2.0, null, null)));

        service.crear(dto);

        ArgumentCaptor<FacturaVenta> captor = ArgumentCaptor.forClass(FacturaVenta.class);
        verify(facturaRepo).guardar(captor.capture());
        FacturaVentaDetalle d = captor.getValue().getDetalles().get(0);
        assertEquals(600.0, d.getPrecioUnitario());
        assertEquals("Lista Mayorista", d.getListaPrecioArticulo().getListaPrecio().getDenominacion());
        assertEquals(1452.0, captor.getValue().getImporteTotal()); // 1200 + 21 %
    }

    @Test
    void crear_articuloQueNoEstaEnLaLista_lanzaRecursoNoEncontrado() {
        FacturaRequestDTO dto = requestValido();
        dto.setListaPrecioId(2L);
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(11L, 1.0, null, null)));
        RecursoNoEncontradoException e = assertThrows(RecursoNoEncontradoException.class, () -> service.crear(dto));
        assertTrue(e.getMessage().contains("Lista Mayorista"));
    }

    @Test
    void actualizar_soloCambiaLaLista_vuelveACotizarLosMismosArticulos() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null); // 2 x 750 en la lista general
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setListaPrecioId(2L);

        service.actualizar(5L, dto);

        assertEquals(1, f.getDetalles().size());
        assertEquals(600.0, f.getDetalles().get(0).getPrecioUnitario());
        assertEquals(1452.0, f.getImporteTotal());
    }
}
