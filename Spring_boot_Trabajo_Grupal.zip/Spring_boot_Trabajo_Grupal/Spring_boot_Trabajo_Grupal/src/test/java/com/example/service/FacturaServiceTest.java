package com.example.service;

import com.example.arca.ArcaConfig;
import com.example.arca.TipoComprobante;
import com.example.arca.WsaaClient;
import com.example.arca.WsfeClient;
import com.example.dto.FacturaDetalleRequestDTO;
import com.example.dto.FacturaReporteDTO;
import com.example.dto.FacturaRequestDTO;
import com.example.entidades.*;
import com.example.exception.RecursoNoEncontradoException;
import com.example.exception.ReglaNegocioException;
import com.example.repository.CatalogoRepository;
import com.example.repository.FacturaVentaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

// Pruebas de las reglas de negocio de FacturaService (sin base de datos: repositorios simulados)
class FacturaServiceTest {

    private FacturaVentaRepository facturaRepo;
    private CatalogoRepository catalogoRepo;
    private FacturaService service;

    private PuntoVenta puntoVenta;
    private CondicionIva responsableInscripto;
    private TipoMoneda pesos;
    private Cliente cliente;
    private ListaPrecioArticulo precioGeneral;

    @BeforeEach
    void preparar() {
        facturaRepo = mock(FacturaVentaRepository.class);
        catalogoRepo = mock(CatalogoRepository.class);
        ArcaConfig configSimulada = mock(ArcaConfig.class); // esModoReal() = false -> modo simulado
        ArcaService arca = new ArcaService(configSimulada, mock(WsaaClient.class), mock(WsfeClient.class));
        service = new FacturaService(facturaRepo, catalogoRepo, arca);

        puntoVenta = new PuntoVenta();
        puntoVenta.setId(1L);
        puntoVenta.setNumero(1);
        responsableInscripto = new CondicionIva();
        responsableInscripto.setId(1L);
        responsableInscripto.setCodigoAfip(1);
        pesos = new TipoMoneda();
        pesos.setId(1L);
        cliente = new Cliente();
        cliente.setId(2L);

        Articulo articulo = new Articulo();
        articulo.setId(10L);
        articulo.setDenominacion("Gaseosa 500ml");
        Articulo cerveza = new Articulo();
        cerveza.setId(11L);
        cerveza.setCodigo("ART-004");

        ListaPrecio general = new ListaPrecio();
        general.setId(1L);
        general.setDenominacion("Lista General");
        ListaPrecio mayorista = new ListaPrecio();
        mayorista.setId(2L);
        mayorista.setDenominacion("Lista Mayorista");

        precioGeneral = new ListaPrecioArticulo();
        precioGeneral.setListaPrecio(general);
        precioGeneral.setArticulo(articulo);
        precioGeneral.setPrecioVenta(750.0);
        ListaPrecioArticulo precioMayorista = new ListaPrecioArticulo();
        precioMayorista.setListaPrecio(mayorista);
        precioMayorista.setArticulo(articulo);
        precioMayorista.setPrecioVenta(600.0);

        when(catalogoRepo.buscarPorId(PuntoVenta.class, 1L)).thenReturn(Optional.of(puntoVenta));
        when(catalogoRepo.buscarPorId(CondicionIva.class, 1L)).thenReturn(Optional.of(responsableInscripto));
        when(catalogoRepo.buscarPorId(TipoMoneda.class, 1L)).thenReturn(Optional.of(pesos));
        when(catalogoRepo.buscarPorId(Cliente.class, 2L)).thenReturn(Optional.of(cliente));
        when(catalogoRepo.buscarPorId(Articulo.class, 10L)).thenReturn(Optional.of(articulo));
        when(catalogoRepo.buscarPorId(eq(Cliente.class), eq(99L))).thenReturn(Optional.empty());
        when(catalogoRepo.buscarPorId(Articulo.class, 11L)).thenReturn(Optional.of(cerveza));
        when(catalogoRepo.buscarPorId(ListaPrecio.class, 1L)).thenReturn(Optional.of(general));
        when(catalogoRepo.buscarPorId(ListaPrecio.class, 2L)).thenReturn(Optional.of(mayorista));
        when(catalogoRepo.buscarPrecio(1L, 10L)).thenReturn(Optional.of(precioGeneral));
        Articulo gaseosaGrande = new Articulo();
        gaseosaGrande.setId(12L);
        gaseosaGrande.setDenominacion("Gaseosa 2.25L");
        ListaPrecioArticulo precioGaseosaGrande = new ListaPrecioArticulo();
        precioGaseosaGrande.setListaPrecio(general);
        precioGaseosaGrande.setArticulo(gaseosaGrande);
        precioGaseosaGrande.setPrecioVenta(750.0);
        when(catalogoRepo.buscarPorId(Articulo.class, 12L)).thenReturn(Optional.of(gaseosaGrande));
        when(catalogoRepo.buscarPrecio(1L, 12L)).thenReturn(Optional.of(precioGaseosaGrande));
        when(catalogoRepo.buscarPrecio(2L, 10L)).thenReturn(Optional.of(precioMayorista));
        when(catalogoRepo.buscarPrecio(2L, 11L)).thenReturn(Optional.empty()); // la cerveza no esta en la mayorista
        when(catalogoRepo.primero(Usuario.class)).thenReturn(Optional.of(new Usuario()));
        when(facturaRepo.buscarReportePorId(any())).thenReturn(Optional.of(new FacturaReporteDTO()));
    }

    private FacturaRequestDTO requestValido() {
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setFechaEmision(LocalDate.now());
        dto.setClienteId(2L);
        dto.setPuntoVentaId(1L);
        dto.setCondicionIvaId(1L);
        dto.setTipoMonedaId(1L);
        dto.setListaPrecioId(1L);
        dto.setDetalles(List.of(
                new FacturaDetalleRequestDTO(10L, 2.0, null, null),
                new FacturaDetalleRequestDTO(12L, 3.0, 10.0, null)));
        return dto;
    }

    private FacturaVenta facturaEnEstado(String estado, Long numero) {
        FacturaVenta f = new FacturaVenta();
        f.setId(5L);
        f.setEstado(estado);
        f.setNumero(numero);
        f.setPuntoVenta(puntoVenta);
        f.setCondicionIva(responsableInscripto);
        f.setCliente(cliente);
        f.setFechaEmision(java.sql.Date.valueOf(LocalDate.now()));
        f.setImporteTotal(1815.0);
        FacturaVentaDetalle detalle = new FacturaVentaDetalle();
        detalle.setListaPrecioArticulo(precioGeneral);
        detalle.setCantidad(2);
        detalle.setPrecioUnitario(750.0);
        detalle.setImporteNeto(1500.0);
        detalle.setImporteIva(315.0);
        detalle.setImporteSubtotal(1815.0);
        List<FacturaVentaDetalle> detalles = new ArrayList<>();
        detalles.add(detalle);
        f.setDetalles(detalles);
        when(facturaRepo.buscarPorId(5L)).thenReturn(Optional.of(f));
        when(facturaRepo.buscarParaModificar(5L)).thenReturn(Optional.of(f));
        return f;
    }

    // ------------------------------------------------------------------ crear

    @Test
    void crear_calculaNetoIvaYTotal_yQuedaComoBorradorSinNumero() {
        service.crear(requestValido());

        ArgumentCaptor<FacturaVenta> captor = ArgumentCaptor.forClass(FacturaVenta.class);
        verify(facturaRepo).guardar(captor.capture());
        FacturaVenta guardada = captor.getValue();

        assertEquals(FacturaService.BORRADOR, guardada.getEstado());
        assertNull(guardada.getNumero(), "el numero lo asigna ARCA al autorizar");
        assertNull(guardada.getCae());
        assertEquals(2, guardada.getDetalles().size());

        // renglon 1: 2 x 750 = 1500 neto, IVA 315, subtotal 1815
        FacturaVentaDetalle d1 = guardada.getDetalles().get(0);
        assertEquals(1500.0, d1.getImporteNeto());
        assertEquals(315.0, d1.getImporteIva());
        assertEquals(1815.0, d1.getImporteSubtotal());
        assertSame(guardada, d1.getFactura(), "relacion bidireccional para el cascade");

        // renglon 2: 3 x 750 = 2250 - 10% = 2025 neto, IVA 425.25
        FacturaVentaDetalle d2 = guardada.getDetalles().get(1);
        assertEquals(2025.0, d2.getImporteNeto());
        assertEquals(425.25, d2.getImporteIva());

        assertEquals(4265.25, guardada.getImporteTotal());
        assertEquals(4265.25, guardada.getImporteSaldo());
    }

    @Test
    void crear_sinDetalles_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setDetalles(List.of());
        assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
        verify(facturaRepo, never()).guardar(any());
    }

    @Test
    void crear_cantidadCero_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 0.0, null, null)));
        assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
    }

    @Test
    void crear_clienteInexistente_lanzaRecursoNoEncontrado() {
        FacturaRequestDTO dto = requestValido();
        dto.setClienteId(99L);
        assertThrows(RecursoNoEncontradoException.class, () -> service.crear(dto));
    }

    // ------------------------------------------------------------------ autorizar

    @Test
    void autorizar_borrador_asignaNumeroCorrelativoYCae() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        cliente.setCuitCuil("30-12345678-1");
        when(facturaRepo.siguienteNumero(1L, TipoComprobante.FACTURA_A)).thenReturn(1008L);

        service.autorizar(5L);

        assertEquals(FacturaService.EMITIDA, f.getEstado());
        assertEquals(1008L, f.getNumero());
        assertNotNull(f.getCae());
        assertEquals(14, f.getCae().length());
        assertEquals(java.sql.Date.valueOf(LocalDate.now().plusDays(10)), f.getCaeFechaVencimiento());
        assertEquals("A", f.getResultadoAfip());
    }

    @Test
    void autorizar_facturaYaEmitida_lanzaReglaNegocio() {
        facturaEnEstado(FacturaService.EMITIDA, 1001L);
        assertThrows(ReglaNegocioException.class, () -> service.autorizar(5L));
    }

    @Test
    void autorizar_borradorIncoherente_responsableInscriptoSinCliente_noSeEnviaAArca() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        f.setCliente(null);
        ReglaNegocioException e = assertThrows(ReglaNegocioException.class, () -> service.autorizar(5L));
        assertTrue(e.getMessage().contains("Consumidor Final"));
        assertNull(f.getNumero(), "no se consume numero");
        assertEquals(FacturaService.BORRADOR, f.getEstado());
    }

    // Regla de ARCA: el numero siguiente no puede tener fecha anterior al ultimo emitido
    @Test
    void autorizar_fechaAnteriorAlUltimoEmitido_esRechazada() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        cliente.setCuitCuil("30-12345678-1");
        f.setFechaEmision(java.sql.Date.valueOf(LocalDate.now().minusDays(2)));
        FacturaVenta ultimo = new FacturaVenta();
        ultimo.setNumero(1007L);
        ultimo.setCae("12345678901234");
        ultimo.setPuntoVenta(puntoVenta);
        ultimo.setCondicionIva(responsableInscripto);
        ultimo.setFechaEmision(java.sql.Date.valueOf(LocalDate.now()));
        when(facturaRepo.ultimoNumerado(1L, TipoComprobante.FACTURA_A)).thenReturn(Optional.of(ultimo));

        ReglaNegocioException e = assertThrows(ReglaNegocioException.class, () -> service.autorizar(5L));
        assertTrue(e.getMessage().contains("anterior a la del último comprobante"), e.getMessage());
        assertNull(f.getNumero(), "no se consume numero");
        assertEquals(FacturaService.BORRADOR, f.getEstado());
        assertEquals("R", f.getResultadoAfip(), "se registra el rechazo");
    }

    @Test
    void autorizar_mismaFechaQueElUltimoEmitido_seAutoriza() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        cliente.setCuitCuil("30-12345678-1");
        FacturaVenta ultimo = new FacturaVenta();
        ultimo.setNumero(1007L);
        ultimo.setPuntoVenta(puntoVenta);
        ultimo.setCondicionIva(responsableInscripto);
        ultimo.setFechaEmision(java.sql.Date.valueOf(LocalDate.now()));
        when(facturaRepo.ultimoNumerado(1L, TipoComprobante.FACTURA_A)).thenReturn(Optional.of(ultimo));
        when(facturaRepo.siguienteNumero(1L, TipoComprobante.FACTURA_A)).thenReturn(1008L);

        service.autorizar(5L);

        assertEquals(FacturaService.EMITIDA, f.getEstado());
        assertEquals(1008L, f.getNumero());
    }

    @Test
    void autorizar_fechaFueraDelRangoDeArca_esRechazada() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        cliente.setCuitCuil("30-12345678-1");
        f.setFechaEmision(java.sql.Date.valueOf(LocalDate.now().minusDays(20)));
        ReglaNegocioException e = assertThrows(ReglaNegocioException.class, () -> service.autorizar(5L));
        assertTrue(e.getMessage().contains("fecha"));
        assertNull(f.getNumero(), "si ARCA rechaza no se consume numero");
        assertEquals(FacturaService.BORRADOR, f.getEstado());
        assertEquals("R", f.getResultadoAfip(), "se registra el rechazo");
        assertNotNull(f.getMotivoRechazo());
    }

    @Test
    void autorizar_cuitConDigitoVerificadorInvalido_esRechazado() {
        facturaEnEstado(FacturaService.BORRADOR, null);
        cliente.setCuitCuil("30-12345678-9");
        ReglaNegocioException e = assertThrows(ReglaNegocioException.class, () -> service.autorizar(5L));
        assertTrue(e.getMessage().contains("CUIT"));
    }

    @Test
    void autorizar_bloqueaElPuntoDeVentaParaNumerar() {
        facturaEnEstado(FacturaService.BORRADOR, null);
        cliente.setCuitCuil("30-12345678-1");
        when(facturaRepo.siguienteNumero(1L, TipoComprobante.FACTURA_A)).thenReturn(1L);
        service.autorizar(5L);
        verify(facturaRepo).bloquearPuntoVenta(1L);
    }

    @Test
    void autorizar_consumidorFinal_usaNumeracionDeFacturaB() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        CondicionIva consumidorFinal = new CondicionIva();
        consumidorFinal.setCodigoAfip(5);
        f.setCondicionIva(consumidorFinal);
        f.setCliente(null);
        when(facturaRepo.siguienteNumero(1L, TipoComprobante.FACTURA_B)).thenReturn(1007L);

        service.autorizar(5L);

        assertEquals(1007L, f.getNumero());
        assertEquals(FacturaService.EMITIDA, f.getEstado());
    }

    // ------------------------------------------------------------------ eliminar

    @Test
    void eliminar_borradorSinNumero_borraLaFactura() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        service.eliminar(5L);
        verify(facturaRepo).eliminar(f);
    }

    @Test
    void eliminar_facturaConNumero_lanzaReglaNegocioYNoBorra() {
        facturaEnEstado(FacturaService.EMITIDA, 1001L);
        assertThrows(ReglaNegocioException.class, () -> service.eliminar(5L));
        verify(facturaRepo, never()).eliminar(any());
    }

    @Test
    void eliminar_inexistente_lanzaRecursoNoEncontrado() {
        when(facturaRepo.buscarPorId(77L)).thenReturn(Optional.empty());
        assertThrows(RecursoNoEncontradoException.class, () -> service.eliminar(77L));
    }

    // ------------------------------------------------------------------ actualizar / anular

    @Test
    void anular_facturaEmitida_cambiaEstadoYFechaAnulacion() {
        FacturaVenta f = facturaEnEstado(FacturaService.EMITIDA, 1001L);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setEstado("anulada");
        dto.setObservaciones("Error de carga");

        service.actualizar(5L, dto);

        assertEquals(FacturaService.ANULADA, f.getEstado());
        assertNotNull(f.getFechaAnulacion());
        assertEquals("Error de carga", f.getObservaciones());
    }

    @Test
    void anular_conObservacionesPrevias_agregaElMotivoSinBorrarlas() {
        FacturaVenta f = facturaEnEstado(FacturaService.EMITIDA, 1001L);
        f.setObservaciones("Entregar por la tarde");
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setEstado("ANULADA");
        dto.setObservaciones("Error de carga");

        service.actualizar(5L, dto);

        assertEquals("Entregar por la tarde | Motivo de anulación: Error de carga", f.getObservaciones());
    }

    @Test
    void anular_borradorSinNumero_lanzaReglaNegocio() {
        facturaEnEstado(FacturaService.BORRADOR, null);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setEstado("ANULADA");
        assertThrows(ReglaNegocioException.class, () -> service.actualizar(5L, dto));
    }

    @Test
    void actualizar_itemsDeFacturaEmitida_lanzaReglaNegocio() {
        facturaEnEstado(FacturaService.EMITIDA, 1001L);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 1.0, null, null)));
        assertThrows(ReglaNegocioException.class, () -> service.actualizar(5L, dto));
    }

    @Test
    void actualizar_facturaAnulada_lanzaReglaNegocio() {
        facturaEnEstado(FacturaService.ANULADA, 1001L);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setObservaciones("x");
        assertThrows(ReglaNegocioException.class, () -> service.actualizar(5L, dto));
    }

    @Test
    void actualizar_itemsDeBorrador_reemplazaYRecalcula() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 4.0, null, null)));

        service.actualizar(5L, dto);

        assertEquals(1, f.getDetalles().size());
        assertEquals(3630.0, f.getImporteTotal()); // 4 x 750 = 3000 + 21%
    }

    @Test
    void actualizar_estadoInvalido_lanzaIllegalArgument() {
        facturaEnEstado(FacturaService.EMITIDA, 1001L);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setEstado("PAGADA");
        assertThrows(IllegalArgumentException.class, () -> service.actualizar(5L, dto));
    }

    // ------------------------------------------------------------------ lista de precios

    @Test
    void crear_sinListaDePrecios_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setListaPrecioId(null);
        assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
    }

    @Test
    void crear_usaElPrecioYLaListaPrecioArticuloDeLaListaElegida() {
        FacturaRequestDTO dto = requestValido();
        dto.setListaPrecioId(2L); // mayorista: 600 en vez de 750
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 2.0, null, null)));

        service.crear(dto);

        ArgumentCaptor<FacturaVenta> captor = ArgumentCaptor.forClass(FacturaVenta.class);
        verify(facturaRepo).guardar(captor.capture());
        FacturaVentaDetalle d = captor.getValue().getDetalles().get(0);
        assertEquals(600.0, d.getPrecioUnitario());
        assertEquals("Lista Mayorista", d.getListaPrecioArticulo().getListaPrecio().getDenominacion());
        assertEquals(1452.0, captor.getValue().getImporteTotal()); // 1200 + 21 %
    }

    @Test
    void crear_articuloQueNoEstaEnLaLista_lanzaRecursoNoEncontrado() {
        FacturaRequestDTO dto = requestValido();
        dto.setListaPrecioId(2L);
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(11L, 1.0, null, null)));
        RecursoNoEncontradoException e = assertThrows(RecursoNoEncontradoException.class, () -> service.crear(dto));
        assertTrue(e.getMessage().contains("Lista Mayorista"));
    }

    @Test
    void actualizar_soloCambiaLaLista_vuelveACotizarLosMismosArticulos() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null); // 2 x 750 en la lista general
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setListaPrecioId(2L);

        service.actualizar(5L, dto);

        assertEquals(1, f.getDetalles().size());
        assertEquals(600.0, f.getDetalles().get(0).getPrecioUnitario());
        assertEquals(1452.0, f.getImporteTotal());
    }

    // ------------------------------------------------------------------ condicion de IVA vs cliente

    private CondicionIva condicion(long id, int codigo) {
        CondicionIva c = new CondicionIva();
        c.setId(id);
        c.setCodigoAfip(codigo);
        c.setDenominacion("cond " + codigo);
        when(catalogoRepo.buscarPorId(CondicionIva.class, id)).thenReturn(Optional.of(c));
        when(catalogoRepo.buscarCondicionPorCodigo(codigo)).thenReturn(Optional.of(c));
        return c;
    }

    @Test
    void crear_sinClienteConCondicionResponsableInscripto_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setClienteId(null);
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
        assertTrue(e.getMessage().contains("Consumidor Final"));
        verify(facturaRepo, never()).guardar(any());
    }

    @Test
    void crear_sinClienteNiCondicion_tomaConsumidorFinal() {
        CondicionIva cf = condicion(2L, FacturaService.CONDICION_CONSUMIDOR_FINAL);
        FacturaRequestDTO dto = requestValido();
        dto.setClienteId(null);
        dto.setCondicionIvaId(null);

        service.crear(dto);

        ArgumentCaptor<FacturaVenta> captor = ArgumentCaptor.forClass(FacturaVenta.class);
        verify(facturaRepo).guardar(captor.capture());
        assertSame(cf, captor.getValue().getCondicionIva());
        assertNull(captor.getValue().getCliente());
    }

    @Test
    void crear_condicionDistintaALaDelCliente_lanzaIllegalArgument() {
        cliente.setCondicionIva(condicion(3L, 6)); // el cliente es monotributista
        FacturaRequestDTO dto = requestValido();       // pero el pedido dice Responsable Inscripto
        assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
    }

    @Test
    void crear_sinCondicion_tomaLaDelCliente() {
        CondicionIva monotributo = condicion(3L, 6);
        cliente.setCondicionIva(monotributo);
        FacturaRequestDTO dto = requestValido();
        dto.setCondicionIvaId(null);

        service.crear(dto);

        ArgumentCaptor<FacturaVenta> captor = ArgumentCaptor.forClass(FacturaVenta.class);
        verify(facturaRepo).guardar(captor.capture());
        assertSame(monotributo, captor.getValue().getCondicionIva());
    }

    @Test
    void actualizar_cambiaElCliente_tomaLaCondicionDelClienteNuevo() {
        FacturaVenta f = facturaEnEstado(FacturaService.BORRADOR, null);
        CondicionIva cf = condicion(2L, FacturaService.CONDICION_CONSUMIDOR_FINAL);
        FacturaRequestDTO dto = new FacturaRequestDTO();
        dto.setClienteId(0L); // pasa a Consumidor Final

        service.actualizar(5L, dto);

        assertNull(f.getCliente());
        assertSame(cf, f.getCondicionIva(), "no queda como Responsable Inscripto sin cliente");
    }

    // ------------------------------------------------------------------ validaciones de datos

    @Test
    void crear_articuloRepetido_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 1.0, null, null),
                new FacturaDetalleRequestDTO(10L, 2.0, null, null)));
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
        assertTrue(e.getMessage().contains("repetido"));
    }

    @Test
    void crear_cantidadesFueraDeRango_lanzanIllegalArgument() {
        for (double cantidad : new double[]{Double.POSITIVE_INFINITY, Double.NaN, -1, 100_000, 1.005}) {
            FacturaRequestDTO dto = requestValido();
            dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, cantidad, null, null)));
            assertThrows(IllegalArgumentException.class, () -> service.crear(dto), "cantidad " + cantidad);
        }
    }

    // No se vende media botella de agua: la cantidad tiene que ser entera
    @Test
    void crear_cantidadConDecimales_lanzaIllegalArgument() {
        for (double cantidad : new double[]{0.5, 1.5, 2.25, 0.01}) {
            FacturaRequestDTO dto = requestValido();
            dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, cantidad, null, null)));
            IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                    () -> service.crear(dto), "cantidad " + cantidad);
            assertTrue(e.getMessage().contains("entero"), e.getMessage());
        }
    }

    @Test
    void crear_bonificacionInvalida_lanzaIllegalArgument() {
        for (double bonif : new double[]{-0.01, 100.01, Double.NaN, 10.555}) {
            FacturaRequestDTO dto = requestValido();
            dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 1.0, bonif, null)));
            assertThrows(IllegalArgumentException.class, () -> service.crear(dto), "bonificacion " + bonif);
        }
    }

    @Test
    void crear_observacionesDemasiadoLargas_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 1.0, null, null)));
        dto.setObservaciones("x".repeat(256));
        assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
    }

    @Test
    void crear_fechaAbsurda_lanzaIllegalArgument() {
        FacturaRequestDTO dto = requestValido();
        dto.setDetalles(List.of(new FacturaDetalleRequestDTO(10L, 1.0, null, null)));
        dto.setFechaEmision(LocalDate.of(1900, 1, 1));
        assertThrows(IllegalArgumentException.class, () -> service.crear(dto));
    }

    @Test
    void filtros_invalidos_lanzanIllegalArgument() {
        com.example.dto.FacturaFiltrosDTO estado = new com.example.dto.FacturaFiltrosDTO();
        estado.setEstado("PAGADA");
        assertThrows(IllegalArgumentException.class, () -> service.buscarFacturasFiltradas(estado));

        com.example.dto.FacturaFiltrosDTO monto = new com.example.dto.FacturaFiltrosDTO();
        monto.setMontoMinimo(Double.POSITIVE_INFINITY);
        assertThrows(IllegalArgumentException.class, () -> service.buscarFacturasFiltradas(monto));

        com.example.dto.FacturaFiltrosDTO rango = new com.example.dto.FacturaFiltrosDTO();
        rango.setMontoMinimo(500.0);
        rango.setMontoMaximo(100.0);
        assertThrows(IllegalArgumentException.class, () -> service.buscarFacturasFiltradas(rango));
    }
}
