package com.example.service;

import com.example.dto.FacturaReporteDTO;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ReporteServiceTest {

    private static FacturaReporteDTO comprobante(String estado, Long numero, String cae) {
        FacturaReporteDTO dto = new FacturaReporteDTO();
        dto.setLetra("B");
        dto.setEstado(estado);
        dto.setNumeroFactura(numero);
        dto.setPuntoVentaNumero(1);
        dto.setCae(cae);
        dto.setImporteTotal(1000);
        return dto;
    }

    @Test
    void totalFacturado_soloSumaEmitidasConCae() {
        assertTrue(ReporteService.sumaAlTotalFacturado(comprobante("EMITIDA", 3L, "71234567890123")));
        assertFalse(ReporteService.sumaAlTotalFacturado(comprobante("ANULADA", 4L, "71234567890124")));
        assertFalse(ReporteService.sumaAlTotalFacturado(comprobante("BORRADOR", null, null)));
        assertFalse(ReporteService.sumaAlTotalFacturado(comprobante("EMITIDA", 5L, null))); // sin CAE: no es factura
    }

    @Test
    void comprobante_soloSeLlamaFacturaConCae() {
        assertEquals("B 0001-00000003", ReporteService.comprobante(comprobante("EMITIDA", 3L, "71234567890123")));
        assertEquals("Borrador", ReporteService.comprobante(comprobante("BORRADOR", null, null)));
        assertTrue(ReporteService.comprobante(comprobante("EMITIDA", 5L, null)).startsWith("Sin CAE"));
    }
}
