/** Error HTTP devuelto por la API (status + mensaje del GlobalExceptionHandler). */
export class ApiError extends Error {
    status;
    constructor(status, mensaje) {
        super(mensaje);
        this.status = status;
        this.name = 'ApiError';
    }
    /** Lanza ApiError si la respuesta no es 2xx, usando el "mensaje" del JSON de error si existe. */
    static async verificar(respuesta) {
        if (respuesta.ok) {
            return;
        }
        let mensaje = `Error ${respuesta.status} (${respuesta.statusText || 'sin detalle'})`;
        try {
            const cuerpo = (await respuesta.json());
            if (cuerpo.mensaje) {
                mensaje = cuerpo.mensaje;
            }
        }
        catch {
            // la respuesta no trae JSON: queda el mensaje generico
        }
        throw new ApiError(respuesta.status, mensaje);
    }
}
//# sourceMappingURL=ApiError.js.map