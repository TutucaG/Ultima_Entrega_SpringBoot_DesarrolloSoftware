import { ApiError } from './ApiError.js';
/** Estado de la conexión con ARCA (GET /api/arca/estado). */
export class ArcaService {
    baseUrl;
    constructor(baseUrl = 'http://localhost:8080/api/arca') {
        this.baseUrl = baseUrl;
    }
    async obtenerEstado() {
        const respuesta = await fetch(`${this.baseUrl}/estado`);
        await ApiError.verificar(respuesta);
        return (await respuesta.json());
    }
}
//# sourceMappingURL=ArcaService.js.map