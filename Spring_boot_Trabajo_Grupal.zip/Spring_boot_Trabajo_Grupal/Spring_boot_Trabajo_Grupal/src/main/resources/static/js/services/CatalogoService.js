import { ApiError } from './ApiError.js';
/** Combos del formulario y busquedas de los explorers de clientes y articulos. */
export class CatalogoService {
    baseUrl;
    constructor(baseUrl = 'http://localhost:8080/api') {
        this.baseUrl = baseUrl;
    }
    /** GET /api/catalogos -> condiciones de IVA, puntos de venta, monedas y listas de precios. */
    async obtenerCatalogo() {
        return this.get(`${this.baseUrl}/catalogos`);
    }
    /** GET /api/clientes?q= -> explorer de clientes (razon social o CUIT). */
    async buscarClientes(texto) {
        return this.get(`${this.baseUrl}/clientes?q=${encodeURIComponent(texto)}`);
    }
    /** GET /api/listas-precio/{id}/articulos?q= -> articulos de esa lista con su precio. */
    async buscarArticulos(listaPrecioId, texto) {
        return this.get(`${this.baseUrl}/listas-precio/${listaPrecioId}/articulos?q=${encodeURIComponent(texto)}`);
    }
    async get(url) {
        const respuesta = await fetch(url);
        await ApiError.verificar(respuesta);
        return (await respuesta.json());
    }
}
//# sourceMappingURL=CatalogoService.js.map