// =====================================================================
// Interfaces espejo de los DTOs de Spring Boot (paquete com.example.dto)
// Mismos nombres de campo que en Java. Equivalencias de tipos:
//   Long / long / int / Double / double -> number
//   String                              -> string
//   Date / LocalDate (yyyy-MM-dd)       -> string  (Jackson la serializa como texto)
//   List<T>                             -> T[]
//   Campo que puede venir null          -> "| null"  (o opcional "?" en los request)
// =====================================================================
export {};
//# sourceMappingURL=factura.dto.js.map