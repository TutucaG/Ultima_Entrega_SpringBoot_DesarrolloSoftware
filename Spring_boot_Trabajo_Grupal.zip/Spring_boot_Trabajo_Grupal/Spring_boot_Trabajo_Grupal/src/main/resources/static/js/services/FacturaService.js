import { ApiError } from './ApiError.js';
/**
 * Cliente HTTP de la API de facturas.
 * Centraliza todas las llamadas a http://localhost:8080/api/facturas usando fetch + async/await.
 */
export class FacturaService {
    baseUrl;
    static JSON_HEADERS = { 'Content-Type': 'application/json' };
    constructor(baseUrl = 'http://localhost:8080/api/facturas') {
        this.baseUrl = baseUrl;
    }
    // ---------------- Metodos pedidos en la consigna ----------------
    /** GET /api/facturas?filtros -> 200 OK con la lista. */
    async obtenerFacturas(filtros = {}) {
        const respuesta = await fetch(this.urlConFiltros(this.baseUrl, filtros));
        await ApiError.verificar(respuesta);
        return (await respuesta.json());
    }
    /** POST /api/facturas -> 201 Created con la factura creada (queda como BORRADOR, sin numero). */
    async crearFactura(factura) {
        return this.enviar(this.baseUrl, 'POST', factura);
    }
    /** PUT /api/facturas/{id} con { estado, observaciones } -> 200 OK (se usa para anular). */
    async actualizarEstado(id, estado, observaciones) {
        const cuerpo = { estado };
        if (observaciones !== undefined) {
            cuerpo.observaciones = observaciones;
        }
        return this.enviar(`${this.baseUrl}/${id}`, 'PUT', cuerpo);
    }
    /** DELETE /api/facturas/{id} -> 204 No Content (solo facturas sin numero). */
    async eliminarFactura(id) {
        const respuesta = await fetch(`${this.baseUrl}/${id}`, { method: 'DELETE' });
        await ApiError.verificar(respuesta);
    }
    // ---------------- Metodos adicionales del explorer ----------------
    /** GET /api/facturas/{id} -> cabecera + items. */
    async obtenerFactura(id) {
        const respuesta = await fetch(`${this.baseUrl}/${id}`);
        await ApiError.verificar(respuesta);
        return (await respuesta.json());
    }
    /** PUT /api/facturas/{id} con cabecera y/o items (edicion de un borrador). */
    async actualizarFactura(id, factura) {
        return this.enviar(`${this.baseUrl}/${id}`, 'PUT', factura);
    }
    /** POST /api/facturas/{id}/autorizar -> ARCA asigna numero y CAE. */
    async autorizarFactura(id) {
        return this.enviar(`${this.baseUrl}/${id}/autorizar`, 'POST');
    }
    /** URL del PDF de una factura (GET /api/facturas/{id}/pdf). */
    urlComprobantePdf(id) {
        return `${this.baseUrl}/${id}/pdf`;
    }
    /** URL de descarga del reporte (GET /api/facturas/pdf | /excel) con los mismos filtros. */
    urlReporte(formato, filtros = {}) {
        return this.urlConFiltros(`${this.baseUrl}/${formato}`, filtros);
    }
    // ---------------- Auxiliares ----------------
    async enviar(url, method, cuerpo) {
        const respuesta = await fetch(url, {
            method,
            headers: FacturaService.JSON_HEADERS,
            body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
        });
        await ApiError.verificar(respuesta);
        return (await respuesta.json());
    }
    /** Arma la query string omitiendo los filtros vacios. */
    urlConFiltros(url, filtros) {
        const params = new URLSearchParams();
        for (const [clave, valor] of Object.entries(filtros)) {
            if (valor !== undefined && valor !== null && String(valor).trim() !== '') {
                params.append(clave, String(valor));
            }
        }
        const query = params.toString();
        return query ? `${url}?${query}` : url;
    }
}
//# sourceMappingURL=FacturaService.js.map