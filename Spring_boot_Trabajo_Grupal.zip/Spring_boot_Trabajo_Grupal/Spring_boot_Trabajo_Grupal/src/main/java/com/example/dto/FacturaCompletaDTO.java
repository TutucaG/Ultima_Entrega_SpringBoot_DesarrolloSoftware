package com.example.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.List;

// Factura con cabecera e items (GET /api/facturas/{id}).
// Lo usa el frontend para "Ver" y para cargar el modal de edicion de un borrador,
// y el backend para armar el PDF del comprobante.
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaCompletaDTO {

    private Long id;
    private String letra;                  // A | B
    private int codigoComprobante;         // codigo ARCA: 1 = Factura A, 6 = Factura B
    private Long numeroFactura;
    private String estado;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date fechaEmision;

    private Long puntoVentaId;
    private int puntoVentaNumero;
    private String puntoVentaDescripcion;

    private Long clienteId;                // null = Consumidor Final
    private String clienteDenominacion;
    private String clienteCuitCuil;
    private String clienteDomicilio;

    private Long condicionIvaId;
    private String condicionIva;

    private Long tipoMonedaId;
    private String tipoMoneda;
    private String simboloMoneda;

    private Long listaPrecioId;
    private String listaPrecio;

    private double importeNeto;
    private double importeIva;
    private double importeTotal;

    private String cae;
    private String resultadoAfip;          // A | R | null
    private String motivoRechazo;          // mensaje de ARCA si el ultimo intento fue rechazado

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date caeFechaVencimiento;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date fechaAnulacion;

    private String observaciones;

    private List<FacturaItemDTO> detalles;

}
