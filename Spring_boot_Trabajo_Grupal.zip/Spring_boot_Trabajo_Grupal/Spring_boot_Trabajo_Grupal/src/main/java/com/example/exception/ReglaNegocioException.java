package com.example.exception;

// Operacion valida en forma pero prohibida por las reglas de facturacion
// (ej. modificar una factura ANULADA). Se traduce a 409 Conflict.
public class ReglaNegocioException extends RuntimeException {

    public ReglaNegocioException(String mensaje) {
        super(mensaje);
    }
}
