package com.example.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Fila del explorer de articulos de una lista de precios (GET /api/listas-precio/{id}/articulos?q=).
// Representa una ListaPrecioArticulo: el articulo con el precio que tiene en ESA lista.
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ArticuloPrecioDTO {

    private Long listaPrecioArticuloId;
    private Long articuloId;
    private String codigo;
    private String denominacion;
    private String rubro;
    private String marca;
    private double precio; // precio neto (sin IVA) en la lista elegida

}
