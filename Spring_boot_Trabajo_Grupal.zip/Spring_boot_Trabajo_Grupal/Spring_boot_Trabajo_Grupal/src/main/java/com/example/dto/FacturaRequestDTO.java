package com.example.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.OptBoolean;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

// Datos que manda el cliente para crear (POST) o modificar (PUT) una factura.
// Las relaciones viajan como IDs, nunca como entidades anidadas.
//
// POST: puntoVentaId, condicionIvaId, tipoMonedaId, listaPrecioId y detalles son obligatorios.
// PUT : todos los campos son opcionales; solo se actualiza lo que viene (no null).
//       Ej. para anular alcanza con {"estado": "ANULADA", "observaciones": "..."}
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaRequestDTO {

    // LocalDate y no Date para que "2026-05-10" no se corra un dia por la zona horaria
    // "uuuu" + lenient FALSE: "2026-02-30" se rechaza (si no, Jackson lo convertia en 28/02 sin avisar)
    @JsonFormat(pattern = "uuuu-MM-dd", lenient = OptBoolean.FALSE)
    private LocalDate fechaEmision;       // si no viene en el POST se usa la fecha de hoy

    private Long clienteId;               // null = Consumidor Final
    private Long condicionIvaId;
    private Long puntoVentaId;
    private Long tipoMonedaId;
    private Long listaPrecioId;           // lista de precios de la que salen los articulos de los detalles

    private String estado;                // ANULADA para anular (en el POST se ignora: nace BORRADOR)
    private String observaciones;

    private List<FacturaDetalleRequestDTO> detalles;

}
