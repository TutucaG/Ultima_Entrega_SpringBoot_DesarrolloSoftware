package com.example.controller;

import com.example.dto.ArticuloPrecioDTO;
import com.example.dto.CatalogoDTO;
import com.example.dto.ClienteExplorerDTO;
import com.example.service.CatalogoService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Endpoints auxiliares del frontend: combos chicos y los explorers de clientes y articulos
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class CatalogoRestController {

    private final CatalogoService catalogoService;

    // GET /api/catalogos -> condiciones de IVA, puntos de venta, monedas y listas de precios
    @GetMapping("/catalogos")
    public CatalogoDTO obtenerCatalogo() {
        return catalogoService.obtenerCatalogo();
    }

    // GET /api/clientes?q=texto -> explorer de clientes (razon social o CUIT)
    @GetMapping("/clientes")
    public List<ClienteExplorerDTO> buscarClientes(@RequestParam(required = false) String q) {
        return catalogoService.buscarClientes(q);
    }

    // GET /api/listas-precio/{id}/articulos?q=texto -> explorer de articulos de esa lista, con su precio
    @GetMapping("/listas-precio/{id:\\d+}/articulos")
    public List<ArticuloPrecioDTO> buscarArticulos(@PathVariable Long id, @RequestParam(required = false) String q) {
        return catalogoService.buscarArticulosDeLista(id, q);
    }
}
