package com.example.controller;

import com.example.dto.ArcaEstadoDTO;
import com.example.service.ArcaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/arca")
@RequiredArgsConstructor
public class ArcaRestController {

    private final ArcaService arcaService;

    // GET /api/arca/estado -> modo configurado y, en homologacion, estado de los servidores (FEDummy)
    @GetMapping("/estado")
    public ArcaEstadoDTO estado() {
        return arcaService.estado();
    }
}
