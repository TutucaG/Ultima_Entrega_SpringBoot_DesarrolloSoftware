package com.example.arca;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

// Utilidades para hablar SOAP con ARCA sin generar clases con wsimport:
// enviar el sobre XML por HTTP POST y leer la respuesta con DOM.
final class Soap {

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    private Soap() {
    }

    static String enviar(String url, String soapAction, String sobre) {
        HttpRequest pedido = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(40))
                .header("Content-Type", "text/xml; charset=utf-8")
                .header("SOAPAction", "\"" + soapAction + "\"")
                .POST(HttpRequest.BodyPublishers.ofString(sobre, StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> respuesta;
        try {
            respuesta = HTTP.send(pedido, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ArcaException("Se interrumpió la comunicación con ARCA", e);
        } catch (Exception e) {
            throw new ArcaException("No se pudo conectar con ARCA (" + url + "): " + e.getMessage(), e);
        }

        String cuerpo = respuesta.body();
        // Los errores SOAP llegan con HTTP 500 y un <faultstring> que explica el motivo
        if (cuerpo != null && cuerpo.contains("Fault")) {
            String falla = texto(parsear(cuerpo).getDocumentElement(), "faultstring");
            if (falla != null) {
                throw new ArcaException("ARCA respondió con un error: " + falla);
            }
        }
        if (respuesta.statusCode() != 200) {
            throw new ArcaException("ARCA respondió HTTP " + respuesta.statusCode() + " en " + url);
        }
        return cuerpo;
    }

    static Document parsear(String xml) {
        try {
            DocumentBuilderFactory fabrica = DocumentBuilderFactory.newInstance();
            fabrica.setNamespaceAware(true);
            // protege contra XXE: las respuestas no deben traer DOCTYPE ni entidades externas
            fabrica.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            fabrica.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            fabrica.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            return fabrica.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
        } catch (Exception e) {
            throw new ArcaException("La respuesta de ARCA no es un XML válido", e);
        }
    }

    // Texto del primer descendiente con ese nombre (sin importar el namespace), o null
    static String texto(Element padre, String nombre) {
        NodeList nodos = padre.getElementsByTagNameNS("*", nombre);
        return nodos.getLength() == 0 ? null : nodos.item(0).getTextContent().trim();
    }

    static List<Element> elementos(Element padre, String nombre) {
        NodeList nodos = padre.getElementsByTagNameNS("*", nombre);
        List<Element> lista = new ArrayList<>();
        for (int i = 0; i < nodos.getLength(); i++) {
            lista.add((Element) nodos.item(i));
        }
        return lista;
    }

    static String escapar(String texto) {
        return texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
