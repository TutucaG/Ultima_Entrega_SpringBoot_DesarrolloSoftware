package com.example.arca;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

// Configuracion de la conexion con ARCA (application.properties -> app.arca.*)
//
//  modo = simulado      -> no se conecta a nada: valida y genera un CAE de prueba (sirve sin certificado)
//  modo = homologacion  -> usa los webservices reales de testing de ARCA (WSAA + WSFEv1)
//                          con el certificado y la clave privada del CUIT configurado
@Getter
@Component
public class ArcaConfig {

    public static final String MODO_SIMULADO = "simulado";
    public static final String MODO_HOMOLOGACION = "homologacion";

    @Value("${app.arca.modo:simulado}")
    private String modo;

    @Value("${app.arca.cuit:0}")
    private long cuit;

    @Value("${app.arca.certificado:}")
    private String certificado;

    @Value("${app.arca.clave-privada:}")
    private String clavePrivada;

    @Value("${app.arca.wsaa-url:https://wsaahomo.afip.gov.ar/ws/services/LoginCms}")
    private String wsaaUrl;

    @Value("${app.arca.wsfe-url:https://wswhomo.afip.gov.ar/wsfev1/service.asmx}")
    private String wsfeUrl;

    // Donde se guarda el ticket de acceso (dura 12 h y WSAA no entrega otro mientras siga vigente)
    @Value("${app.arca.ticket-cache:${java.io.tmpdir}/arca-ticket-wsfe.properties}")
    private String ticketCache;

    public boolean esModoReal() {
        return MODO_HOMOLOGACION.equalsIgnoreCase(modo.trim());
    }
}
