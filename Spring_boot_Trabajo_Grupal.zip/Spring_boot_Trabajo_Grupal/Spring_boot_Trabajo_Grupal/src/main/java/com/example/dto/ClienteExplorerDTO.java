package com.example.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Fila del explorer de clientes (GET /api/clientes?q=)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClienteExplorerDTO {

    private Long id;
    private String cuitCuil;
    private String denominacion;
    private String domicilio;
    private String email;
    private String telefono;
    private Long condicionIvaId;     // null si el cliente no la tiene cargada
    private String condicionIva;

}
