package com.example.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

// Fila del listado / reporte de facturas.
// El orden de los campos es el del constructor que usa la consulta JPQL (SELECT new ...).
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaReporteDTO {

    // id interno: lo necesita el frontend para llamar a PUT / DELETE /api/facturas/{id}
    private Long id;

    private String letra;       // A | B (tipo de comprobante segun la condicion de IVA del receptor)

    private Long numeroFactura; // null mientras la factura es BORRADOR (todavia no autorizada por ARCA)

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date fechaEmision;

    private String clienteDenominacion;
    private String condicionIva;
    private String puntoVentaDescripcion;
    private int puntoVentaNumero;
    private double importeTotal;
    private long cantidadItems;

    private String estado;
    private String observaciones;
    private String cae;
    private String resultadoAfip; // A = aprobada, R = ultimo intento rechazado por ARCA, null = sin enviar

}
