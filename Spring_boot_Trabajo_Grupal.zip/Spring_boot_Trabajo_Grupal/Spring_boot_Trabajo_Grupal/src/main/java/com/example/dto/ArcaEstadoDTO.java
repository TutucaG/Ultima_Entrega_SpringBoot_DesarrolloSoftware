package com.example.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Estado de la conexion con ARCA (GET /api/arca/estado)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ArcaEstadoDTO {

    private String modo;            // simulado | homologacion
    private Long cuit;              // CUIT emisor configurado (solo homologacion)
    private String wsfeUrl;         // servidor WSFEv1 usado (solo homologacion)
    private Boolean servidoresOk;   // resultado de FEDummy (null en modo simulado)
    private String detalle;

}
