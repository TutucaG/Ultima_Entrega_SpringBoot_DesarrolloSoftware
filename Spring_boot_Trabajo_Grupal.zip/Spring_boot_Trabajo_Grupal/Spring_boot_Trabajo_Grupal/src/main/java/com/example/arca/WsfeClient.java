package com.example.arca;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Element;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// WSFEv1 (Factura Electronica) de ARCA. Se arma el XML a mano para no depender de clases
// generadas con wsimport; los nombres y el orden de los campos son los del WSDL oficial.
@Component
@RequiredArgsConstructor
public class WsfeClient {

    private static final String NS = "http://ar.gov.afip.dif.FEV1/";
    private static final DateTimeFormatter FECHA_ARCA = DateTimeFormatter.BASIC_ISO_DATE; // yyyyMMdd

    // Codigos de las tablas de ARCA
    public static final int CONCEPTO_PRODUCTOS = 1;
    public static final int DOC_CUIT = 80;
    public static final int DOC_SIN_IDENTIFICAR = 99; // Consumidor Final
    public static final int IVA_21 = 5;               // Id de alicuota 21 %

    private final ArcaConfig config;

    public record EstadoServidores(String appServer, String dbServer, String authServer) {
        public boolean todosOk() {
            return "OK".equals(appServer) && "OK".equals(dbServer) && "OK".equals(authServer);
        }
    }

    public record SolicitudCae(int puntoVenta, int tipoComprobante, long numero, LocalDate fecha,
                               int docTipo, long docNro, int condicionIvaReceptor,
                               double neto, double iva, String moneda) {
    }

    // resultado: A = aprobado, R = rechazado, P = parcial. mensajes: errores y observaciones de ARCA
    public record RespuestaCae(String resultado, String cae, LocalDate vencimientoCae, long numero,
                               List<String> mensajes) {
        public boolean aprobada() {
            return "A".equals(resultado) && cae != null && !cae.isBlank();
        }
    }

    // ------------------------------------------------------------------ metodos del webservice

    // FEDummy: estado de los servidores de ARCA (no necesita autenticacion)
    public EstadoServidores consultarEstado() {
        String respuesta = Soap.enviar(config.getWsfeUrl(), NS + "FEDummy", sobre("<ar:FEDummy/>"));
        return leerEstado(respuesta);
    }

    // FECompUltimoAutorizado: ultimo numero autorizado para ese punto de venta y tipo
    public long ultimoAutorizado(WsaaClient.TicketAcceso ticket, int puntoVenta, int tipoComprobante) {
        String cuerpo = "<ar:FECompUltimoAutorizado>" + auth(ticket)
                + "<ar:PtoVta>" + puntoVenta + "</ar:PtoVta>"
                + "<ar:CbteTipo>" + tipoComprobante + "</ar:CbteTipo>"
                + "</ar:FECompUltimoAutorizado>";
        String respuesta = Soap.enviar(config.getWsfeUrl(), NS + "FECompUltimoAutorizado", sobre(cuerpo));
        return leerUltimoAutorizado(respuesta);
    }

    // FECAESolicitar: pide el CAE para un comprobante
    public RespuestaCae solicitarCae(WsaaClient.TicketAcceso ticket, SolicitudCae solicitud) {
        String respuesta = Soap.enviar(config.getWsfeUrl(), NS + "FECAESolicitar",
                sobre(cuerpoSolicitarCae(auth(ticket), solicitud)));
        return leerRespuestaCae(respuesta);
    }

    // ------------------------------------------------------------------ armado de XML (package-private para tests)

    static String cuerpoSolicitarCae(String auth, SolicitudCae s) {
        String fecha = s.fecha().format(FECHA_ARCA);
        double total = redondear(s.neto() + s.iva());
        return "<ar:FECAESolicitar>" + auth
                + "<ar:FeCAEReq>"
                + "<ar:FeCabReq><ar:CantReg>1</ar:CantReg>"
                + "<ar:PtoVta>" + s.puntoVenta() + "</ar:PtoVta>"
                + "<ar:CbteTipo>" + s.tipoComprobante() + "</ar:CbteTipo></ar:FeCabReq>"
                + "<ar:FeDetReq><ar:FECAEDetRequest>"
                + "<ar:Concepto>" + CONCEPTO_PRODUCTOS + "</ar:Concepto>"
                + "<ar:DocTipo>" + s.docTipo() + "</ar:DocTipo>"
                + "<ar:DocNro>" + s.docNro() + "</ar:DocNro>"
                + "<ar:CbteDesde>" + s.numero() + "</ar:CbteDesde>"
                + "<ar:CbteHasta>" + s.numero() + "</ar:CbteHasta>"
                + "<ar:CbteFch>" + fecha + "</ar:CbteFch>"
                + "<ar:ImpTotal>" + importe(total) + "</ar:ImpTotal>"
                + "<ar:ImpTotConc>0.00</ar:ImpTotConc>"
                + "<ar:ImpNeto>" + importe(s.neto()) + "</ar:ImpNeto>"
                + "<ar:ImpOpEx>0.00</ar:ImpOpEx>"
                + "<ar:ImpTrib>0.00</ar:ImpTrib>"
                + "<ar:ImpIVA>" + importe(s.iva()) + "</ar:ImpIVA>"
                + "<ar:MonId>" + Soap.escapar(s.moneda()) + "</ar:MonId>"
                + "<ar:MonCotiz>1</ar:MonCotiz>"
                + "<ar:CondicionIVAReceptorId>" + s.condicionIvaReceptor() + "</ar:CondicionIVAReceptorId>"
                + "<ar:Iva><ar:AlicIva>"
                + "<ar:Id>" + IVA_21 + "</ar:Id>"
                + "<ar:BaseImp>" + importe(s.neto()) + "</ar:BaseImp>"
                + "<ar:Importe>" + importe(s.iva()) + "</ar:Importe>"
                + "</ar:AlicIva></ar:Iva>"
                + "</ar:FECAEDetRequest></ar:FeDetReq>"
                + "</ar:FeCAEReq></ar:FECAESolicitar>";
    }

    static EstadoServidores leerEstado(String respuesta) {
        Element raiz = Soap.parsear(respuesta).getDocumentElement();
        return new EstadoServidores(Soap.texto(raiz, "AppServer"), Soap.texto(raiz, "DbServer"),
                Soap.texto(raiz, "AuthServer"));
    }

    static long leerUltimoAutorizado(String respuesta) {
        Element raiz = Soap.parsear(respuesta).getDocumentElement();
        List<String> errores = mensajes(raiz, "Err");
        String numero = Soap.texto(raiz, "CbteNro");
        if (!errores.isEmpty() || numero == null) {
            throw new ArcaException("ARCA no informó el último comprobante: "
                    + (errores.isEmpty() ? "respuesta sin número" : String.join("; ", errores)));
        }
        return Long.parseLong(numero);
    }

    static RespuestaCae leerRespuestaCae(String respuesta) {
        Element raiz = Soap.parsear(respuesta).getDocumentElement();
        List<String> mensajes = new ArrayList<>(mensajes(raiz, "Err"));
        mensajes.addAll(mensajes(raiz, "Obs"));

        String resultado = Soap.texto(raiz, "Resultado");
        String cae = Soap.texto(raiz, "CAE");
        String vencimiento = Soap.texto(raiz, "CAEFchVto");
        String numero = Soap.texto(raiz, "CbteDesde");
        return new RespuestaCae(
                resultado == null ? "R" : resultado,
                cae == null || cae.isBlank() ? null : cae,
                vencimiento == null || vencimiento.isBlank() ? null : LocalDate.parse(vencimiento, FECHA_ARCA),
                numero == null || numero.isBlank() ? 0 : Long.parseLong(numero),
                mensajes);
    }

    // ------------------------------------------------------------------ auxiliares

    private static List<String> mensajes(Element raiz, String etiqueta) {
        List<String> lista = new ArrayList<>();
        for (Element e : Soap.elementos(raiz, etiqueta)) {
            lista.add(Soap.texto(e, "Code") + " - " + Soap.texto(e, "Msg"));
        }
        return lista;
    }

    private String auth(WsaaClient.TicketAcceso ticket) {
        return "<ar:Auth><ar:Token>" + Soap.escapar(ticket.token()) + "</ar:Token>"
                + "<ar:Sign>" + Soap.escapar(ticket.sign()) + "</ar:Sign>"
                + "<ar:Cuit>" + config.getCuit() + "</ar:Cuit></ar:Auth>";
    }

    private static String sobre(String cuerpo) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ar=\"" + NS + "\">"
                + "<soap:Header/><soap:Body>" + cuerpo + "</soap:Body></soap:Envelope>";
    }

    private static String importe(double valor) {
        return String.format(Locale.US, "%.2f", valor);
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
