package com.example.service;

import com.example.arca.TipoComprobante;
import com.example.dto.*;
import com.example.entidades.*;
import com.example.exception.RecursoNoEncontradoException;
import com.example.exception.ReglaNegocioException;
import com.example.repository.CatalogoRepository;
import com.example.repository.FacturaVentaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;

// Ciclo de vida de un comprobante:
//
//   crear (POST)  ->  BORRADOR  (sin numero ni CAE: NO es una factura todavia; se puede editar y ELIMINAR)
//                        |
//   autorizar (ARCA)     v
//                     EMITIDA   (numero correlativo + CAE: recien ahi es una Factura A/B valida)
//                        |
//   anular (PUT)         v
//                     ANULADA   (fechaAnulacion = hoy; queda registrada)
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true) // por defecto solo lectura; los metodos de escritura lo sobreescriben
// Las escrituras sobre una factura existente usan READ COMMITTED + bloqueo de fila (SELECT ... FOR UPDATE):
// despues de esperar el bloqueo, cada lectura ve lo ultimo confirmado por la otra operacion.
// (En REPEATABLE READ, el default de MySQL, se leeria una "foto" vieja y dos autorizaciones
// simultaneas podian tomar el mismo numero.)
public class FacturaService {

    public static final String BORRADOR = "BORRADOR";
    public static final String EMITIDA = "EMITIDA";
    public static final String ANULADA = "ANULADA";
    public static final Set<String> ESTADOS = Set.of(BORRADOR, EMITIDA, ANULADA);

    // Alicuota general de IVA. Los precios de la lista de precios son netos (sin IVA).
    public static final double ALICUOTA_IVA = 21.0;

    // Codigo ARCA de la condicion "Consumidor Final" (unica posible si no se elige cliente)
    public static final int CONDICION_CONSUMIDOR_FINAL = 5;

    // Limites de los datos de entrada
    public static final int LARGO_MAXIMO_TEXTO = 255;
    public static final int MAXIMO_DETALLES = 100;
    public static final double CANTIDAD_MAXIMA = 99_999;
    private static final LocalDate FECHA_MINIMA = LocalDate.of(2000, 1, 1);
    private static final LocalDate FECHA_MAXIMA = LocalDate.of(2099, 12, 31);

    private final FacturaVentaRepository facturaVentaRepository;
    private final CatalogoRepository catalogoRepository;
    private final ArcaService arcaService;

    // =====================================================================
    // Lectura
    // =====================================================================

    public List<FacturaReporteDTO> buscarFacturasFiltradas(FacturaFiltrosDTO filtros) {
        if (filtros.getEstado() != null) {
            String estado = filtros.getEstado().trim().toUpperCase();
            if (!estado.isEmpty() && !ESTADOS.contains(estado)) {
                throw new IllegalArgumentException("Estado inválido: " + filtros.getEstado()
                        + ". Valores permitidos: BORRADOR, EMITIDA, ANULADA");
            }
            filtros.setEstado(estado.isEmpty() ? null : estado);
        }
        if (filtros.getFechaDesde() != null && filtros.getFechaHasta() != null
                && filtros.getFechaDesde().after(filtros.getFechaHasta())) {
            throw new IllegalArgumentException("fechaDesde no puede ser posterior a fechaHasta");
        }
        validarMonto(filtros.getMontoMinimo(), "montoMinimo");
        validarMonto(filtros.getMontoMaximo(), "montoMaximo");
        if (filtros.getMontoMinimo() != null && filtros.getMontoMaximo() != null
                && filtros.getMontoMinimo() > filtros.getMontoMaximo()) {
            throw new IllegalArgumentException("montoMinimo no puede ser mayor que montoMaximo");
        }
        if (filtros.getNumero() != null && filtros.getNumero() < 1) {
            throw new IllegalArgumentException("El número de comprobante debe ser mayor a 0");
        }
        if (filtros.getClienteId() != null && filtros.getClienteId() < 0) {
            throw new IllegalArgumentException("clienteId inválido");
        }
        return facturaVentaRepository.buscarFacturasFiltradas(filtros);
    }

    // Cabecera + items (para "Ver", editar un borrador y el PDF del comprobante)
    public FacturaCompletaDTO buscarPorId(Long id) {
        return aCompletaDTO(facturaVentaRepository.buscarPorId(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Comprobante", id)));
    }

    // =====================================================================
    // Creacion (POST) -> queda como BORRADOR, sin numero
    // =====================================================================

    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO dto) {
        if (dto.getPuntoVentaId() == null || dto.getTipoMonedaId() == null || dto.getListaPrecioId() == null) {
            throw new IllegalArgumentException("puntoVentaId, tipoMonedaId y listaPrecioId son obligatorios");
        }
        validarDetalles(dto.getDetalles());
        validarTexto(dto.getObservaciones(), "Las observaciones");
        LocalDate fecha = dto.getFechaEmision() != null ? dto.getFechaEmision() : LocalDate.now();
        validarFecha(fecha);

        // 1) Buscar las entidades asociadas por ID (404 si alguna no existe)
        PuntoVenta puntoVenta = buscar(PuntoVenta.class, dto.getPuntoVentaId(), "Punto de venta");
        TipoMoneda tipoMoneda = buscar(TipoMoneda.class, dto.getTipoMonedaId(), "Tipo de moneda");
        Cliente cliente = buscarClienteOpcional(dto.getClienteId());
        CondicionIva condicionIva = dto.getCondicionIvaId() != null
                ? buscar(CondicionIva.class, dto.getCondicionIvaId(), "Condición de IVA")
                : condicionPorDefecto(cliente);
        validarCondicionIva(cliente, condicionIva);
        ListaPrecio listaPrecio = buscar(ListaPrecio.class, dto.getListaPrecioId(), "Lista de precios");
        Usuario usuario = usuarioSistema();

        // 2) Mapear el DTO a la entidad. El numero y el CAE los asigna ARCA al autorizar.
        FacturaVenta factura = FacturaVenta.builder()
                .fechaEmision(java.sql.Date.valueOf(fecha))
                .puntoVenta(puntoVenta)
                .condicionIva(condicionIva)
                .tipoMoneda(tipoMoneda)
                .cliente(cliente)
                .estado(BORRADOR)
                .observaciones(textoOpcional(dto.getObservaciones()))
                .detalles(new ArrayList<>())
                .build();

        Date ahora = new Date();
        factura.setFechaAlta(ahora);
        factura.setUsuarioCarga(usuario);
        factura.setFechaModificacion(ahora);
        factura.setUsuarioModificacion(usuario);

        // 3) Detalles (articulos de la lista elegida) + calculo automatico de neto, IVA y total
        agregarDetalles(factura, listaPrecio, dto.getDetalles());
        recalcularTotales(factura);

        // 4) Guardar: el cascade ALL inserta tambien los detalles
        facturaVentaRepository.guardar(factura);
        facturaVentaRepository.sincronizar();

        return buscarReporte(factura.getId());
    }

    // =====================================================================
    // Actualizacion (PUT) - solo se cambia lo que viene distinto de null
    // =====================================================================
    //  BORRADOR -> se puede cambiar cabecera e items (no se anula: se elimina)
    //  EMITIDA  -> solo se puede anular (estado = ANULADA) y cambiar observaciones
    //  ANULADA  -> no admite cambios

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO dto) {
        FacturaVenta factura = buscarParaModificar(id);
        String estadoActual = factura.getEstado();

        if (ANULADA.equals(estadoActual)) {
            throw new ReglaNegocioException("El comprobante " + descripcion(factura)
                    + " está ANULADO y ya no puede modificarse");
        }

        String nuevoEstado = null;
        if (dto.getEstado() != null && !dto.getEstado().isBlank()) {
            nuevoEstado = dto.getEstado().trim().toUpperCase();
            if (!ESTADOS.contains(nuevoEstado)) {
                throw new IllegalArgumentException("Estado inválido: " + dto.getEstado()
                        + ". Valores permitidos: BORRADOR, EMITIDA, ANULADA");
            }
            if (nuevoEstado.equals(estadoActual)) {
                nuevoEstado = null; // sin cambio de estado
            } else if (EMITIDA.equals(nuevoEstado)) {
                throw new ReglaNegocioException("Para emitir una factura hay que autorizarla en ARCA "
                        + "(POST /api/facturas/" + id + "/autorizar)");
            } else if (BORRADOR.equals(nuevoEstado)) {
                throw new ReglaNegocioException("Una factura emitida no puede volver a borrador; debe anularse");
            } else if (BORRADOR.equals(estadoActual)) { // pide ANULADA sobre un borrador
                throw new ReglaNegocioException("El borrador no tiene número de comprobante: "
                        + "no se anula, se elimina (DELETE)");
            }
        }

        boolean modificaDatos = dto.getFechaEmision() != null || dto.getPuntoVentaId() != null
                || dto.getCondicionIvaId() != null || dto.getTipoMonedaId() != null
                || dto.getClienteId() != null || dto.getListaPrecioId() != null || dto.getDetalles() != null;
        if (modificaDatos && !BORRADOR.equals(estadoActual)) {
            throw new ReglaNegocioException("El comprobante " + descripcion(factura)
                    + " ya fue autorizado por ARCA: sus datos no pueden modificarse, solo anularse");
        }
        validarTexto(dto.getObservaciones(), "Las observaciones");
        if (dto.getDetalles() != null) {
            validarDetalles(dto.getDetalles());
        }

        // ---- Cabecera ----
        if (dto.getFechaEmision() != null) {
            validarFecha(dto.getFechaEmision());
            factura.setFechaEmision(java.sql.Date.valueOf(dto.getFechaEmision()));
        }
        if (dto.getPuntoVentaId() != null) {
            factura.setPuntoVenta(buscar(PuntoVenta.class, dto.getPuntoVentaId(), "Punto de venta"));
        }
        if (dto.getTipoMonedaId() != null) {
            factura.setTipoMoneda(buscar(TipoMoneda.class, dto.getTipoMonedaId(), "Tipo de moneda"));
        }
        if (dto.getClienteId() != null) {
            // clienteId = 0 -> pasa a Consumidor Final
            factura.setCliente(buscarClienteOpcional(dto.getClienteId()));
        }
        if (dto.getCondicionIvaId() != null) {
            factura.setCondicionIva(buscar(CondicionIva.class, dto.getCondicionIvaId(), "Condición de IVA"));
        } else if (dto.getClienteId() != null) {
            // cambio el cliente y no se informo la condicion: se toma la del cliente nuevo
            factura.setCondicionIva(condicionPorDefecto(factura.getCliente()));
        }
        validarCondicionIva(factura.getCliente(), factura.getCondicionIva());
        if (dto.getObservaciones() != null) {
            String observaciones = textoOpcional(dto.getObservaciones());
            String anteriores = factura.getObservaciones();
            if (ANULADA.equals(nuevoEstado) && observaciones != null && anteriores != null && !anteriores.isBlank()) {
                // el motivo de anulacion se agrega: no borra las observaciones que ya tenia el comprobante
                observaciones = recortar(anteriores + " | Motivo de anulación: " + observaciones, LARGO_MAXIMO_TEXTO);
            }
            factura.setObservaciones(observaciones);
        }

        if (modificaDatos) {
            // el borrador cambio: el rechazo anterior de ARCA ya no aplica
            factura.setResultadoAfip(null);
            factura.setMotivoRechazo(null);
        }

        // ---- Items: si vienen, reemplazan a los anteriores. Si solo cambia la lista de precios,
        //      se vuelven a cotizar los mismos articulos con los precios de la lista nueva ----
        ListaPrecio listaPrecio = dto.getListaPrecioId() != null
                ? buscar(ListaPrecio.class, dto.getListaPrecioId(), "Lista de precios")
                : listaDe(factura);
        List<FacturaDetalleRequestDTO> nuevosDetalles = dto.getDetalles();
        if (nuevosDetalles == null && dto.getListaPrecioId() != null) {
            nuevosDetalles = factura.getDetalles().stream()
                    .map(d -> new FacturaDetalleRequestDTO(d.getListaPrecioArticulo().getArticulo().getId(),
                            d.getCantidad(), d.getPorcentajeBonificacion(), d.getDescripcion()))
                    .toList();
        }
        if (nuevosDetalles != null) {
            validarDetalles(nuevosDetalles);
            if (listaPrecio == null) {
                throw new IllegalArgumentException("listaPrecioId es obligatorio para cargar los detalles");
            }
            factura.getDetalles().clear(); // orphanRemoval borra los renglones viejos
            agregarDetalles(factura, listaPrecio, nuevosDetalles);
            recalcularTotales(factura);
        }

        // ---- Anulacion logica (solo facturas EMITIDAS, ya validado arriba) ----
        if (ANULADA.equals(nuevoEstado)) {
            factura.setEstado(ANULADA);
            factura.setFechaAnulacion(new Date());
        }

        factura.setFechaModificacion(new Date());
        factura.setUsuarioModificacion(usuarioSistema());

        facturaVentaRepository.sincronizar();
        return buscarReporte(factura.getId());
    }

    // =====================================================================
    // Autorizacion en ARCA (POST /{id}/autorizar): asigna numero y CAE
    // =====================================================================
    // noRollbackFor: si ARCA rechaza el comprobante, igual se guarda el resultado "R" y el motivo
    // (la factura sigue como BORRADOR para poder corregirla y volver a enviarla).

    @Transactional(isolation = Isolation.READ_COMMITTED, noRollbackFor = ReglaNegocioException.class)
    public FacturaReporteDTO autorizar(Long id) {
        FacturaVenta factura = buscarParaModificar(id);
        if (!BORRADOR.equals(factura.getEstado())) {
            throw new ReglaNegocioException("El comprobante " + descripcion(factura)
                    + " ya fue autorizado (estado " + factura.getEstado() + ")");
        }
        // datos incoherentes (p. ej. cargados antes de estas validaciones): se corrigen con "Editar"
        try {
            validarCondicionIva(factura.getCliente(), factura.getCondicionIva());
        } catch (IllegalArgumentException e) {
            throw new ReglaNegocioException("No se puede autorizar: " + e.getMessage() + " (corregilo con Editar)");
        }
        // un borrador guardado antes de exigir cantidades enteras no puede salir con media unidad
        for (FacturaVentaDetalle d : factura.getDetalles()) {
            if (!esEntera(d.getCantidad())) {
                throw new ReglaNegocioException("No se puede autorizar: el ítem " + d.getDescripcion()
                        + " tiene cantidad " + d.getCantidad() + " y tiene que ser un número entero (corregilo con Editar)");
            }
        }

        // Un solo comprobante a la vez por punto de venta: evita que dos autorizaciones
        // simultaneas tomen el mismo numero
        facturaVentaRepository.bloquearPuntoVenta(factura.getPuntoVenta().getId());

        TipoComprobante tipo = TipoComprobante.para(factura.getCondicionIva());
        ArcaService.Autorizacion autorizacion;
        try {
            validarFechaContraUltimo(factura, tipo);
            autorizacion = arcaService.autorizar(factura,
                    () -> facturaVentaRepository.siguienteNumero(factura.getPuntoVenta().getId(), tipo));
        } catch (ReglaNegocioException rechazo) {
            factura.setResultadoAfip("R"); // R = rechazado
            factura.setMotivoRechazo(recortar(rechazo.getMessage(), LARGO_MAXIMO_TEXTO));
            factura.setFechaModificacion(new Date());
            factura.setUsuarioModificacion(usuarioSistema());
            throw rechazo; // 409 con el motivo
        }

        factura.setNumero(autorizacion.numero());
        factura.setCae(autorizacion.cae());
        factura.setCaeFechaVencimiento(autorizacion.fechaVencimiento());
        factura.setResultadoAfip("A"); // A = aprobado
        factura.setMotivoRechazo(null);
        factura.setEstado(EMITIDA);
        factura.setFechaModificacion(new Date());
        factura.setUsuarioModificacion(usuarioSistema());

        facturaVentaRepository.sincronizar();
        return buscarReporte(factura.getId());
    }

    // =====================================================================
    // Eliminacion (DELETE) - borrado fisico
    // =====================================================================
    // Regla de negocio: solo se elimina un comprobante SIN numero (borrador).
    // Si ya tiene numero/CAE es un comprobante fiscal: no se borra, se anula (PUT estado ANULADA).

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void eliminar(Long id) {
        FacturaVenta factura = buscarParaModificar(id);

        if (factura.getNumero() != null || (factura.getCae() != null && !factura.getCae().isBlank())) {
            throw new ReglaNegocioException("El comprobante " + descripcion(factura)
                    + " tiene número de comprobante y no puede eliminarse; debe anularse");
        }
        facturaVentaRepository.eliminar(factura);
    }

    // =====================================================================
    // Auxiliares
    // =====================================================================

    // Lectura con bloqueo de fila: dos operaciones de escritura sobre la misma factura no se pisan
    private FacturaVenta buscarParaModificar(Long id) {
        return facturaVentaRepository.buscarParaModificar(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Comprobante", id));
    }

    private FacturaReporteDTO buscarReporte(Long id) {
        return facturaVentaRepository.buscarReportePorId(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Comprobante", id));
    }

    // Cada detalle guarda la ListaPrecioArticulo: el articulo con el precio de la lista elegida
    private void agregarDetalles(FacturaVenta factura, ListaPrecio lista, List<FacturaDetalleRequestDTO> detallesDto) {
        for (FacturaDetalleRequestDTO d : detallesDto) {
            Articulo articulo = buscar(Articulo.class, d.getArticuloId(), "Artículo");
            ListaPrecioArticulo precio = catalogoRepository.buscarPrecio(lista.getId(), d.getArticuloId())
                    .orElseThrow(() -> new RecursoNoEncontradoException("El artículo " + articulo.getCodigo()
                            + " no está en la lista de precios " + lista.getDenominacion()));

            double cantidad = d.getCantidad();
            double bonificacion = d.getPorcentajeBonificacion() == null ? 0 : d.getPorcentajeBonificacion();
            double precioUnitario = precio.getPrecioVenta();

            double bruto = cantidad * precioUnitario;
            double neto = redondear(bruto - bruto * bonificacion / 100);
            double iva = redondear(neto * ALICUOTA_IVA / 100);

            FacturaVentaDetalle detalle = new FacturaVentaDetalle();
            detalle.setFactura(factura); // relacion bidireccional
            detalle.setListaPrecioArticulo(precio);
            String descripcion = textoOpcional(d.getDescripcion());
            detalle.setDescripcion(descripcion != null ? descripcion : precio.getArticulo().getDenominacion());
            detalle.setCantidad(cantidad);
            detalle.setPrecioUnitario(precioUnitario);
            detalle.setPorcentajeBonificacion(bonificacion);
            detalle.setImporteNeto(neto);
            detalle.setImporteIva(iva);
            detalle.setImporteSubtotal(redondear(neto + iva));

            factura.getDetalles().add(detalle);
        }
    }

    // Lista de precios de una factura guardada: la de sus detalles (todos salen de la misma lista)
    private static ListaPrecio listaDe(FacturaVenta factura) {
        return factura.getDetalles() == null || factura.getDetalles().isEmpty() ? null
                : factura.getDetalles().get(0).getListaPrecioArticulo().getListaPrecio();
    }

    private void recalcularTotales(FacturaVenta factura) {
        double total = factura.getDetalles().stream()
                .mapToDouble(FacturaVentaDetalle::getImporteSubtotal)
                .sum();
        factura.setImporteTotal(redondear(total));
        factura.setImporteSaldo(redondear(total - factura.getImporteCobrado()));
    }

    private void validarDetalles(List<FacturaDetalleRequestDTO> detalles) {
        if (detalles == null || detalles.isEmpty()) {
            throw new IllegalArgumentException("El comprobante debe tener al menos un detalle");
        }
        if (detalles.size() > MAXIMO_DETALLES) {
            throw new IllegalArgumentException("Un comprobante admite como máximo " + MAXIMO_DETALLES + " renglones");
        }
        Set<Long> articulos = new HashSet<>();
        for (int i = 0; i < detalles.size(); i++) {
            FacturaDetalleRequestDTO d = detalles.get(i);
            String renglon = "Detalle " + (i + 1) + ": ";
            if (d == null || d.getArticuloId() == null) {
                throw new IllegalArgumentException(renglon + "articuloId es obligatorio");
            }
            if (!articulos.add(d.getArticuloId())) {
                throw new IllegalArgumentException(renglon + "el artículo está repetido; "
                        + "modificá la cantidad del renglón existente");
            }
            Double cantidad = d.getCantidad();
            if (cantidad == null || !Double.isFinite(cantidad) || cantidad <= 0) {
                throw new IllegalArgumentException(renglon + "la cantidad debe ser mayor a 0");
            }
            if (cantidad > CANTIDAD_MAXIMA) {
                throw new IllegalArgumentException(renglon + "la cantidad no puede superar "
                        + String.format(Locale.forLanguageTag("es-AR"), "%,.0f", CANTIDAD_MAXIMA));
            }
            if (!esEntera(cantidad)) {
                throw new IllegalArgumentException(renglon + "la cantidad tiene que ser un número entero "
                        + "(los artículos se venden por unidad)");
            }
            Double bonif = d.getPorcentajeBonificacion();
            if (bonif != null && (!Double.isFinite(bonif) || bonif < 0 || bonif > 100)) {
                throw new IllegalArgumentException(renglon + "la bonificación debe estar entre 0 y 100");
            }
            if (bonif != null && !tieneHastaDosDecimales(bonif)) {
                throw new IllegalArgumentException(renglon + "la bonificación admite hasta 2 decimales");
            }
            validarTexto(d.getDescripcion(), renglon + "la descripción");
        }
    }

    // Sin cliente solo se puede facturar a Consumidor Final; con cliente, la condicion es la del cliente
    private void validarCondicionIva(Cliente cliente, CondicionIva condicion) {
        if (cliente == null) {
            if (condicion.getCodigoAfip() != CONDICION_CONSUMIDOR_FINAL) {
                throw new IllegalArgumentException("Sin cliente (Consumidor Final) la condición de IVA tiene que ser "
                        + "Consumidor Final. Para facturar a \"" + condicion.getDenominacion()
                        + "\" hay que elegir el cliente");
            }
            return;
        }
        CondicionIva propia = cliente.getCondicionIva();
        if (propia != null && !Objects.equals(propia.getId(), condicion.getId())) {
            throw new IllegalArgumentException("El cliente " + cliente.getDenominacion() + " es \""
                    + propia.getDenominacion() + "\"; la factura no puede ir como \""
                    + condicion.getDenominacion() + "\"");
        }
    }

    private CondicionIva condicionPorDefecto(Cliente cliente) {
        if (cliente != null) {
            if (cliente.getCondicionIva() == null) {
                throw new IllegalArgumentException("El cliente " + cliente.getDenominacion()
                        + " no tiene condición de IVA cargada: indicá condicionIvaId");
            }
            return cliente.getCondicionIva();
        }
        return catalogoRepository.buscarCondicionPorCodigo(CONDICION_CONSUMIDOR_FINAL)
                .orElseThrow(() -> new ReglaNegocioException("No existe la condición de IVA Consumidor Final"));
    }

    private static void validarFecha(LocalDate fecha) {
        if (fecha.isBefore(FECHA_MINIMA) || fecha.isAfter(FECHA_MAXIMA)) {
            throw new IllegalArgumentException("La fecha de emisión " + fecha + " no es válida");
        }
    }

    private static void validarTexto(String texto, String campo) {
        if (texto != null && texto.trim().length() > LARGO_MAXIMO_TEXTO) {
            throw new IllegalArgumentException(campo + " no pueden superar " + LARGO_MAXIMO_TEXTO + " caracteres");
        }
    }

    private static void validarMonto(Double monto, String campo) {
        if (monto != null && (!Double.isFinite(monto) || monto < 0)) {
            throw new IllegalArgumentException(campo + " debe ser un número mayor o igual a 0");
        }
    }

    // Los articulos se venden por unidad (no se vende media botella de agua)
    private static boolean esEntera(double valor) {
        return valor == Math.rint(valor);
    }

    private static boolean tieneHastaDosDecimales(double valor) {
        double centesimos = valor * 100;
        return Math.abs(centesimos - Math.rint(centesimos)) < 1e-6;
    }

    private FacturaCompletaDTO aCompletaDTO(FacturaVenta f) {
        List<FacturaItemDTO> items = f.getDetalles().stream()
                .map(d -> new FacturaItemDTO(
                        d.getListaPrecioArticulo().getId(),
                        d.getListaPrecioArticulo().getArticulo().getId(),
                        d.getListaPrecioArticulo().getArticulo().getCodigo(),
                        d.getDescripcion(), d.getCantidad(), d.getPrecioUnitario(),
                        d.getPorcentajeBonificacion(), d.getImporteNeto(), d.getImporteIva(),
                        d.getImporteSubtotal()))
                .toList();

        double neto = redondear(items.stream().mapToDouble(FacturaItemDTO::getImporteNeto).sum());
        double iva = redondear(items.stream().mapToDouble(FacturaItemDTO::getImporteIva).sum());

        Cliente c = f.getCliente();
        String domicilio = (c == null || c.getDomicilio() == null) ? null
                : (c.getDomicilio().getNombreCalle() + " " + c.getDomicilio().getNumeroCalle()).trim();

        TipoComprobante tipo = TipoComprobante.para(f.getCondicionIva());
        ListaPrecio lista = listaDe(f);
        return new FacturaCompletaDTO(
                f.getId(), tipo.getLetra(), tipo.getCodigoArca(), f.getNumero(), f.getEstado(), f.getFechaEmision(),
                f.getPuntoVenta().getId(), f.getPuntoVenta().getNumero(), f.getPuntoVenta().getDescripcion(),
                c == null ? null : c.getId(),
                c == null ? "Consumidor Final" : c.getDenominacion(),
                c == null ? null : c.getCuitCuil(),
                domicilio,
                c == null || c.getCondicionIva() == null ? null : c.getCondicionIva().getId(),
                f.getCondicionIva().getId(), f.getCondicionIva().getDenominacion(),
                f.getTipoMoneda().getId(), f.getTipoMoneda().getDenominacion(), f.getTipoMoneda().getSimbolo(),
                lista == null ? null : lista.getId(),
                lista == null ? null : lista.getCodigo() + " - " + lista.getDenominacion(),
                neto, iva, f.getImporteTotal(),
                f.getCae(), f.getResultadoAfip(), f.getMotivoRechazo(),
                f.getCaeFechaVencimiento(), f.getFechaAnulacion(), f.getObservaciones(),
                items);
    }

    // Regla de ARCA: la numeracion es correlativa y la fecha no puede ir hacia atras.
    // Un comprobante no puede tener fecha anterior al ultimo emitido del mismo punto de venta y tipo.
    private void validarFechaContraUltimo(FacturaVenta factura, TipoComprobante tipo) {
        LocalDate fechaBorrador = aLocalDate(factura.getFechaEmision());
        if (Math.abs(java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), fechaBorrador))
                > ArcaService.DIAS_TOLERANCIA_FECHA) {
            return; // fuera de los +-5 dias: ARCA lo rechaza con su propio mensaje (mas claro para ese caso)
        }
        facturaVentaRepository.ultimoNumerado(factura.getPuntoVenta().getId(), tipo).ifPresent(ultimo -> {
            LocalDate fecha = fechaBorrador;
            LocalDate fechaUltimo = aLocalDate(ultimo.getFechaEmision());
            if (fecha.isBefore(fechaUltimo)) {
                throw new ReglaNegocioException("ARCA rechazó el comprobante: la fecha de emisión ("
                        + FORMATO_FECHA.format(fecha) + ") no puede ser anterior a la del último comprobante emitido ("
                        + FORMATO_FECHA.format(fechaUltimo) + ", " + descripcion(ultimo) + "). Editá la fecha del borrador");
            }
        });
    }

    private static final java.time.format.DateTimeFormatter FORMATO_FECHA =
            java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // Hibernate devuelve java.sql.Date para columnas DATE (y su toInstant() no esta soportado)
    private static LocalDate aLocalDate(Date fecha) {
        if (fecha instanceof java.sql.Date fechaSql) {
            return fechaSql.toLocalDate();
        }
        return fecha.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
    }

    // Como se nombra el comprobante en los mensajes: solo es "Factura A/B" si ya tiene CAE
    private static String descripcion(FacturaVenta f) {
        if (f.getNumero() == null) {
            return "(borrador id " + f.getId() + ")";
        }
        String numero = String.format("%04d-%08d", f.getPuntoVenta().getNumero(), f.getNumero());
        return f.getCae() == null || f.getCae().isBlank()
                ? numero + " (sin CAE)"
                : TipoComprobante.para(f.getCondicionIva()).getLetra() + " " + numero;
    }

    private static String recortar(String texto, int maximo) {
        return texto.length() <= maximo ? texto : texto.substring(0, maximo - 1) + "…";
    }

    private <T> T buscar(Class<T> clase, Long id, String nombre) {
        return catalogoRepository.buscarPorId(clase, id)
                .orElseThrow(() -> new RecursoNoEncontradoException(nombre, id));
    }

    // null o 0 = Consumidor Final (sin cliente)
    private Cliente buscarClienteOpcional(Long clienteId) {
        return clienteId == null || clienteId == 0 ? null : buscar(Cliente.class, clienteId, "Cliente");
    }

    // No hay login: las operaciones se registran a nombre del primer usuario (admin)
    private Usuario usuarioSistema() {
        return catalogoRepository.primero(Usuario.class)
                .orElseThrow(() -> new ReglaNegocioException("No hay usuarios cargados en el sistema"));
    }

    private static String textoOpcional(String texto) {
        return (texto == null || texto.isBlank()) ? null : texto.trim();
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
