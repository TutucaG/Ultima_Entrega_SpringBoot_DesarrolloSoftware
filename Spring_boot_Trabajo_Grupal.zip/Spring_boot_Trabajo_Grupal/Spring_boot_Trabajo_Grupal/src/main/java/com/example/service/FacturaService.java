package com.example.service;

import com.example.arca.TipoComprobante;
import com.example.dto.*;
import com.example.entidades.*;
import com.example.exception.RecursoNoEncontradoException;
import com.example.exception.ReglaNegocioException;
import com.example.repository.CatalogoRepository;
import com.example.repository.FacturaVentaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

// Ciclo de vida de una factura:
//
//   crear (POST)  ->  BORRADOR  (sin numero ni CAE: se puede editar y ELIMINAR)
//                        |
//   autorizar (ARCA)     v
//                     EMITIDA   (numero correlativo + CAE: ya no se edita ni se elimina)
//                        |
//   anular (PUT)         v
//                     ANULADA   (fechaAnulacion = hoy; queda registrada)
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true) // por defecto solo lectura; los metodos de escritura lo sobreescriben
public class FacturaService {

    public static final String BORRADOR = "BORRADOR";
    public static final String EMITIDA = "EMITIDA";
    public static final String ANULADA = "ANULADA";
    public static final Set<String> ESTADOS = Set.of(BORRADOR, EMITIDA, ANULADA);

    // Alicuota general de IVA. Los precios de la lista de precios son netos (sin IVA).
    public static final double ALICUOTA_IVA = 21.0;

    private final FacturaVentaRepository facturaVentaRepository;
    private final CatalogoRepository catalogoRepository;
    private final ArcaService arcaService;

    // =====================================================================
    // Lectura
    // =====================================================================

    public List<FacturaReporteDTO> buscarFacturasFiltradas(FacturaFiltrosDTO filtros) {
        if (filtros.getEstado() != null) {
            filtros.setEstado(filtros.getEstado().isBlank() ? null : filtros.getEstado().trim().toUpperCase());
        }
        if (filtros.getFechaDesde() != null && filtros.getFechaHasta() != null
                && filtros.getFechaDesde().after(filtros.getFechaHasta())) {
            throw new IllegalArgumentException("fechaDesde no puede ser posterior a fechaHasta");
        }
        return facturaVentaRepository.buscarFacturasFiltradas(filtros);
    }

    // Cabecera + items (para "Ver", editar un borrador y el PDF del comprobante)
    public FacturaCompletaDTO buscarPorId(Long id) {
        return aCompletaDTO(buscarEntidad(id));
    }

    // =====================================================================
    // Creacion (POST) -> queda como BORRADOR, sin numero
    // =====================================================================

    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO dto) {
        if (dto.getPuntoVentaId() == null || dto.getCondicionIvaId() == null || dto.getTipoMonedaId() == null
                || dto.getListaPrecioId() == null) {
            throw new IllegalArgumentException(
                    "puntoVentaId, condicionIvaId, tipoMonedaId y listaPrecioId son obligatorios");
        }
        validarDetalles(dto.getDetalles());

        // 1) Buscar las entidades asociadas por ID (404 si alguna no existe)
        PuntoVenta puntoVenta = buscar(PuntoVenta.class, dto.getPuntoVentaId(), "Punto de venta");
        CondicionIva condicionIva = buscar(CondicionIva.class, dto.getCondicionIvaId(), "Condición de IVA");
        TipoMoneda tipoMoneda = buscar(TipoMoneda.class, dto.getTipoMonedaId(), "Tipo de moneda");
        Cliente cliente = buscarClienteOpcional(dto.getClienteId());
        ListaPrecio listaPrecio = buscar(ListaPrecio.class, dto.getListaPrecioId(), "Lista de precios");
        Usuario usuario = usuarioSistema();

        // 2) Mapear el DTO a la entidad. El numero lo asigna ARCA al autorizar.
        LocalDate fecha = dto.getFechaEmision() != null ? dto.getFechaEmision() : LocalDate.now();
        FacturaVenta factura = FacturaVenta.builder()
                .fechaEmision(java.sql.Date.valueOf(fecha))
                .puntoVenta(puntoVenta)
                .condicionIva(condicionIva)
                .tipoMoneda(tipoMoneda)
                .cliente(cliente)
                .estado(BORRADOR)
                .observaciones(textoOpcional(dto.getObservaciones()))
                .detalles(new ArrayList<>())
                .build();

        Date ahora = new Date();
        factura.setFechaAlta(ahora);
        factura.setUsuarioCarga(usuario);
        factura.setFechaModificacion(ahora);
        factura.setUsuarioModificacion(usuario);

        // 3) Detalles (articulos de la lista elegida) + calculo automatico de neto, IVA y total
        agregarDetalles(factura, listaPrecio, dto.getDetalles());
        recalcularTotales(factura);

        // 4) Guardar: el cascade ALL inserta tambien los detalles
        facturaVentaRepository.guardar(factura);
        facturaVentaRepository.sincronizar();

        return buscarReporte(factura.getId());
    }

    // =====================================================================
    // Actualizacion (PUT) - solo se cambia lo que viene distinto de null
    // =====================================================================
    //  BORRADOR -> se puede cambiar cabecera e items (no se anula: se elimina)
    //  EMITIDA  -> solo se puede anular (estado = ANULADA) y cambiar observaciones
    //  ANULADA  -> no admite cambios

    @Transactional
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO dto) {
        FacturaVenta factura = buscarEntidad(id);
        String estadoActual = factura.getEstado();

        if (ANULADA.equals(estadoActual)) {
            throw new ReglaNegocioException("La factura " + descripcion(factura)
                    + " está ANULADA y ya no puede modificarse");
        }

        String nuevoEstado = null;
        if (dto.getEstado() != null && !dto.getEstado().isBlank()) {
            nuevoEstado = dto.getEstado().trim().toUpperCase();
            if (!ESTADOS.contains(nuevoEstado)) {
                throw new IllegalArgumentException("Estado inválido: " + dto.getEstado()
                        + ". Valores permitidos: " + ESTADOS);
            }
            if (nuevoEstado.equals(estadoActual)) {
                nuevoEstado = null; // sin cambio de estado
            } else if (EMITIDA.equals(nuevoEstado)) {
                throw new ReglaNegocioException("Para emitir una factura hay que autorizarla en ARCA "
                        + "(POST /api/facturas/" + id + "/autorizar)");
            } else if (BORRADOR.equals(nuevoEstado)) {
                throw new ReglaNegocioException("Una factura emitida no puede volver a borrador; debe anularse");
            } else if (BORRADOR.equals(estadoActual)) { // pide ANULADA sobre un borrador
                throw new ReglaNegocioException("La factura no tiene número de comprobante: "
                        + "no se anula, se elimina (DELETE)");
            }
        }

        boolean modificaDatos = dto.getFechaEmision() != null || dto.getPuntoVentaId() != null
                || dto.getCondicionIvaId() != null || dto.getTipoMonedaId() != null
                || dto.getClienteId() != null || dto.getListaPrecioId() != null || dto.getDetalles() != null;
        if (modificaDatos && !BORRADOR.equals(estadoActual)) {
            throw new ReglaNegocioException("La factura " + descripcion(factura)
                    + " ya fue autorizada por ARCA: sus datos no pueden modificarse, solo anularse");
        }

        // ---- Cabecera ----
        if (dto.getFechaEmision() != null) {
            factura.setFechaEmision(java.sql.Date.valueOf(dto.getFechaEmision()));
        }
        if (dto.getPuntoVentaId() != null) {
            factura.setPuntoVenta(buscar(PuntoVenta.class, dto.getPuntoVentaId(), "Punto de venta"));
        }
        if (dto.getCondicionIvaId() != null) {
            factura.setCondicionIva(buscar(CondicionIva.class, dto.getCondicionIvaId(), "Condición de IVA"));
        }
        if (dto.getTipoMonedaId() != null) {
            factura.setTipoMoneda(buscar(TipoMoneda.class, dto.getTipoMonedaId(), "Tipo de moneda"));
        }
        if (dto.getClienteId() != null) {
            // clienteId = 0 -> pasa a Consumidor Final
            factura.setCliente(buscarClienteOpcional(dto.getClienteId() == 0 ? null : dto.getClienteId()));
        }
        if (dto.getObservaciones() != null) {
            factura.setObservaciones(textoOpcional(dto.getObservaciones()));
        }

        if (modificaDatos) {
            // el borrador cambio: el rechazo anterior de ARCA ya no aplica
            factura.setResultadoAfip(null);
            factura.setMotivoRechazo(null);
        }

        // ---- Items: si vienen, reemplazan a los anteriores. Si solo cambia la lista de precios,
        //      se vuelven a cotizar los mismos articulos con los precios de la lista nueva ----
        ListaPrecio listaPrecio = dto.getListaPrecioId() != null
                ? buscar(ListaPrecio.class, dto.getListaPrecioId(), "Lista de precios")
                : listaDe(factura);
        List<FacturaDetalleRequestDTO> nuevosDetalles = dto.getDetalles();
        if (nuevosDetalles == null && dto.getListaPrecioId() != null) {
            nuevosDetalles = factura.getDetalles().stream()
                    .map(d -> new FacturaDetalleRequestDTO(d.getListaPrecioArticulo().getArticulo().getId(),
                            d.getCantidad(), d.getPorcentajeBonificacion(), d.getDescripcion()))
                    .toList();
        }
        if (nuevosDetalles != null) {
            validarDetalles(nuevosDetalles);
            if (listaPrecio == null) {
                throw new IllegalArgumentException("listaPrecioId es obligatorio para cargar los detalles");
            }
            factura.getDetalles().clear(); // orphanRemoval borra los renglones viejos
            agregarDetalles(factura, listaPrecio, nuevosDetalles);
            recalcularTotales(factura);
        }

        // ---- Anulacion logica (solo facturas EMITIDAS, ya validado arriba) ----
        if (ANULADA.equals(nuevoEstado)) {
            factura.setEstado(ANULADA);
            factura.setFechaAnulacion(new Date());
        }

        factura.setFechaModificacion(new Date());
        factura.setUsuarioModificacion(usuarioSistema());

        facturaVentaRepository.sincronizar();
        return buscarReporte(factura.getId());
    }

    // =====================================================================
    // Autorizacion en ARCA (POST /{id}/autorizar): asigna numero y CAE
    // =====================================================================
    // noRollbackFor: si ARCA rechaza el comprobante, igual se guarda el resultado "R" y el motivo
    // (la factura sigue como BORRADOR para poder corregirla y volver a enviarla).

    @Transactional(noRollbackFor = ReglaNegocioException.class)
    public FacturaReporteDTO autorizar(Long id) {
        FacturaVenta factura = buscarEntidad(id);
        if (!BORRADOR.equals(factura.getEstado())) {
            throw new ReglaNegocioException("La factura " + descripcion(factura)
                    + " ya fue autorizada (estado " + factura.getEstado() + ")");
        }

        TipoComprobante tipo = TipoComprobante.para(factura.getCondicionIva());
        ArcaService.Autorizacion autorizacion;
        try {
            autorizacion = arcaService.autorizar(factura,
                    () -> facturaVentaRepository.siguienteNumero(factura.getPuntoVenta().getId(), tipo));
        } catch (ReglaNegocioException rechazo) {
            factura.setResultadoAfip("R"); // R = rechazado
            factura.setMotivoRechazo(recortar(rechazo.getMessage(), 255));
            factura.setFechaModificacion(new Date());
            factura.setUsuarioModificacion(usuarioSistema());
            throw rechazo; // 409 con el motivo
        }

        factura.setNumero(autorizacion.numero());
        factura.setCae(autorizacion.cae());
        factura.setCaeFechaVencimiento(autorizacion.fechaVencimiento());
        factura.setResultadoAfip("A"); // A = aprobado
        factura.setMotivoRechazo(null);
        factura.setEstado(EMITIDA);
        factura.setFechaModificacion(new Date());
        factura.setUsuarioModificacion(usuarioSistema());

        facturaVentaRepository.sincronizar();
        return buscarReporte(factura.getId());
    }

    // =====================================================================
    // Eliminacion (DELETE) - borrado fisico
    // =====================================================================
    // Regla de negocio: solo se elimina una factura SIN numero de comprobante (borrador).
    // Si ya tiene numero/CAE es un comprobante fiscal: no se borra, se anula (PUT estado ANULADA).

    @Transactional
    public void eliminar(Long id) {
        FacturaVenta factura = buscarEntidad(id);

        if (factura.getNumero() != null || (factura.getCae() != null && !factura.getCae().isBlank())) {
            throw new ReglaNegocioException("La factura " + descripcion(factura)
                    + " tiene número de comprobante y no puede eliminarse; debe anularse");
        }
        facturaVentaRepository.eliminar(factura);
    }

    // =====================================================================
    // Auxiliares
    // =====================================================================

    private FacturaVenta buscarEntidad(Long id) {
        return facturaVentaRepository.buscarPorId(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Factura", id));
    }

    private FacturaReporteDTO buscarReporte(Long id) {
        return facturaVentaRepository.buscarReportePorId(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Factura", id));
    }

    // Cada detalle guarda la ListaPrecioArticulo: el articulo con el precio de la lista elegida
    private void agregarDetalles(FacturaVenta factura, ListaPrecio lista, List<FacturaDetalleRequestDTO> detallesDto) {
        for (FacturaDetalleRequestDTO d : detallesDto) {
            Articulo articulo = buscar(Articulo.class, d.getArticuloId(), "Artículo");
            ListaPrecioArticulo precio = catalogoRepository.buscarPrecio(lista.getId(), d.getArticuloId())
                    .orElseThrow(() -> new RecursoNoEncontradoException("El artículo " + articulo.getCodigo()
                            + " no está en la lista de precios " + lista.getDenominacion()));

            double cantidad = d.getCantidad();
            double bonificacion = d.getPorcentajeBonificacion() == null ? 0 : d.getPorcentajeBonificacion();
            double precioUnitario = precio.getPrecioVenta();

            double bruto = cantidad * precioUnitario;
            double neto = redondear(bruto - bruto * bonificacion / 100);
            double iva = redondear(neto * ALICUOTA_IVA / 100);

            FacturaVentaDetalle detalle = new FacturaVentaDetalle();
            detalle.setFactura(factura); // relacion bidireccional
            detalle.setListaPrecioArticulo(precio);
            String descripcion = textoOpcional(d.getDescripcion());
            detalle.setDescripcion(descripcion != null ? descripcion : precio.getArticulo().getDenominacion());
            detalle.setCantidad(cantidad);
            detalle.setPrecioUnitario(precioUnitario);
            detalle.setPorcentajeBonificacion(bonificacion);
            detalle.setImporteNeto(neto);
            detalle.setImporteIva(iva);
            detalle.setImporteSubtotal(redondear(neto + iva));

            factura.getDetalles().add(detalle);
        }
    }

    // Lista de precios de una factura guardada: la de sus detalles (todos salen de la misma lista)
    private static ListaPrecio listaDe(FacturaVenta factura) {
        return factura.getDetalles() == null || factura.getDetalles().isEmpty() ? null
                : factura.getDetalles().get(0).getListaPrecioArticulo().getListaPrecio();
    }

    private void recalcularTotales(FacturaVenta factura) {
        double total = factura.getDetalles().stream()
                .mapToDouble(FacturaVentaDetalle::getImporteSubtotal)
                .sum();
        factura.setImporteTotal(redondear(total));
        factura.setImporteSaldo(redondear(total - factura.getImporteCobrado()));
    }

    private void validarDetalles(List<FacturaDetalleRequestDTO> detalles) {
        if (detalles == null || detalles.isEmpty()) {
            throw new IllegalArgumentException("La factura debe tener al menos un detalle");
        }
        for (int i = 0; i < detalles.size(); i++) {
            FacturaDetalleRequestDTO d = detalles.get(i);
            String renglon = "Detalle " + (i + 1) + ": ";
            if (d == null || d.getArticuloId() == null) {
                throw new IllegalArgumentException(renglon + "articuloId es obligatorio");
            }
            if (d.getCantidad() == null || d.getCantidad() <= 0) {
                throw new IllegalArgumentException(renglon + "la cantidad debe ser mayor a 0");
            }
            Double bonif = d.getPorcentajeBonificacion();
            if (bonif != null && (bonif < 0 || bonif > 100)) {
                throw new IllegalArgumentException(renglon + "la bonificación debe estar entre 0 y 100");
            }
        }
    }

    private FacturaCompletaDTO aCompletaDTO(FacturaVenta f) {
        List<FacturaItemDTO> items = f.getDetalles().stream()
                .map(d -> new FacturaItemDTO(
                        d.getListaPrecioArticulo().getId(),
                        d.getListaPrecioArticulo().getArticulo().getId(),
                        d.getListaPrecioArticulo().getArticulo().getCodigo(),
                        d.getDescripcion(), d.getCantidad(), d.getPrecioUnitario(),
                        d.getPorcentajeBonificacion(), d.getImporteNeto(), d.getImporteIva(),
                        d.getImporteSubtotal()))
                .toList();

        double neto = redondear(items.stream().mapToDouble(FacturaItemDTO::getImporteNeto).sum());
        double iva = redondear(items.stream().mapToDouble(FacturaItemDTO::getImporteIva).sum());

        Cliente c = f.getCliente();
        String domicilio = (c == null || c.getDomicilio() == null) ? null
                : (c.getDomicilio().getNombreCalle() + " " + c.getDomicilio().getNumeroCalle()).trim();

        TipoComprobante tipo = TipoComprobante.para(f.getCondicionIva());
        ListaPrecio lista = listaDe(f);
        return new FacturaCompletaDTO(
                f.getId(), tipo.getLetra(), tipo.getCodigoArca(), f.getNumero(), f.getEstado(), f.getFechaEmision(),
                f.getPuntoVenta().getId(), f.getPuntoVenta().getNumero(), f.getPuntoVenta().getDescripcion(),
                c == null ? null : c.getId(),
                c == null ? "Consumidor Final" : c.getDenominacion(),
                c == null ? null : c.getCuitCuil(),
                domicilio,
                f.getCondicionIva().getId(), f.getCondicionIva().getDenominacion(),
                f.getTipoMoneda().getId(), f.getTipoMoneda().getDenominacion(), f.getTipoMoneda().getSimbolo(),
                lista == null ? null : lista.getId(),
                lista == null ? null : lista.getCodigo() + " - " + lista.getDenominacion(),
                neto, iva, f.getImporteTotal(),
                f.getCae(), f.getResultadoAfip(), f.getMotivoRechazo(),
                f.getCaeFechaVencimiento(), f.getFechaAnulacion(), f.getObservaciones(),
                items);
    }

    private static String descripcion(FacturaVenta f) {
        return f.getNumero() == null
                ? "(borrador id " + f.getId() + ")"
                : String.format("%s %04d-%08d", TipoComprobante.para(f.getCondicionIva()).getLetra(),
                f.getPuntoVenta().getNumero(), f.getNumero());
    }

    private static String recortar(String texto, int maximo) {
        return texto.length() <= maximo ? texto : texto.substring(0, maximo - 1) + "…";
    }

    private <T> T buscar(Class<T> clase, Long id, String nombre) {
        return catalogoRepository.buscarPorId(clase, id)
                .orElseThrow(() -> new RecursoNoEncontradoException(nombre, id));
    }

    private Cliente buscarClienteOpcional(Long clienteId) {
        return clienteId == null ? null : buscar(Cliente.class, clienteId, "Cliente");
    }

    // No hay login: las operaciones se registran a nombre del primer usuario (admin)
    private Usuario usuarioSistema() {
        return catalogoRepository.primero(Usuario.class)
                .orElseThrow(() -> new ReglaNegocioException("No hay usuarios cargados en el sistema"));
    }

    private static String textoOpcional(String texto) {
        return (texto == null || texto.isBlank()) ? null : texto.trim();
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
