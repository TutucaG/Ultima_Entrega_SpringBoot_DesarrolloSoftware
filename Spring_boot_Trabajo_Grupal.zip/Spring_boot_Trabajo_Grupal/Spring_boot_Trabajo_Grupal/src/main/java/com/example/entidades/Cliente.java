package com.example.entidades;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "cliente")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class Cliente extends AuditoriaApp {

    @Column(nullable = false)
    private String cuitCuil;

    @Column(nullable = false)
    private String denominacion;

    @OneToOne
    @JoinColumn(nullable = false)
    private Contacto contacto;

    @OneToOne
    @JoinColumn(nullable = false)
    private Domicilio domicilio;

    // Condicion frente al IVA del cliente: define si se le emite Factura A o B.
    // Nullable solo por compatibilidad con clientes cargados antes de este campo.
    @ManyToOne
    @JoinColumn(name = "condicion_iva_id")
    private CondicionIva condicionIva;

}