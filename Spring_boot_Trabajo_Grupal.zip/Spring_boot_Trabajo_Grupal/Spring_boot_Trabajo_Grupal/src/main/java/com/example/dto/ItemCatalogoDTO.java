package com.example.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Opcion de un combo del formulario (condicion IVA, punto de venta, moneda, lista de precios)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ItemCatalogoDTO {

    private Long id;
    private String descripcion;

}
