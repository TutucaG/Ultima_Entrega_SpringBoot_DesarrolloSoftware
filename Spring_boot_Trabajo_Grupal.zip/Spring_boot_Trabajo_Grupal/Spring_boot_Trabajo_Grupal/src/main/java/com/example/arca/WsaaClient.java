package com.example.arca;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
import org.springframework.stereotype.Component;
import org.w3c.dom.Element;

import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.Properties;

// WSAA (Web Service de Autenticacion y Autorizacion) de ARCA.
// Pasos: 1) armar el TRA (loginTicketRequest)  2) firmarlo en CMS/PKCS#7 con el certificado
//        3) enviarlo a loginCms  4) recibir el Token y el Sign que piden los demas webservices.
@Slf4j
@Component
@RequiredArgsConstructor
public class WsaaClient {

    private static final String SERVICIO = "wsfe";

    private final ArcaConfig config;
    private TicketAcceso ticket; // cache en memoria

    public record TicketAcceso(String token, String sign, Instant expiracion) {

        // margen de 10 minutos para no usar un ticket que vence en medio de la operacion
        public boolean vigente() {
            return expiracion != null && expiracion.isAfter(Instant.now().plus(Duration.ofMinutes(10)));
        }
    }

    public synchronized TicketAcceso obtenerTicket() {
        if (ticket != null && ticket.vigente()) {
            return ticket;
        }
        TicketAcceso guardado = leerCache();
        if (guardado != null && guardado.vigente()) {
            ticket = guardado;
            return ticket;
        }
        ticket = solicitarNuevoTicket();
        guardarCache(ticket);
        log.info("ARCA: nuevo ticket de acceso para {} (vence {})", SERVICIO, ticket.expiracion());
        return ticket;
    }

    private TicketAcceso solicitarNuevoTicket() {
        if (config.getCertificado().isBlank() || config.getClavePrivada().isBlank()) {
            throw new ArcaException("Modo homologación: falta configurar app.arca.certificado y "
                    + "app.arca.clave-privada (ver README, sección ARCA)");
        }
        PrivateKey clave = cargarClavePrivada(Path.of(config.getClavePrivada()));
        X509Certificate certificado = cargarCertificado(Path.of(config.getCertificado()));

        String tra = generarTra(ZonedDateTime.now(), SERVICIO);
        String cms = firmarCms(tra, clave, certificado);

        String sobre = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "xmlns:wsaa=\"http://wsaa.view.sua.dvadac.desein.afip.gov\">"
                + "<soapenv:Header/><soapenv:Body><wsaa:loginCms><wsaa:in0>" + cms
                + "</wsaa:in0></wsaa:loginCms></soapenv:Body></soapenv:Envelope>";

        String respuesta = Soap.enviar(config.getWsaaUrl(), "", sobre);
        return leerRespuestaLogin(respuesta);
    }

    // ------------------------------------------------------------------ pasos (package-private para los tests)

    // TRA: pedido de ticket con validez desde 5 min antes hasta 10 min despues (como indica la guia)
    static String generarTra(ZonedDateTime ahora, String servicio) {
        DateTimeFormatter iso = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<loginTicketRequest version=\"1.0\"><header>"
                + "<uniqueId>" + ahora.toEpochSecond() + "</uniqueId>"
                + "<generationTime>" + ahora.minusMinutes(5).withNano(0).format(iso) + "</generationTime>"
                + "<expirationTime>" + ahora.plusMinutes(10).withNano(0).format(iso) + "</expirationTime>"
                + "</header><service>" + servicio + "</service></loginTicketRequest>";
    }

    // Firma CMS (PKCS#7) con SHA256withRSA, incluyendo el certificado y el contenido firmado
    static String firmarCms(String tra, PrivateKey clave, X509Certificate certificado) {
        try {
            registrarBouncyCastle();
            ContentSigner firmante = new JcaContentSignerBuilder("SHA256withRSA").setProvider("BC").build(clave);
            CMSSignedDataGenerator generador = new CMSSignedDataGenerator();
            generador.addSignerInfoGenerator(new JcaSignerInfoGeneratorBuilder(
                    new JcaDigestCalculatorProviderBuilder().setProvider("BC").build())
                    .build(firmante, certificado));
            generador.addCertificates(new JcaCertStore(List.of(certificado)));
            CMSSignedData firmado = generador.generate(
                    new CMSProcessableByteArray(tra.getBytes(StandardCharsets.UTF_8)), true);
            return Base64.getEncoder().encodeToString(firmado.getEncoded());
        } catch (Exception e) {
            throw new ArcaException("No se pudo firmar el pedido de acceso a ARCA: " + e.getMessage(), e);
        }
    }

    // La respuesta trae el loginTicketResponse como texto escapado dentro de <loginCmsReturn>
    static TicketAcceso leerRespuestaLogin(String respuestaSoap) {
        String ticketXml = Soap.texto(Soap.parsear(respuestaSoap).getDocumentElement(), "loginCmsReturn");
        if (ticketXml == null) {
            throw new ArcaException("WSAA no devolvió el ticket de acceso");
        }
        Element raiz = Soap.parsear(ticketXml).getDocumentElement();
        String token = Soap.texto(raiz, "token");
        String sign = Soap.texto(raiz, "sign");
        String vence = Soap.texto(raiz, "expirationTime");
        if (token == null || sign == null || vence == null) {
            throw new ArcaException("El ticket de acceso de WSAA está incompleto");
        }
        return new TicketAcceso(token, sign, OffsetDateTime.parse(vence).toInstant());
    }

    // Acepta claves "BEGIN PRIVATE KEY" (PKCS#8, OpenSSL 3) y "BEGIN RSA PRIVATE KEY" (PKCS#1)
    static PrivateKey cargarClavePrivada(Path archivo) {
        try (Reader lector = Files.newBufferedReader(archivo, StandardCharsets.UTF_8);
             PEMParser pem = new PEMParser(lector)) {
            Object objeto = pem.readObject();
            JcaPEMKeyConverter conversor = new JcaPEMKeyConverter();
            if (objeto instanceof PEMKeyPair par) {
                return conversor.getPrivateKey(par.getPrivateKeyInfo());
            }
            if (objeto instanceof PrivateKeyInfo info) {
                return conversor.getPrivateKey(info);
            }
            throw new ArcaException("El archivo " + archivo + " no contiene una clave privada PEM sin contraseña");
        } catch (ArcaException e) {
            throw e;
        } catch (Exception e) {
            throw new ArcaException("No se pudo leer la clave privada " + archivo + ": " + e.getMessage(), e);
        }
    }

    static X509Certificate cargarCertificado(Path archivo) {
        try (InputStream entrada = Files.newInputStream(archivo)) {
            return (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(entrada);
        } catch (Exception e) {
            throw new ArcaException("No se pudo leer el certificado " + archivo + ": " + e.getMessage(), e);
        }
    }

    private static void registrarBouncyCastle() {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    // ------------------------------------------------------------------ cache en disco

    private TicketAcceso leerCache() {
        Path archivo = Path.of(config.getTicketCache());
        if (!Files.exists(archivo)) {
            return null;
        }
        try (Reader lector = Files.newBufferedReader(archivo, StandardCharsets.UTF_8)) {
            Properties p = new Properties();
            p.load(lector);
            if (!String.valueOf(config.getCuit()).equals(p.getProperty("cuit"))) {
                return null; // ticket de otro CUIT
            }
            return new TicketAcceso(p.getProperty("token"), p.getProperty("sign"),
                    Instant.parse(p.getProperty("expiracion")));
        } catch (Exception e) {
            log.warn("ARCA: no se pudo leer el ticket guardado en {}: {}", archivo, e.getMessage());
            return null;
        }
    }

    private void guardarCache(TicketAcceso t) {
        Path archivo = Path.of(config.getTicketCache());
        try (Writer escritor = Files.newBufferedWriter(archivo, StandardCharsets.UTF_8)) {
            Properties p = new Properties();
            p.setProperty("cuit", String.valueOf(config.getCuit()));
            p.setProperty("token", t.token());
            p.setProperty("sign", t.sign());
            p.setProperty("expiracion", t.expiracion().toString());
            p.store(escritor, "Ticket de acceso WSAA (no compartir)");
        } catch (Exception e) {
            log.warn("ARCA: no se pudo guardar el ticket en {}: {}", archivo, e.getMessage());
        }
    }
}
