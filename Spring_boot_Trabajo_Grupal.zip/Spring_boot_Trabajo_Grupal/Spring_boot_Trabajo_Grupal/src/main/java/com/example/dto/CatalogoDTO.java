package com.example.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

// Catalogos chicos del formulario de alta, en una sola llamada.
// Clientes y articulos NO van aca: se eligen con sus explorers (busqueda en el servidor).
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CatalogoDTO {

    private List<ItemCatalogoDTO> condicionesIva;
    private List<ItemCatalogoDTO> puntosVenta;
    private List<ItemCatalogoDTO> tiposMoneda;
    private List<ItemCatalogoDTO> listasPrecio;
    private double alicuotaIva;

}
