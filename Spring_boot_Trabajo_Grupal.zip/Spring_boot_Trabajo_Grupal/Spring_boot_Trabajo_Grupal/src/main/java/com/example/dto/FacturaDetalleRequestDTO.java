package com.example.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Renglon de la factura tal como lo manda el cliente en POST / PUT.
// Solo viaja el ID del articulo; el precio se toma de su ListaPrecioArticulo
// y los importes (neto, IVA, subtotal) los calcula el servicio.
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaDetalleRequestDTO {

    private Long articuloId;
    private Double cantidad;
    private Double porcentajeBonificacion; // opcional, 0 si no viene
    private String descripcion;            // opcional, por defecto la denominacion del articulo

}
