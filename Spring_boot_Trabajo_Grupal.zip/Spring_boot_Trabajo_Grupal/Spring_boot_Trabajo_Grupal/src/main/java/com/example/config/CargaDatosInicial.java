package com.example.config;

import com.example.entidades.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;


@Slf4j
@Component
public class CargaDatosInicial implements CommandLineRunner {

    @PersistenceContext
    private EntityManager em;

    @Value("${app.cargar-datos-prueba:true}")
    private boolean cargarDatosPrueba;

    @Override
    @Transactional
    public void run(String... args) {
        if (!cargarDatosPrueba) {
            log.info("Carga de datos de prueba desactivada (app.cargar-datos-prueba=false).");
            return;
        }

        // ---------- Datos base (cada uno se crea solo si todavia no existe) ----------
        Usuario usuario = primero(Usuario.class);
        if (usuario == null) {
            usuario = new Usuario();
            usuario.setUsuario("admin");
            usuario.setClave("admin");
            usuario.setNombre("Administrador");
            usuario.setApellido("Sistema");
            em.persist(usuario);
        }

        PuntoVenta puntoVenta = primero(PuntoVenta.class);
        if (puntoVenta == null) {
            puntoVenta = new PuntoVenta();
            puntoVenta.setNumero(1);
            puntoVenta.setDescripcion("Sucursal Central");
            puntoVenta.setTipoEmision("CAE");
            puntoVenta.setDomicilioComercial("Av. San Martin 100");
            auditar(puntoVenta, usuario);
            em.persist(puntoVenta);
        }

        CondicionIva condicionIva = primero(CondicionIva.class);
        if (condicionIva == null) {
            condicionIva = new CondicionIva();
            condicionIva.setCodigoAfip(1);
            condicionIva.setDenominacion("IVA Responsable Inscripto");
            auditar(condicionIva, usuario);
            em.persist(condicionIva);
        }

        TipoMoneda tipoMoneda = primero(TipoMoneda.class);
        if (tipoMoneda == null) {
            tipoMoneda = new TipoMoneda();
            tipoMoneda.setCodigoAfip("PES");
            tipoMoneda.setDenominacion("Pesos Argentinos");
            tipoMoneda.setSimbolo("$");
            auditar(tipoMoneda, usuario);
            em.persist(tipoMoneda);
        }

        Cliente cliente = primero(Cliente.class);
        if (cliente == null) {
            Contacto contacto = new Contacto();
            contacto.setEmail("contacto@empresatech.com");
            contacto.setTelefono("0261-4000000");
            contacto.setCelular("261-5000000");
            em.persist(contacto);

            Domicilio domicilio = new Domicilio();
            domicilio.setNombreCalle("Belgrano");
            domicilio.setNumeroCalle("250");
            em.persist(domicilio);

            cliente = new Cliente();
            cliente.setCuitCuil("30-12345678-9");
            cliente.setDenominacion("Empresa Tech S.A.");
            cliente.setContacto(contacto);
            cliente.setDomicilio(domicilio);
            auditar(cliente, usuario);
            em.persist(cliente);
        }

        ListaPrecioArticulo listaPrecioArticulo = primero(ListaPrecioArticulo.class);
        if (listaPrecioArticulo == null) {
            Rubro rubro = new Rubro();
            rubro.setDenominacion("Bebidas");
            rubro.setCodigo(1);
            auditar(rubro, usuario);
            em.persist(rubro);

            Marca marca = new Marca();
            marca.setDenominacion("Coca-Cola");
            marca.setCodigo(1);
            auditar(marca, usuario);
            em.persist(marca);

            Articulo articulo = new Articulo();
            articulo.setRubro(rubro);
            articulo.setMarca(marca);
            articulo.setCodigo("ART-001");
            articulo.setDenominacion("Gaseosa 500ml");
            auditar(articulo, usuario);
            em.persist(articulo);

            ListaPrecio listaPrecio = new ListaPrecio();
            listaPrecio.setCodigo("LP-01");
            listaPrecio.setDenominacion("Lista General");
            auditar(listaPrecio, usuario);
            em.persist(listaPrecio);

            listaPrecioArticulo = new ListaPrecioArticulo();
            listaPrecioArticulo.setListaPrecio(listaPrecio);
            listaPrecioArticulo.setArticulo(articulo);
            listaPrecioArticulo.setPrecioVenta(750.0);
            auditar(listaPrecioArticulo, usuario);
            em.persist(listaPrecioArticulo);
        }

        // ---------- Catalogo extra para el formulario de alta del frontend ----------
        CondicionIva consumidorFinal = asegurarCondicionIva(5, "Consumidor Final", usuario);
        asegurarCondicionIva(6, "Responsable Monotributo", usuario);
        asegurarCliente("20-30111222-3", "Comercial Andina S.R.L.", "Mitre", "845", usuario);
        asegurarArticulo("ART-002", "Agua mineral 1.5L", 520.0, listaPrecioArticulo, usuario);
        asegurarArticulo("ART-003", "Jugo de naranja 1L", 980.0, listaPrecioArticulo, usuario);
        asegurarArticulo("ART-004", "Cerveza lata 473ml", 1350.0, listaPrecioArticulo, usuario);
        asegurarArticulo("ART-005", "Gaseosa 2.25L", 1890.0, listaPrecioArticulo, usuario);
        asegurarArticulo("ART-006", "Agua saborizada 1.5L", 870.0, listaPrecioArticulo, usuario);
        asegurarArticulo("ART-007", "Bebida isotónica 500ml", 1150.0, listaPrecioArticulo, usuario);
        asegurarArticulo("ART-008", "Soda sifón 2L", 640.0, listaPrecioArticulo, usuario);
        asegurarCliente("30-70984512-4", "Supermercado El Sol S.A.", "Las Heras", "1220", usuario);
        asegurarCliente("20-28456123-7", "Pérez Juan Carlos", "San Juan", "377", usuario);
        asegurarCliente("27-33214567-2", "Gómez María Laura", "Rivadavia", "56", usuario);
        asegurarCliente("30-71566890-1", "Distribuidora Cuyo S.R.L.", "Ruta 40 km", "12", usuario);

        // Segunda lista de precios: mayorista, con 15 % menos y sin la cerveza
        // (el detalle de la factura guarda la ListaPrecioArticulo: primero se elige la lista, despues el articulo)
        asegurarListaPrecio("LP-02", "Lista Mayorista", 0.85, Set.of("ART-004"),
                listaPrecioArticulo.getListaPrecio(), usuario);

        Long cantidad = em.createQuery("SELECT COUNT(f) FROM FacturaVenta f", Long.class).getSingleResult();
        if (cantidad > 0) {
            // ya hay facturas en ESTA base, no se agregan las de ejemplo
            log.info("La base ya tiene {} factura(s); no se cargan facturas de prueba.", cantidad);
            return;
        }

        // ---------- Facturas de ejemplo ----------
        // numero (null = borrador sin autorizar), fecha, importe, estado, cliente (null = Consumidor Final), items
        // Las que tienen numero ya fueron "autorizadas" por ARCA: llevan CAE y vencimiento.
        List<FacturaVenta> facturas = new ArrayList<>();
        facturas.add(crearFactura(1001L, LocalDate.of(2026, 3, 15), 1500.0, "EMITIDA", null, 2, usuario, puntoVenta, consumidorFinal, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1002L, LocalDate.of(2026, 3, 20), 85000.5, "EMITIDA", cliente, 5, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1003L, LocalDate.of(2026, 4, 2), 12500.0, "EMITIDA", cliente, 3, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1004L, LocalDate.of(2026, 4, 10), 4300.0, "ANULADA", null, 1, usuario, puntoVenta, consumidorFinal, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1005L, LocalDate.of(2026, 5, 5), 52000.0, "EMITIDA", cliente, 2, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1006L, LocalDate.of(2026, 5, 20), 800.0, "EMITIDA", null, 1, usuario, puntoVenta, consumidorFinal, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1007L, LocalDate.of(2026, 6, 1), 23000.0, "ANULADA", cliente, 2, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(null, LocalDate.now().minusDays(1), 3630.0, "BORRADOR", cliente, 2, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(null, LocalDate.now(), 907.5, "BORRADOR", null, 1, usuario, puntoVenta, consumidorFinal, tipoMoneda, listaPrecioArticulo));

        for (FacturaVenta f : facturas) {
            em.persist(f); // los detalles se guardan solos por el cascade
        }
        log.info("Datos de prueba cargados: {} facturas.", facturas.size());
    }

    private FacturaVenta crearFactura(Long numero, LocalDate fecha, double importe, String estado,
                                      Cliente cliente, int items, Usuario usuario, PuntoVenta puntoVenta,
                                      CondicionIva condicionIva, TipoMoneda tipoMoneda,
                                      ListaPrecioArticulo listaPrecioArticulo) {
        Date fechaEmision = java.sql.Date.valueOf(fecha);

        FacturaVenta f = new FacturaVenta();
        f.setNumero(numero);
        f.setFechaEmision(fechaEmision);
        f.setPuntoVenta(puntoVenta);
        f.setCliente(cliente);
        f.setCondicionIva(condicionIva);
        f.setTipoMoneda(tipoMoneda);
        f.setImporteTotal(importe);
        f.setImporteSaldo(importe);
        f.setEstado(estado);
        if (numero != null) {
            // CAE de ejemplo (14 digitos) con vencimiento a 10 dias de la emision
            f.setCae(String.format("7%013d", numero * 7919));
            f.setCaeFechaVencimiento(java.sql.Date.valueOf(fecha.plusDays(10)));
            f.setResultadoAfip("A");
        }
        if ("ANULADA".equals(estado)) {
            f.setFechaAnulacion(fechaEmision);
        }
        auditar(f, usuario);

        List<FacturaVentaDetalle> detalles = new ArrayList<>();
        double subtotal = importe / items;
        for (int i = 0; i < items; i++) {
            FacturaVentaDetalle d = new FacturaVentaDetalle();
            d.setFactura(f); // relacion bidireccional
            d.setListaPrecioArticulo(listaPrecioArticulo);
            d.setDescripcion("Gaseosa 500ml");
            d.setCantidad(1);
            double neto = Math.round(subtotal / 1.21 * 100.0) / 100.0; // el subtotal incluye IVA 21%
            d.setPrecioUnitario(neto);
            d.setImporteNeto(neto);
            d.setImporteIva(Math.round((subtotal - neto) * 100.0) / 100.0);
            d.setImporteSubtotal(subtotal);
            detalles.add(d);
        }
        f.setDetalles(detalles);
        return f;
    }

    private CondicionIva asegurarCondicionIva(int codigoAfip, String denominacion, Usuario usuario) {
        List<CondicionIva> existentes = em.createQuery(
                        "SELECT c FROM CondicionIva c WHERE c.codigoAfip = :codigo", CondicionIva.class)
                .setParameter("codigo", codigoAfip)
                .getResultList();
        if (!existentes.isEmpty()) {
            return existentes.get(0);
        }
        CondicionIva ci = new CondicionIva();
        ci.setCodigoAfip(codigoAfip);
        ci.setDenominacion(denominacion);
        auditar(ci, usuario);
        em.persist(ci);
        return ci;
    }

    private void asegurarCliente(String cuit, String denominacion, String calle, String numero, Usuario usuario) {
        if (existe("Cliente", "cuitCuil", cuit)) {
            return;
        }
        Contacto contacto = new Contacto();
        em.persist(contacto);

        Domicilio domicilio = new Domicilio();
        domicilio.setNombreCalle(calle);
        domicilio.setNumeroCalle(numero);
        em.persist(domicilio);

        Cliente cliente = new Cliente();
        cliente.setCuitCuil(cuit);
        cliente.setDenominacion(denominacion);
        cliente.setContacto(contacto);
        cliente.setDomicilio(domicilio);
        auditar(cliente, usuario);
        em.persist(cliente);
    }

    // Crea el articulo y su precio en la misma lista / rubro / marca que el articulo base
    private void asegurarArticulo(String codigo, String denominacion, double precio,
                                  ListaPrecioArticulo base, Usuario usuario) {
        if (existe("Articulo", "codigo", codigo)) {
            return;
        }
        Articulo articulo = new Articulo();
        articulo.setRubro(base.getArticulo().getRubro());
        articulo.setMarca(base.getArticulo().getMarca());
        articulo.setCodigo(codigo);
        articulo.setDenominacion(denominacion);
        auditar(articulo, usuario);
        em.persist(articulo);

        ListaPrecioArticulo lpa = new ListaPrecioArticulo();
        lpa.setListaPrecio(base.getListaPrecio());
        lpa.setArticulo(articulo);
        lpa.setPrecioVenta(precio);
        auditar(lpa, usuario);
        em.persist(lpa);
    }

    // Copia los precios de la lista base aplicando un factor (y excluyendo algunos codigos)
    private void asegurarListaPrecio(String codigo, String denominacion, double factor, Set<String> excluidos,
                                     ListaPrecio base, Usuario usuario) {
        if (existe("ListaPrecio", "codigo", codigo)) {
            return;
        }
        ListaPrecio lista = new ListaPrecio();
        lista.setCodigo(codigo);
        lista.setDenominacion(denominacion);
        auditar(lista, usuario);
        em.persist(lista);

        List<ListaPrecioArticulo> precios = em.createQuery(
                        "SELECT lpa FROM ListaPrecioArticulo lpa WHERE lpa.listaPrecio = :base", ListaPrecioArticulo.class)
                .setParameter("base", base)
                .getResultList();
        for (ListaPrecioArticulo p : precios) {
            if (excluidos.contains(p.getArticulo().getCodigo())) {
                continue;
            }
            ListaPrecioArticulo lpa = new ListaPrecioArticulo();
            lpa.setListaPrecio(lista);
            lpa.setArticulo(p.getArticulo());
            lpa.setPrecioVenta(Math.round(p.getPrecioVenta() * factor * 100.0) / 100.0);
            auditar(lpa, usuario);
            em.persist(lpa);
        }
    }

    private boolean existe(String entidad, String campo, Object valor) {
        return em.createQuery("SELECT COUNT(e) FROM " + entidad + " e WHERE e." + campo + " = :valor", Long.class)
                .setParameter("valor", valor)
                .getSingleResult() > 0;
    }

    private void auditar(AuditoriaApp entidad, Usuario usuario) {
        Date ahora = new Date();
        entidad.setFechaAlta(ahora);
        entidad.setFechaModificacion(ahora);
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
    }

    private <T> T primero(Class<T> clase) {
        List<T> lista = em.createQuery("SELECT e FROM " + clase.getSimpleName() + " e", clase)
                .setMaxResults(1)
                .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }
}
