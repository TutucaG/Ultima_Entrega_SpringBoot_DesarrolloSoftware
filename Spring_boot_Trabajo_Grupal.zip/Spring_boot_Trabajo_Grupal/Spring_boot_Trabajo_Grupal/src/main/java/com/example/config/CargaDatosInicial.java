package com.example.config;

import com.example.entidades.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;

// Datos de prueba. Todo es idempotente: cada dato se crea (o se corrige) solo si hace falta,
// asi que se puede arrancar la aplicacion las veces que se quiera sobre la misma base.
// Los comprobantes de ejemplo se cargan solo si la base no tiene ninguno.
@Slf4j
@Component
public class CargaDatosInicial implements CommandLineRunner {

    @PersistenceContext
    private EntityManager em;

    @Value("${app.cargar-datos-prueba:true}")
    private boolean cargarDatosPrueba;

    private static final double ALICUOTA_IVA = 21.0;

    // Condiciones frente al IVA (codigos de la tabla de ARCA)
    private static final int RI = 1, EXENTO = 4, CF = 5, MONOTRIBUTO = 6;

    // CUIT de versiones anteriores con digito verificador incorrecto -> CUIT valido
    private static final Map<String, String> CUIT_CORREGIDOS = Map.of(
            "30-12345678-9", "30-12345678-1",
            "20-30111222-3", "20-30111222-0",
            "27-33214567-2", "27-33214567-9",
            "30-71566890-1", "30-71566890-0");

    private record ArticuloSemilla(String rubro, int codigoRubro, String marca, int codigoMarca,
                                   String codigo, String denominacion, double precio) {
    }

    // precio = neto (sin IVA) en la lista general
    private static final List<ArticuloSemilla> ARTICULOS = List.of(
            new ArticuloSemilla("Bebidas", 1, "Coca-Cola", 1, "ART-001", "Gaseosa 500ml", 750),
            new ArticuloSemilla("Bebidas", 1, "Villavicencio", 2, "ART-002", "Agua mineral 1.5L", 520),
            new ArticuloSemilla("Bebidas", 1, "Coca-Cola", 1, "ART-003", "Jugo de naranja 1L", 980),
            new ArticuloSemilla("Bebidas", 1, "Quilmes", 3, "ART-004", "Cerveza lata 473ml", 1350),
            new ArticuloSemilla("Bebidas", 1, "Coca-Cola", 1, "ART-005", "Gaseosa 2.25L", 1890),
            new ArticuloSemilla("Bebidas", 1, "Villavicencio", 2, "ART-006", "Agua saborizada 1.5L", 870),
            new ArticuloSemilla("Bebidas", 1, "Pepsico", 4, "ART-007", "Bebida isotónica 500ml", 1150),
            new ArticuloSemilla("Bebidas", 1, "Marolio", 11, "ART-008", "Soda sifón 2L", 640),
            new ArticuloSemilla("Bebidas", 1, "Pepsico", 4, "ART-009", "Gaseosa lima-limón 1.5L", 1490),
            new ArticuloSemilla("Bebidas", 1, "Quilmes", 3, "ART-010", "Cerveza rubia 1L retornable", 2100),
            new ArticuloSemilla("Almacén", 2, "Molinos", 6, "ART-011", "Fideos spaghetti 500g", 1250),
            new ArticuloSemilla("Almacén", 2, "Molinos", 6, "ART-012", "Arroz largo fino 1kg", 1680),
            new ArticuloSemilla("Almacén", 2, "Molinos", 6, "ART-013", "Aceite de girasol 1.5L", 3450),
            new ArticuloSemilla("Almacén", 2, "Molinos", 6, "ART-014", "Harina 000 1kg", 990),
            new ArticuloSemilla("Almacén", 2, "Marolio", 11, "ART-015", "Yerba mate 1kg", 4200),
            new ArticuloSemilla("Almacén", 2, "Marolio", 11, "ART-016", "Azúcar 1kg", 1150),
            new ArticuloSemilla("Lácteos", 3, "La Serenísima", 7, "ART-017", "Leche entera 1L", 1290),
            new ArticuloSemilla("Lácteos", 3, "Sancor", 10, "ART-018", "Yogur bebible frutilla 1L", 1890),
            new ArticuloSemilla("Lácteos", 3, "Sancor", 10, "ART-019", "Queso cremoso 1kg", 8900),
            new ArticuloSemilla("Lácteos", 3, "La Serenísima", 7, "ART-020", "Manteca 200g", 2350),
            new ArticuloSemilla("Limpieza", 4, "Ayudín", 8, "ART-021", "Lavandina 1L", 890),
            new ArticuloSemilla("Limpieza", 4, "Magistral", 9, "ART-022", "Detergente 750ml", 1980),
            new ArticuloSemilla("Limpieza", 4, "Ayudín", 8, "ART-023", "Limpiador de pisos 900ml", 1450),
            new ArticuloSemilla("Snacks y golosinas", 5, "Arcor", 5, "ART-024", "Galletitas de agua 3x100g", 1150),
            new ArticuloSemilla("Snacks y golosinas", 5, "Arcor", 5, "ART-025", "Alfajor triple chocolate", 950),
            new ArticuloSemilla("Snacks y golosinas", 5, "Pepsico", 4, "ART-026", "Papas fritas 150g", 2100),
            new ArticuloSemilla("Snacks y golosinas", 5, "Arcor", 5, "ART-027", "Chocolate con leche 100g", 1750),
            new ArticuloSemilla("Snacks y golosinas", 5, "Arcor", 5, "ART-028", "Caramelos masticables 800g", 3100),
            new ArticuloSemilla("Perfumería", 6, "Dove", 12, "ART-029", "Jabón de tocador 90g", 990),
            new ArticuloSemilla("Perfumería", 6, "Dove", 12, "ART-030", "Shampoo 400ml", 4300),
            new ArticuloSemilla("Bebidas", 1, "Coca-Cola", 1, "ART-031", "Agua tónica 1.5L", 1350),
            new ArticuloSemilla("Bebidas", 1, "Arcor", 5, "ART-032", "Jugo en polvo naranja x18", 1650),
            new ArticuloSemilla("Bebidas", 1, "Bodega Norton", 13, "ART-033", "Vino tinto Malbec 750ml", 4200),
            new ArticuloSemilla("Bebidas", 1, "Bodega Norton", 13, "ART-034", "Vino blanco Torrontés 750ml", 3900),
            new ArticuloSemilla("Bebidas", 1, "Pepsico", 4, "ART-035", "Bebida energizante lata 473ml", 1800),
            new ArticuloSemilla("Almacén", 2, "Molinos", 6, "ART-036", "Fideos tirabuzón 500g", 1250),
            new ArticuloSemilla("Almacén", 2, "Molinos", 6, "ART-037", "Polenta instantánea 500g", 890),
            new ArticuloSemilla("Almacén", 2, "Marolio", 11, "ART-038", "Lentejas 400g", 1100),
            new ArticuloSemilla("Almacén", 2, "Marolio", 11, "ART-039", "Arvejas en lata 350g", 720),
            new ArticuloSemilla("Almacén", 2, "Marolio", 11, "ART-040", "Tomate triturado 520g", 980),
            new ArticuloSemilla("Almacén", 2, "Hellmann's", 14, "ART-041", "Mayonesa 475g", 2300),
            new ArticuloSemilla("Almacén", 2, "La Virginia", 15, "ART-042", "Café molido 500g", 5900),
            new ArticuloSemilla("Almacén", 2, "La Virginia", 15, "ART-043", "Té en saquitos x50", 1450),
            new ArticuloSemilla("Almacén", 2, "Arcor", 5, "ART-044", "Mermelada de durazno 454g", 1980),
            new ArticuloSemilla("Lácteos", 3, "La Serenísima", 7, "ART-045", "Dulce de leche 400g", 2200),
            new ArticuloSemilla("Lácteos", 3, "La Serenísima", 7, "ART-046", "Leche descremada 1L", 1290),
            new ArticuloSemilla("Lácteos", 3, "La Serenísima", 7, "ART-047", "Crema de leche 200ml", 1550),
            new ArticuloSemilla("Lácteos", 3, "Sancor", 10, "ART-048", "Queso rallado 150g", 2650),
            new ArticuloSemilla("Lácteos", 3, "Sancor", 10, "ART-049", "Yogur firme vainilla 190g", 760),
            new ArticuloSemilla("Limpieza", 4, "Vivere", 16, "ART-050", "Suavizante para ropa 900ml", 2450),
            new ArticuloSemilla("Limpieza", 4, "Ala", 17, "ART-051", "Jabón en polvo 800g", 3200),
            new ArticuloSemilla("Limpieza", 4, "Magistral", 9, "ART-052", "Esponja multiuso x3", 950),
            new ArticuloSemilla("Limpieza", 4, "Ayudín", 8, "ART-053", "Desinfectante aerosol 360ml", 3100),
            new ArticuloSemilla("Limpieza", 4, "Marolio", 11, "ART-054", "Bolsas de residuos x10", 1100),
            new ArticuloSemilla("Snacks y golosinas", 5, "Pepsico", 4, "ART-055", "Maní salado 120g", 1300),
            new ArticuloSemilla("Snacks y golosinas", 5, "Pepsico", 4, "ART-056", "Chizitos 120g", 1450),
            new ArticuloSemilla("Snacks y golosinas", 5, "Arcor", 5, "ART-057", "Turrón de maní 25g", 450),
            new ArticuloSemilla("Perfumería", 6, "Colgate", 18, "ART-058", "Pasta dental 90g", 1700),
            new ArticuloSemilla("Perfumería", 6, "Dove", 12, "ART-059", "Desodorante aerosol 150ml", 3600),
            new ArticuloSemilla("Perfumería", 6, "Higienol", 19, "ART-060", "Papel higiénico x4", 2300));

    private record ClienteSemilla(String cuit, String denominacion, String calle, String numero,
                                  int condicion, String email, String telefono) {
    }

    private static final List<ClienteSemilla> CLIENTES = List.of(
            new ClienteSemilla("30-12345678-1", "Empresa Tech S.A.", "Belgrano", "250", RI, "compras@empresatech.com", "0261-4000000"),
            new ClienteSemilla("20-30111222-0", "Comercial Andina S.R.L.", "Mitre", "845", RI, "administracion@andina.com.ar", "0261-4231100"),
            new ClienteSemilla("30-70984512-4", "Supermercado El Sol S.A.", "Las Heras", "1220", RI, "proveedores@elsol.com.ar", "0261-4255870"),
            new ClienteSemilla("20-28456123-7", "Pérez Juan Carlos", "San Juan", "377", MONOTRIBUTO, "jcperez@gmail.com", "261-5123456"),
            new ClienteSemilla("27-33214567-9", "Gómez María Laura", "Rivadavia", "56", MONOTRIBUTO, "mlgomez@hotmail.com", "261-6987412"),
            new ClienteSemilla("30-71566890-0", "Distribuidora Cuyo S.R.L.", "Ruta 40 km", "12", RI, "ventas@distcuyo.com.ar", "0261-4987001"),
            new ClienteSemilla("30-68512347-5", "Fundación Manos Unidas", "Colón", "980", EXENTO, "contacto@manosunidas.org.ar", "0261-4445566"),
            new ClienteSemilla("27-40125896-0", "Rodríguez Ana Belén", "Sarmiento", "1543", CF, "anabelen.r@gmail.com", "261-4785236"),
            new ClienteSemilla("20-31478520-8", "López Ricardo (Almacén Don Pepe)", "Godoy Cruz", "2210", MONOTRIBUTO, "donpepe.almacen@gmail.com", "261-5874120"),
            new ClienteSemilla("30-71045698-0", "Hotel Aconcagua S.A.", "San Lorenzo", "545", RI, "compras@hotelaconcagua.com.ar", "0261-5200500"),
            new ClienteSemilla("30-70123988-8", "Bodega Los Andes S.A.", "Ruta 60", "3500", RI, "administracion@bodegalosandes.com", "0261-4960200"),
            new ClienteSemilla("30-71458963-2", "Farmacia Central S.R.L.", "Av. San Martín", "1100", RI, "farmaciacentral@gmail.com", "0261-4291234"),
            new ClienteSemilla("27-35874120-2", "Martínez Lucía", "Pedro Molina", "312", MONOTRIBUTO, "lucia.martinez@yahoo.com", "261-6321458"),
            new ClienteSemilla("30-52634179-8", "Club Atlético Independiente Rivadavia", "Av. del Libertador", "1", EXENTO, "secretaria@csir.org.ar", "0261-4250500"),
            new ClienteSemilla("20-36985214-1", "Fernández Diego (Kiosco La Esquina)", "Patricias Mendocinas", "870", MONOTRIBUTO, "kiosco.laesquina@gmail.com", "261-5412369"));

    private final Random azar = new Random(2026); // CAE de ejemplo reproducibles

    @Override
    @Transactional
    public void run(String... args) {
        if (!cargarDatosPrueba) {
            log.info("Carga de datos de prueba desactivada (app.cargar-datos-prueba=false).");
            return;
        }

        // ---------- Datos base (cada uno se crea solo si todavia no existe) ----------
        Usuario usuario = primero(Usuario.class);
        if (usuario == null) {
            usuario = new Usuario();
            usuario.setUsuario("admin");
            usuario.setClave("admin");
            usuario.setNombre("Administrador");
            usuario.setApellido("Sistema");
            em.persist(usuario);
        }

        PuntoVenta central = asegurarPuntoVenta(1, "Sucursal Central", "Av. San Martín 100 - Mendoza", usuario);
        PuntoVenta godoyCruz = asegurarPuntoVenta(2, "Sucursal Godoy Cruz", "San Martín Sur 1450 - Godoy Cruz", usuario);

        asegurarCondicionIva(RI, "IVA Responsable Inscripto", usuario);
        asegurarCondicionIva(EXENTO, "IVA Sujeto Exento", usuario);
        asegurarCondicionIva(CF, "Consumidor Final", usuario);
        asegurarCondicionIva(MONOTRIBUTO, "Responsable Monotributo", usuario);

        if (primero(TipoMoneda.class) == null) {
            TipoMoneda pesos = new TipoMoneda();
            pesos.setCodigoAfip("PES");
            pesos.setDenominacion("Pesos Argentinos");
            pesos.setSimbolo("$");
            auditar(pesos, usuario);
            em.persist(pesos);
        }

        // ---------- Articulos y listas de precios ----------
        ListaPrecio general = asegurarLista("LP-01", "Lista General", usuario);
        ListaPrecio mayorista = asegurarLista("LP-02", "Lista Mayorista", usuario);
        ListaPrecio supermercados = asegurarLista("LP-03", "Lista Supermercados", usuario);
        for (ArticuloSemilla a : ARTICULOS) {
            Articulo articulo = asegurarArticulo(a, usuario);
            asegurarPrecio(general, articulo, a.precio(), usuario);
            // Mayorista: 15 % menos, sin cervezas ni perfumeria
            if (!Set.of("ART-004", "ART-010").contains(a.codigo()) && !"Perfumería".equals(a.rubro())) {
                asegurarPrecio(mayorista, articulo, redondear(a.precio() * 0.85), usuario);
            }
            // Supermercados: 10 % menos, solo almacen, lacteos y limpieza
            if (Set.of("Almacén", "Lácteos", "Limpieza").contains(a.rubro())) {
                asegurarPrecio(supermercados, articulo, redondear(a.precio() * 0.90), usuario);
            }
        }

        // ---------- Clientes (con su condicion frente al IVA y CUIT valido) ----------
        CUIT_CORREGIDOS.forEach(this::corregirCuit);
        for (ClienteSemilla c : CLIENTES) {
            asegurarCliente(c, condicion(c.condicion()), usuario);
        }

        Long cantidad = em.createQuery("SELECT COUNT(f) FROM FacturaVenta f", Long.class).getSingleResult();
        if (cantidad > 0) {
            log.info("La base ya tiene {} comprobante(s); no se cargan comprobantes de prueba.", cantidad);
            return;
        }

        // ---------- Comprobantes de ejemplo ----------
        // Calculados con los precios de cada lista y la misma formula que FacturaService.
        // Numeracion correlativa por punto de venta y por letra, como en ARCA.
        Map<String, Long> numeracion = new HashMap<>();
        LocalDate hoy = LocalDate.now();
        int creados = 0;

        creados += emitir(central, "30-12345678-1", general, LocalDate.of(2026, 8, 3), null, numeracion, usuario,
                "ART-001:24", "ART-005:12", "ART-003:12:5");
        creados += emitir(central, null, general, LocalDate.of(2026, 8, 5), null, numeracion, usuario,
                "ART-025:6", "ART-001:2");
        creados += emitir(central, "30-70984512-4", supermercados, LocalDate.of(2026, 8, 12), null, numeracion, usuario,
                "ART-011:120", "ART-012:80", "ART-013:40:3", "ART-017:200", "ART-021:60", "ART-022:48");
        creados += emitir(central, "20-28456123-7", general, LocalDate.of(2026, 8, 20), "Error en las cantidades",
                numeracion, usuario, "ART-015:3", "ART-016:5");
        creados += emitir(central, "30-68512347-5", general, LocalDate.of(2026, 9, 2), null, numeracion, usuario,
                "ART-017:30", "ART-024:20", "ART-014:15");
        creados += emitir(central, "30-71566890-0", mayorista, LocalDate.of(2026, 9, 15), null, numeracion, usuario,
                "ART-002:150", "ART-006:100", "ART-007:60:2", "ART-009:80");
        creados += emitir(central, null, general, LocalDate.of(2026, 9, 28), null, numeracion, usuario,
                "ART-026:2", "ART-009:1", "ART-027:3");
        creados += emitir(central, "30-71045698-0", general, LocalDate.of(2026, 10, 7), "Facturado al cliente equivocado",
                numeracion, usuario, "ART-029:200", "ART-030:50");
        creados += emitir(central, "27-33214567-9", general, LocalDate.of(2026, 10, 19), null, numeracion, usuario,
                "ART-020:10", "ART-019:2");
        creados += emitir(central, "30-70123988-8", supermercados, LocalDate.of(2026, 11, 4), null, numeracion, usuario,
                "ART-021:24", "ART-023:24", "ART-022:12");
        creados += emitir(godoyCruz, "20-30111222-0", mayorista, LocalDate.of(2026, 10, 10), null, numeracion, usuario,
                "ART-011:300:5", "ART-012:200", "ART-016:150");
        creados += emitir(godoyCruz, null, general, LocalDate.of(2026, 11, 2), null, numeracion, usuario,
                "ART-028:1", "ART-018:2");

        // Borradores (sin numero ni CAE): uno con un rechazo de ARCA por la fecha
        creados += borrador(central, "30-71458963-2", general, hoy.minusDays(1), null, usuario,
                "ART-029:48", "ART-030:24:10");
        creados += borrador(central, null, general, hoy, null, usuario, "ART-001:2", "ART-025:3");
        creados += borrador(godoyCruz, "27-35874120-2", mayorista, hoy.minusDays(12),
                "ARCA rechazó el comprobante: la fecha de emisión debe estar dentro de los 5 días anteriores o "
                        + "posteriores a hoy (editá la fecha del borrador)", usuario, "ART-015:10", "ART-016:10");

        log.info("Datos de prueba cargados: {} comprobantes.", creados);
    }

    // =====================================================================
    // Comprobantes de ejemplo
    // =====================================================================

    // Factura autorizada (con numero y CAE); si motivoAnulacion != null queda ANULADA
    private int emitir(PuntoVenta pv, String cuit, ListaPrecio lista, LocalDate fecha, String motivoAnulacion,
                       Map<String, Long> numeracion, Usuario usuario, String... renglones) {
        FacturaVenta f = armar(pv, cuit, lista, fecha, usuario, renglones);
        String letra = f.getCondicionIva().getCodigoAfip() == RI ? "A" : "B";
        f.setNumero(numeracion.merge(pv.getNumero() + letra, 1L, Long::sum));
        StringBuilder cae = new StringBuilder("7");
        for (int i = 0; i < 13; i++) {
            cae.append(azar.nextInt(10));
        }
        f.setCae(cae.toString());
        f.setCaeFechaVencimiento(java.sql.Date.valueOf(fecha.plusDays(10)));
        f.setResultadoAfip("A");
        f.setEstado("EMITIDA");
        if (motivoAnulacion != null) {
            f.setEstado("ANULADA");
            f.setFechaAnulacion(java.sql.Date.valueOf(fecha.plusDays(2)));
            f.setObservaciones(motivoAnulacion);
        }
        em.persist(f); // los detalles se guardan solos por el cascade
        return 1;
    }

    private int borrador(PuntoVenta pv, String cuit, ListaPrecio lista, LocalDate fecha, String rechazo,
                         Usuario usuario, String... renglones) {
        FacturaVenta f = armar(pv, cuit, lista, fecha, usuario, renglones);
        f.setEstado("BORRADOR");
        if (rechazo != null) {
            f.setResultadoAfip("R");
            f.setMotivoRechazo(rechazo);
        }
        em.persist(f);
        return 1;
    }

    // renglon = "CODIGO:cantidad[:bonificacion%]"
    private FacturaVenta armar(PuntoVenta pv, String cuit, ListaPrecio lista, LocalDate fecha,
                               Usuario usuario, String... renglones) {
        Cliente cliente = cuit == null ? null : buscarUno("Cliente", "cuitCuil", cuit, Cliente.class);
        FacturaVenta f = new FacturaVenta();
        f.setFechaEmision(java.sql.Date.valueOf(fecha));
        f.setPuntoVenta(pv);
        f.setCliente(cliente);
        f.setCondicionIva(cliente == null ? condicion(CF) : cliente.getCondicionIva());
        f.setTipoMoneda(primero(TipoMoneda.class));
        auditar(f, usuario);

        List<FacturaVentaDetalle> detalles = new ArrayList<>();
        double total = 0;
        for (String renglon : renglones) {
            String[] partes = renglon.split(":");
            Articulo articulo = buscarUno("Articulo", "codigo", partes[0], Articulo.class);
            ListaPrecioArticulo precio = em.createQuery(
                            "SELECT lpa FROM ListaPrecioArticulo lpa WHERE lpa.listaPrecio = :l AND lpa.articulo = :a",
                            ListaPrecioArticulo.class)
                    .setParameter("l", lista).setParameter("a", articulo)
                    .getSingleResult();
            double cantidad = Double.parseDouble(partes[1]);
            double bonificacion = partes.length > 2 ? Double.parseDouble(partes[2]) : 0;
            double bruto = cantidad * precio.getPrecioVenta();
            double neto = redondear(bruto - bruto * bonificacion / 100);
            double iva = redondear(neto * ALICUOTA_IVA / 100);

            FacturaVentaDetalle d = new FacturaVentaDetalle();
            d.setFactura(f); // relacion bidireccional
            d.setListaPrecioArticulo(precio);
            d.setDescripcion(articulo.getDenominacion());
            d.setCantidad(cantidad);
            d.setPrecioUnitario(precio.getPrecioVenta());
            d.setPorcentajeBonificacion(bonificacion);
            d.setImporteNeto(neto);
            d.setImporteIva(iva);
            d.setImporteSubtotal(redondear(neto + iva));
            detalles.add(d);
            total += d.getImporteSubtotal();
        }
        f.setDetalles(detalles);
        f.setImporteTotal(redondear(total));
        f.setImporteSaldo(redondear(total));
        return f;
    }

    // =====================================================================
    // Datos maestros
    // =====================================================================

    private PuntoVenta asegurarPuntoVenta(int numero, String descripcion, String domicilio, Usuario usuario) {
        PuntoVenta pv = buscarUno("PuntoVenta", "numero", numero, PuntoVenta.class);
        if (pv != null) {
            return pv;
        }
        pv = new PuntoVenta();
        pv.setNumero(numero);
        pv.setDescripcion(descripcion);
        pv.setTipoEmision("CAE");
        pv.setDomicilioComercial(domicilio);
        auditar(pv, usuario);
        em.persist(pv);
        return pv;
    }

    private void asegurarCondicionIva(int codigoAfip, String denominacion, Usuario usuario) {
        if (condicion(codigoAfip) != null) {
            return;
        }
        CondicionIva ci = new CondicionIva();
        ci.setCodigoAfip(codigoAfip);
        ci.setDenominacion(denominacion);
        auditar(ci, usuario);
        em.persist(ci);
    }

    private CondicionIva condicion(int codigoAfip) {
        return buscarUno("CondicionIva", "codigoAfip", codigoAfip, CondicionIva.class);
    }

    private ListaPrecio asegurarLista(String codigo, String denominacion, Usuario usuario) {
        ListaPrecio lista = buscarUno("ListaPrecio", "codigo", codigo, ListaPrecio.class);
        if (lista != null) {
            return lista;
        }
        lista = new ListaPrecio();
        lista.setCodigo(codigo);
        lista.setDenominacion(denominacion);
        auditar(lista, usuario);
        em.persist(lista);
        return lista;
    }

    private Rubro asegurarRubro(int codigo, String denominacion, Usuario usuario) {
        Rubro rubro = buscarUno("Rubro", "codigo", codigo, Rubro.class);
        if (rubro == null) {
            rubro = new Rubro();
            rubro.setCodigo(codigo);
            rubro.setDenominacion(denominacion);
            auditar(rubro, usuario);
            em.persist(rubro);
        }
        return rubro;
    }

    private Marca asegurarMarca(int codigo, String denominacion, Usuario usuario) {
        Marca marca = buscarUno("Marca", "codigo", codigo, Marca.class);
        if (marca == null) {
            marca = new Marca();
            marca.setCodigo(codigo);
            marca.setDenominacion(denominacion);
            auditar(marca, usuario);
            em.persist(marca);
        }
        return marca;
    }

    // Crea el articulo o corrige su rubro / marca si fue cargado por una version anterior
    private Articulo asegurarArticulo(ArticuloSemilla s, Usuario usuario) {
        Rubro rubro = asegurarRubro(s.codigoRubro(), s.rubro(), usuario);
        Marca marca = asegurarMarca(s.codigoMarca(), s.marca(), usuario);
        Articulo articulo = buscarUno("Articulo", "codigo", s.codigo(), Articulo.class);
        if (articulo == null) {
            articulo = new Articulo();
            articulo.setCodigo(s.codigo());
            articulo.setDenominacion(s.denominacion());
            articulo.setRubro(rubro);
            articulo.setMarca(marca);
            auditar(articulo, usuario);
            em.persist(articulo);
        } else if (articulo.getRubro() != rubro || articulo.getMarca() != marca) {
            articulo.setRubro(rubro);
            articulo.setMarca(marca);
            articulo.setFechaModificacion(new Date());
        }
        return articulo;
    }

    // Agrega el articulo a la lista (no pisa un precio ya cargado)
    private void asegurarPrecio(ListaPrecio lista, Articulo articulo, double precio, Usuario usuario) {
        Long existe = em.createQuery(
                        "SELECT COUNT(lpa) FROM ListaPrecioArticulo lpa WHERE lpa.listaPrecio = :l AND lpa.articulo = :a",
                        Long.class)
                .setParameter("l", lista).setParameter("a", articulo)
                .getSingleResult();
        if (existe > 0) {
            return;
        }
        ListaPrecioArticulo lpa = new ListaPrecioArticulo();
        lpa.setListaPrecio(lista);
        lpa.setArticulo(articulo);
        lpa.setPrecioVenta(precio);
        auditar(lpa, usuario);
        em.persist(lpa);
    }

    private void corregirCuit(String incorrecto, String correcto) {
        Cliente c = buscarUno("Cliente", "cuitCuil", incorrecto, Cliente.class);
        if (c != null && buscarUno("Cliente", "cuitCuil", correcto, Cliente.class) == null) {
            c.setCuitCuil(correcto);
            em.flush(); // para que la busqueda por CUIT de asegurarCliente ya lo encuentre corregido
        }
    }

    // Crea el cliente o completa la condicion de IVA / contacto si le faltan
    private void asegurarCliente(ClienteSemilla s, CondicionIva condicion, Usuario usuario) {
        Cliente cliente = buscarUno("Cliente", "cuitCuil", s.cuit(), Cliente.class);
        if (cliente != null) {
            if (cliente.getCondicionIva() == null) {
                cliente.setCondicionIva(condicion);
            }
            Contacto contacto = cliente.getContacto();
            if (contacto != null && contacto.getEmail() == null) {
                contacto.setEmail(s.email());
                contacto.setTelefono(s.telefono());
            }
            return;
        }
        Contacto contacto = new Contacto();
        contacto.setEmail(s.email());
        contacto.setTelefono(s.telefono());
        em.persist(contacto);

        Domicilio domicilio = new Domicilio();
        domicilio.setNombreCalle(s.calle());
        domicilio.setNumeroCalle(s.numero());
        em.persist(domicilio);

        cliente = new Cliente();
        cliente.setCuitCuil(s.cuit());
        cliente.setDenominacion(s.denominacion());
        cliente.setContacto(contacto);
        cliente.setDomicilio(domicilio);
        cliente.setCondicionIva(condicion);
        auditar(cliente, usuario);
        em.persist(cliente);
    }

    // =====================================================================
    // Auxiliares
    // =====================================================================

    private <T> T buscarUno(String entidad, String campo, Object valor, Class<T> clase) {
        List<T> lista = em.createQuery("SELECT e FROM " + entidad + " e WHERE e." + campo + " = :valor ORDER BY e.id", clase)
                .setParameter("valor", valor)
                .setMaxResults(1)
                .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }

    private void auditar(AuditoriaApp entidad, Usuario usuario) {
        Date ahora = new Date();
        entidad.setFechaAlta(ahora);
        entidad.setFechaModificacion(ahora);
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
    }

    private <T> T primero(Class<T> clase) {
        List<T> lista = em.createQuery("SELECT e FROM " + clase.getSimpleName() + " e ORDER BY e.id", clase)
                .setMaxResults(1)
                .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
