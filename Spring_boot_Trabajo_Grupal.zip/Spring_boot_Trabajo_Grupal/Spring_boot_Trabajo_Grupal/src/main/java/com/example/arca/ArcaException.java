package com.example.arca;

// Falla de comunicacion o de configuracion con ARCA (no es un rechazo del comprobante).
// Se traduce a 502 Bad Gateway en GlobalExceptionHandler.
public class ArcaException extends RuntimeException {

    public ArcaException(String mensaje) {
        super(mensaje);
    }

    public ArcaException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
