package com.example.arca;

import com.example.entidades.CondicionIva;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

// Tipo de comprobante segun la tabla de ARCA (CbteTipo). El emisor es Responsable Inscripto:
//   - receptor Responsable Inscripto           -> Factura A (codigo 1)
//   - receptor Consumidor Final, Monotributo... -> Factura B (codigo 6)
// La numeracion es independiente por punto de venta y por tipo de comprobante.
@Getter
@RequiredArgsConstructor
public enum TipoComprobante {

    FACTURA_A(1, "A"),
    FACTURA_B(6, "B");

    // Codigo ARCA de la condicion "IVA Responsable Inscripto" (tabla de condiciones frente al IVA)
    public static final int CONDICION_RESPONSABLE_INSCRIPTO = 1;

    private final int codigoArca;
    private final String letra;

    public static TipoComprobante para(CondicionIva condicionReceptor) {
        return condicionReceptor != null && condicionReceptor.getCodigoAfip() == CONDICION_RESPONSABLE_INSCRIPTO
                ? FACTURA_A
                : FACTURA_B;
    }
}
