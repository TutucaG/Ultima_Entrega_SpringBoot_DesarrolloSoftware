package com.example.repository;

import com.example.arca.TipoComprobante;
import com.example.dto.FacturaFiltrosDTO;
import com.example.dto.FacturaReporteDTO;
import com.example.entidades.FacturaVenta;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Repository
public class FacturaVentaRepository {

    @PersistenceContext
    private EntityManager em;

    // Factura A si el receptor es Responsable Inscripto, B en cualquier otro caso (ver TipoComprobante)
    private static final String LETRA =
            "CASE WHEN ci.codigoAfip = " + TipoComprobante.CONDICION_RESPONSABLE_INSCRIPTO + " THEN 'A' ELSE 'B' END";

    private static final String SELECT_REPORTE =
            "SELECT new " + FacturaReporteDTO.class.getName() + "(" +
                    " f.id, " + LETRA + ", f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'), " +
                    " ci.denominacion, pv.descripcion, pv.numero, f.importeTotal, COUNT(d), " +
                    " f.estado, f.observaciones, f.cae, f.resultadoAfip" +
                    ") " +
                    "FROM FacturaVenta f " +
                    "LEFT JOIN f.cliente c " +
                    "JOIN f.condicionIva ci " +
                    "JOIN f.puntoVenta pv " +
                    "LEFT JOIN f.detalles d " +
                    "WHERE 1=1 ";

    private static final String GROUP_BY_REPORTE =
            "GROUP BY f.id, ci.codigoAfip, f.numero, f.fechaEmision, c.denominacion, ci.denominacion, " +
                    "pv.descripcion, pv.numero, f.importeTotal, f.estado, f.observaciones, f.cae, f.resultadoAfip ";

    // ---------------- Lectura (reporte) ----------------

    // Arma el WHERE solo con los filtros que vienen cargados
    public List<FacturaReporteDTO> buscarFacturasFiltradas(FacturaFiltrosDTO filtros) {
        StringBuilder jpql = new StringBuilder(SELECT_REPORTE);
        Map<String, Object> params = new HashMap<>();

        if (filtros.getFechaDesde() != null) {
            jpql.append("AND f.fechaEmision >= :fechaDesde ");
            params.put("fechaDesde", filtros.getFechaDesde());
        }
        if (filtros.getFechaHasta() != null) {
            jpql.append("AND f.fechaEmision <= :fechaHasta ");
            params.put("fechaHasta", filtros.getFechaHasta());
        }
        if (filtros.getEstado() != null && !filtros.getEstado().isBlank()) {
            jpql.append("AND f.estado = :estado ");
            params.put("estado", filtros.getEstado().trim());
        }
        if (filtros.getMontoMinimo() != null) {
            jpql.append("AND f.importeTotal >= :montoMinimo ");
            params.put("montoMinimo", filtros.getMontoMinimo());
        }
        if (filtros.getMontoMaximo() != null) {
            jpql.append("AND f.importeTotal <= :montoMaximo ");
            params.put("montoMaximo", filtros.getMontoMaximo());
        }
        if (filtros.getClienteId() != null) {
            if (filtros.getClienteId() == 0) {
                jpql.append("AND c.id IS NULL "); // solo Consumidor Final
            } else {
                jpql.append("AND c.id = :clienteId ");
                params.put("clienteId", filtros.getClienteId());
            }
        }
        if (filtros.getPuntoVentaId() != null) {
            jpql.append("AND pv.id = :puntoVentaId ");
            params.put("puntoVentaId", filtros.getPuntoVentaId());
        }
        if (filtros.getNumero() != null) {
            jpql.append("AND f.numero = :numero ");
            params.put("numero", filtros.getNumero());
        }

        // Mas recientes primero; en el mismo dia: borradores arriba y despues por punto de venta y numero descendente
        jpql.append(GROUP_BY_REPORTE).append("ORDER BY f.fechaEmision DESC, CASE WHEN f.numero IS NULL THEN 0 ELSE 1 END, pv.numero, f.numero DESC, f.id DESC");

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql.toString(), FacturaReporteDTO.class);
        params.forEach(query::setParameter);
        return query.getResultList();
    }

    // Mismo DTO del reporte pero de una sola factura (respuesta de POST, PUT y autorizar)
    public Optional<FacturaReporteDTO> buscarReportePorId(Long id) {
        return em.createQuery(SELECT_REPORTE + "AND f.id = :id " + GROUP_BY_REPORTE, FacturaReporteDTO.class)
                .setParameter("id", id)
                .getResultStream()
                .findFirst();
    }

    // ---------------- Escritura ----------------

    public Optional<FacturaVenta> buscarPorId(Long id) {
        return Optional.ofNullable(em.find(FacturaVenta.class, id));
    }

    // SELECT ... FOR UPDATE: la fila queda bloqueada hasta que termine la transaccion.
    // Se hace con SQL nativo simple porque el "FOR UPDATE OF alias" que genera Hibernate
    // no existe en MariaDB (el MySQL de XAMPP); asi funciona igual en MySQL y en MariaDB.
    public Optional<FacturaVenta> buscarParaModificar(Long id) {
        if (!bloquearFila("factura_venta", id)) {
            return Optional.empty();
        }
        return Optional.of(em.find(FacturaVenta.class, id));
    }

    // Serializa la numeracion de un punto de venta (dos autorizaciones no pueden tomar el mismo numero)
    public void bloquearPuntoVenta(Long puntoVentaId) {
        bloquearFila("punto_venta", puntoVentaId);
    }

    private boolean bloquearFila(String tabla, Long id) {
        return !em.createNativeQuery("SELECT id FROM " + tabla + " WHERE id = ?1 FOR UPDATE")
                .setParameter(1, id)
                .getResultList()
                .isEmpty();
    }

    public FacturaVenta guardar(FacturaVenta factura) {
        if (factura.getId() == null) {
            em.persist(factura); // cascade ALL: tambien inserta los detalles
            return factura;
        }
        return em.merge(factura);
    }

    public void eliminar(FacturaVenta factura) {
        em.remove(factura); // cascade ALL + orphanRemoval: tambien borra los detalles
    }

    // Como en ARCA, la numeracion es correlativa por punto de venta Y por tipo de comprobante (A / B).
    // Se usa en modo simulado; en homologacion el numero lo informa ARCA (FECompUltimoAutorizado).
    // Se llama con el punto de venta bloqueado y en READ COMMITTED (ver FacturaService.autorizar):
    // asi siempre ve el ultimo numero confirmado y dos autorizaciones no pueden tomar el mismo.
    public Long siguienteNumero(Long puntoVentaId, TipoComprobante tipo) {
        String condicion = tipo == TipoComprobante.FACTURA_A ? " = " : " <> ";
        Long maximo = em.createQuery(
                        "SELECT MAX(f.numero) FROM FacturaVenta f WHERE f.puntoVenta.id = :pv " +
                                "AND f.condicionIva.codigoAfip" + condicion + ":ri", Long.class)
                .setParameter("pv", puntoVentaId)
                .setParameter("ri", TipoComprobante.CONDICION_RESPONSABLE_INSCRIPTO)
                .getSingleResult();
        return maximo == null ? 1L : maximo + 1;
    }

    // Ultimo comprobante con numero (emitido o anulado) del mismo punto de venta y tipo (A / B).
    // Se usa para controlar que la fecha no vaya hacia atras (regla de ARCA).
    public Optional<FacturaVenta> ultimoNumerado(Long puntoVentaId, TipoComprobante tipo) {
        String condicion = tipo == TipoComprobante.FACTURA_A ? " = " : " <> ";
        return em.createQuery(
                        "SELECT f FROM FacturaVenta f WHERE f.puntoVenta.id = :pv AND f.numero IS NOT NULL " +
                                "AND f.condicionIva.codigoAfip" + condicion + ":ri ORDER BY f.numero DESC", FacturaVenta.class)
                .setParameter("pv", puntoVentaId)
                .setParameter("ri", TipoComprobante.CONDICION_RESPONSABLE_INSCRIPTO)
                .setMaxResults(1)
                .getResultStream()
                .findFirst();
    }

    // Obliga a escribir en la base ahora (para que el reporte posterior vea los cambios)
    public void sincronizar() {
        em.flush();
    }
}
