package com.example.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Renglon de una factura ya guardada (con los importes calculados por el servidor)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaItemDTO {

    private Long listaPrecioArticuloId;
    private Long articuloId;
    private String articuloCodigo;
    private String descripcion;
    private double cantidad;
    private double precioUnitario;
    private double porcentajeBonificacion;
    private double importeNeto;
    private double importeIva;
    private double importeSubtotal;

}
