package com.example.exception;

import com.example.arca.ArcaException;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.http.InvalidParameterException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

// Convierte TODAS las excepciones en respuestas HTTP con el mismo JSON:
// { "timestamp": "...", "status": 404, "error": "Not Found", "mensaje": "..." }
// Ninguna excepcion llega al cliente como un 500 "crudo" de Spring.
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    // ---------------- reglas de negocio ----------------

    @ExceptionHandler(RecursoNoEncontradoException.class)
    public ResponseEntity<Map<String, Object>> noEncontrado(RecursoNoEncontradoException e) {
        return respuesta(HttpStatus.NOT_FOUND, e.getMessage());
    }

    @ExceptionHandler(ReglaNegocioException.class)
    public ResponseEntity<Map<String, Object>> reglaNegocio(ReglaNegocioException e) {
        return respuesta(HttpStatus.CONFLICT, e.getMessage());
    }

    // ARCA no respondio o falta configurar el certificado
    @ExceptionHandler(ArcaException.class)
    public ResponseEntity<Map<String, Object>> errorArca(ArcaException e) {
        return respuesta(HttpStatus.BAD_GATEWAY, e.getMessage());
    }

    // ---------------- datos invalidos (400) ----------------

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> datosInvalidos(IllegalArgumentException e) {
        return respuesta(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> jsonInvalido(HttpMessageNotReadableException e) {
        return respuesta(HttpStatus.BAD_REQUEST,
                "El cuerpo de la petición no es un JSON válido o tiene tipos/fechas incorrectos");
    }

    // ?montoMinimo=abc, ?fechaDesde=31-12-2026 -> los filtros se cargan en FacturaFiltrosDTO
    @ExceptionHandler(BindException.class)
    public ResponseEntity<Map<String, Object>> filtroInvalido(BindException e) {
        String campo = e.getFieldError() == null ? "un parámetro" : e.getFieldError().getField();
        return respuesta(HttpStatus.BAD_REQUEST, "El valor de '" + campo + "' no es válido"
                + " (fechas en formato yyyy-MM-dd, montos y números sin letras)");
    }

    // /api/facturas/99999999999999999999 -> no entra en un Long
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Map<String, Object>> parametroInvalido(MethodArgumentTypeMismatchException e) {
        return respuesta(HttpStatus.BAD_REQUEST, "El valor '" + e.getValue() + "' no es válido para " + e.getName());
    }

    // ?q=%  (caracteres mal codificados en la URL)
    @ExceptionHandler(InvalidParameterException.class)
    public ResponseEntity<Map<String, Object>> urlMalCodificada(InvalidParameterException e) {
        return respuesta(HttpStatus.BAD_REQUEST, "La URL tiene parámetros con caracteres mal codificados");
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<Map<String, Object>> parametroFaltante(MissingServletRequestParameterException e) {
        return respuesta(HttpStatus.BAD_REQUEST, "Falta el parámetro " + e.getParameterName());
    }

    // ---------------- rutas / metodos ----------------

    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<Map<String, Object>> rutaInexistente(NoResourceFoundException e) {
        return respuesta(HttpStatus.NOT_FOUND, "No existe el recurso /" + e.getResourcePath());
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<Map<String, Object>> metodoNoPermitido(HttpRequestMethodNotSupportedException e) {
        return respuesta(HttpStatus.METHOD_NOT_ALLOWED, "El método " + e.getMethod() + " no está permitido en esta URL");
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<Map<String, Object>> tipoNoSoportado(HttpMediaTypeNotSupportedException e) {
        return respuesta(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "El cuerpo tiene que enviarse como application/json");
    }

    // ---------------- base de datos ----------------

    // Otra operacion esta modificando la misma factura en este momento
    @ExceptionHandler(PessimisticLockingFailureException.class)
    public ResponseEntity<Map<String, Object>> bloqueo(PessimisticLockingFailureException e) {
        return respuesta(HttpStatus.CONFLICT, "El comprobante está siendo modificado por otra operación; reintentá en unos segundos");
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, Object>> integridad(DataIntegrityViolationException e) {
        log.warn("Violación de integridad de datos", e);
        return respuesta(HttpStatus.CONFLICT, "La operación viola una restricción de la base de datos "
                + "(un dato obligatorio falta, es demasiado largo o está en uso)");
    }

    // ---------------- cualquier otro error: se registra y se informa sin detalles internos ----------------

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> inesperado(Exception e) {
        log.error("Error inesperado", e);
        return respuesta(HttpStatus.INTERNAL_SERVER_ERROR,
                "Ocurrió un error inesperado en el servidor. La operación no se realizó; revisá los datos e intentá de nuevo.");
    }

    private ResponseEntity<Map<String, Object>> respuesta(HttpStatus status, String mensaje) {
        Map<String, Object> cuerpo = new LinkedHashMap<>();
        cuerpo.put("timestamp", LocalDateTime.now().toString());
        cuerpo.put("status", status.value());
        cuerpo.put("error", status.getReasonPhrase());
        cuerpo.put("mensaje", mensaje);
        return ResponseEntity.status(status).body(cuerpo);
    }
}
