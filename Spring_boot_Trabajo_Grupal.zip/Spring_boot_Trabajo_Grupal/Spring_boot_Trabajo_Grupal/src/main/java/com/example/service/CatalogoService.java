package com.example.service;

import com.example.dto.ArticuloPrecioDTO;
import com.example.dto.CatalogoDTO;
import com.example.dto.ClienteExplorerDTO;
import com.example.dto.ItemCatalogoDTO;
import com.example.entidades.*;
import com.example.exception.RecursoNoEncontradoException;
import com.example.repository.CatalogoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CatalogoService {

    // tope de filas que devuelve un explorer (se afina la busqueda escribiendo)
    public static final int MAXIMO_RESULTADOS = 500;

    private final CatalogoRepository catalogoRepository;

    public CatalogoDTO obtenerCatalogo() {
        List<ItemCatalogoDTO> condicionesIva = catalogoRepository.listarActivos(CondicionIva.class).stream()
                .map(ci -> new ItemCatalogoDTO(ci.getId(), String.valueOf(ci.getCodigoAfip()), ci.getDenominacion()))
                .toList();

        List<ItemCatalogoDTO> puntosVenta = catalogoRepository.listarActivos(PuntoVenta.class).stream()
                .map(pv -> new ItemCatalogoDTO(pv.getId(), String.valueOf(pv.getNumero()),
                        String.format("%04d - %s", pv.getNumero(), pv.getDescripcion())))
                .toList();

        List<ItemCatalogoDTO> tiposMoneda = catalogoRepository.listarActivos(TipoMoneda.class).stream()
                .map(tm -> new ItemCatalogoDTO(tm.getId(), tm.getCodigoAfip(), tm.getSimbolo() + " " + tm.getDenominacion()))
                .toList();

        List<ItemCatalogoDTO> listasPrecio = catalogoRepository.listarActivos(ListaPrecio.class).stream()
                .map(lp -> new ItemCatalogoDTO(lp.getId(), lp.getCodigo(), lp.getCodigo() + " - " + lp.getDenominacion()))
                .toList();

        return new CatalogoDTO(condicionesIva, puntosVenta, tiposMoneda, listasPrecio, FacturaService.ALICUOTA_IVA);
    }

    // Explorer de clientes
    public List<ClienteExplorerDTO> buscarClientes(String texto) {
        return catalogoRepository.buscarClientes(normalizar(texto), MAXIMO_RESULTADOS).stream()
                .map(c -> new ClienteExplorerDTO(
                        c.getId(), c.getCuitCuil(), c.getDenominacion(),
                        c.getDomicilio() == null ? null
                                : (c.getDomicilio().getNombreCalle() + " " + c.getDomicilio().getNumeroCalle()).trim(),
                        c.getContacto() == null ? null : c.getContacto().getEmail(),
                        c.getContacto() == null ? null : c.getContacto().getTelefono(),
                        c.getCondicionIva() == null ? null : c.getCondicionIva().getId(),
                        c.getCondicionIva() == null ? null : c.getCondicionIva().getDenominacion()))
                .toList();
    }

    // Explorer de articulos de una lista de precios (primero se elige la lista, despues el articulo)
    public List<ArticuloPrecioDTO> buscarArticulosDeLista(Long listaPrecioId, String texto) {
        catalogoRepository.buscarPorId(ListaPrecio.class, listaPrecioId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Lista de precios", listaPrecioId));

        return catalogoRepository.buscarArticulosDeLista(listaPrecioId, normalizar(texto), MAXIMO_RESULTADOS).stream()
                .map(lpa -> {
                    Articulo a = lpa.getArticulo();
                    return new ArticuloPrecioDTO(lpa.getId(), a.getId(), a.getCodigo(), a.getDenominacion(),
                            a.getRubro() == null ? null : a.getRubro().getDenominacion(),
                            a.getMarca() == null ? null : a.getMarca().getDenominacion(),
                            lpa.getPrecioVenta());
                })
                .toList();
    }

    private static String normalizar(String texto) {
        return texto == null ? "" : texto.trim().toLowerCase(Locale.ROOT);
    }
}
