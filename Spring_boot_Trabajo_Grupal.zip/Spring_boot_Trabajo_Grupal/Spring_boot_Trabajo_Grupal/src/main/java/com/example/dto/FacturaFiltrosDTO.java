package com.example.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

// Filtros opcionales de los GET (?fechaDesde=...&fechaHasta=...&estado=...&montoMinimo=...).
// Spring arma este objeto a partir de los query params.
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaFiltrosDTO {

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fechaDesde;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fechaHasta;

    private String estado;       // BORRADOR | EMITIDA | ANULADA
    private Double montoMinimo;
    private Double montoMaximo;
    private Long clienteId;      // 0 = solo Consumidor Final
    private Long puntoVentaId;
    private Long numero;         // numero de comprobante exacto

}
