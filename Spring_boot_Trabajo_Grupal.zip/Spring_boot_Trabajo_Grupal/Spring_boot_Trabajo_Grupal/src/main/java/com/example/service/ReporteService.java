package com.example.service;

import com.example.dto.FacturaCompletaDTO;
import com.example.dto.FacturaItemDTO;
import com.example.dto.FacturaReporteDTO;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;


@Service
public class ReporteService {

    private static final String[] ENCABEZADOS = {
            "Comprobante", "Fecha Emisión", "Cliente", "Condición IVA", "Punto Venta", "Importe Total",
            "Cant. Items", "Estado"
    };
    private static final String[] ENCABEZADOS_EXCEL = {
            "Comprobante", "Fecha Emisión", "Cliente", "Condición IVA", "Punto Venta", "Importe Total",
            "Cant. Items", "Estado", "CAE"
    };
    private static final Locale AR = Locale.forLanguageTag("es-AR");

    private static final Font TITULO = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
    private static final Font NEGRITA = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
    private static final Font NORMAL = new Font(Font.FontFamily.HELVETICA, 9);
    private static final Font NUMERO = new Font(Font.FontFamily.HELVETICA, 8);
    private static final Font CABECERA_TABLA = new Font(Font.FontFamily.HELVETICA, 9, Font.BOLD, BaseColor.WHITE);

    // Datos del emisor (application.properties)
    @Value("${app.empresa.razon-social:Mi Empresa S.A.}")
    private String razonSocial;
    @Value("${app.empresa.cuit:30-00000000-0}")
    private String cuitEmpresa;
    @Value("${app.empresa.domicilio:}")
    private String domicilioEmpresa;
    @Value("${app.empresa.condicion-iva:IVA Responsable Inscripto}")
    private String condicionIvaEmpresa;

    // =====================================================================
    // Reporte de ventas (listado filtrado)
    // =====================================================================
    public byte[] generarPdf(List<FacturaReporteDTO> reporte) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        Document documento = new Document(PageSize.A4.rotate());
        try {
            PdfWriter.getInstance(documento, salida);
            documento.open();

            Paragraph titulo = new Paragraph("Reporte Ejecutivo de Ventas", TITULO);
            titulo.setSpacingAfter(4);
            documento.add(titulo);
            Paragraph emitido = new Paragraph(razonSocial + "  ·  Generado el " +
                    new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date()), NORMAL);
            emitido.setSpacingAfter(12);
            documento.add(emitido);

            PdfPTable tabla = new PdfPTable(ENCABEZADOS.length);
            tabla.setWidthPercentage(100);
            tabla.setWidths(new float[]{1.7f, 1.3f, 2.6f, 2.4f, 2.2f, 1.7f, 1.0f, 1.3f});
            tabla.setHeaderRows(1);

            for (String h : ENCABEZADOS) {
                tabla.addCell(celdaCabecera(h));
            }

            double total = 0;
            for (FacturaReporteDTO dto : reporte) {
                tabla.addCell(celda(comprobante(dto), Element.ALIGN_LEFT));
                tabla.addCell(celda(sdf.format(dto.getFechaEmision()), Element.ALIGN_LEFT));
                tabla.addCell(celda(dto.getClienteDenominacion(), Element.ALIGN_LEFT));
                tabla.addCell(celda(dto.getCondicionIva(), Element.ALIGN_LEFT));
                tabla.addCell(celda(dto.getPuntoVentaDescripcion(), Element.ALIGN_LEFT));
                tabla.addCell(celda(moneda(dto.getImporteTotal()), Element.ALIGN_RIGHT));
                tabla.addCell(celda(String.valueOf(dto.getCantidadItems()), Element.ALIGN_RIGHT));
                tabla.addCell(celda(dto.getEstado(), Element.ALIGN_LEFT));
                if (sumaAlTotalFacturado(dto)) {
                    total += dto.getImporteTotal();
                }
            }
            documento.add(tabla);

            Paragraph pie = new Paragraph(
                    String.format(AR, "Comprobantes listados: %d  |  Total facturado (emitidas con CAE): %s",
                            reporte.size(), moneda(total)),
                    NEGRITA);
            pie.setSpacingBefore(15);
            documento.add(pie);

            documento.close();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo generar el PDF", e);
        }
        return salida.toByteArray();
    }

    // =====================================================================
    // Comprobante individual (la factura impresa)
    // =====================================================================
    public byte[] generarComprobantePdf(FacturaCompletaDTO f) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String simbolo = f.getSimboloMoneda() == null ? "$" : f.getSimboloMoneda();

        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        Document documento = new Document(PageSize.A4, 36, 36, 36, 36);
        try {
            PdfWriter writer = PdfWriter.getInstance(documento, salida);

            // Sin CAE el comprobante NO es una factura: no lleva letra ni codigo ARCA y se marca sin validez
            boolean tieneCae = f.getCae() != null && !f.getCae().isBlank();
            boolean anulada = FacturaService.ANULADA.equals(f.getEstado());

            // Marca de agua en cada pagina para los comprobantes sin validez
            String marca = !tieneCae ? "SIN VALIDEZ FISCAL" : anulada ? "ANULADA" : null;
            if (marca != null) {
                BaseColor color = anulada ? BaseColor.RED : BaseColor.GRAY;
                writer.setPageEvent(new PdfPageEventHelper() {
                    @Override
                    public void onEndPage(PdfWriter w, Document d) {
                        marcaDeAgua(w, marca, color);
                    }
                });
            }
            documento.open();

            // ---- Encabezado: emisor | comprobante ----
            PdfPTable encabezado = new PdfPTable(2);
            encabezado.setWidthPercentage(100);
            encabezado.setWidths(new float[]{1.2f, 1f});

            PdfPCell emisor = new PdfPCell();
            emisor.setPadding(8);
            emisor.addElement(new Paragraph(razonSocial, TITULO));
            emisor.addElement(new Paragraph("CUIT: " + cuitEmpresa, NORMAL));
            if (!domicilioEmpresa.isBlank()) {
                emisor.addElement(new Paragraph(domicilioEmpresa, NORMAL));
            }
            emisor.addElement(new Paragraph(condicionIvaEmpresa, NORMAL));
            encabezado.addCell(emisor);

            PdfPCell comprobante = new PdfPCell();
            comprobante.setPadding(8);
            if (tieneCae) {
                comprobante.addElement(new Paragraph("FACTURA " + f.getLetra(), TITULO));
                comprobante.addElement(new Paragraph(String.format("Código ARCA %02d", f.getCodigoComprobante()), NORMAL));
                comprobante.addElement(new Paragraph("Nº " + numeroComprobante(f.getPuntoVentaNumero(), f.getNumeroFactura()), NEGRITA));
            } else {
                comprobante.addElement(new Paragraph(f.getNumeroFactura() == null ? "BORRADOR" : "COMPROBANTE SIN CAE", TITULO));
                comprobante.addElement(new Paragraph("Documento no válido como factura", NEGRITA));
                if (f.getNumeroFactura() != null) {
                    comprobante.addElement(new Paragraph("Nº interno " + numeroComprobante(f.getPuntoVentaNumero(), f.getNumeroFactura()), NORMAL));
                }
            }
            comprobante.addElement(new Paragraph("Fecha de emisión: " + sdf.format(f.getFechaEmision()), NORMAL));
            comprobante.addElement(new Paragraph("Punto de venta: " + f.getPuntoVentaDescripcion(), NORMAL));
            comprobante.addElement(new Paragraph("Estado: " + f.getEstado(), NORMAL));
            encabezado.addCell(comprobante);
            documento.add(encabezado);

            // ---- Receptor ----
            PdfPTable receptor = new PdfPTable(1);
            receptor.setWidthPercentage(100);
            receptor.setSpacingBefore(8);
            PdfPCell datosReceptor = new PdfPCell();
            datosReceptor.setPadding(8);
            datosReceptor.addElement(new Paragraph("Cliente: " + f.getClienteDenominacion(), NEGRITA));
            if (f.getClienteCuitCuil() != null) {
                datosReceptor.addElement(new Paragraph("CUIT/CUIL: " + f.getClienteCuitCuil(), NORMAL));
            }
            if (f.getClienteDomicilio() != null && !f.getClienteDomicilio().isBlank()) {
                datosReceptor.addElement(new Paragraph("Domicilio: " + f.getClienteDomicilio(), NORMAL));
            }
            datosReceptor.addElement(new Paragraph("Condición frente al IVA: " + f.getCondicionIva()
                    + "   ·   Moneda: " + f.getTipoMoneda()
                    + (f.getListaPrecio() == null ? "" : "   ·   Lista de precios: " + f.getListaPrecio()), NORMAL));
            receptor.addCell(datosReceptor);
            documento.add(receptor);

            // ---- Items ----
            String[] columnas = {"Código", "Descripción", "Cant.", "Precio unit.", "Bonif. %", "Neto", "IVA", "Subtotal"};
            PdfPTable items = new PdfPTable(columnas.length);
            items.setWidthPercentage(100);
            items.setSpacingBefore(12);
            items.setWidths(new float[]{1.0f, 1.95f, 0.9f, 1.2f, 0.85f, 1.8f, 1.6f, 1.9f});
            items.setHeaderRows(1);
            for (String c : columnas) {
                items.addCell(celdaCabecera(c));
            }
            for (FacturaItemDTO d : f.getDetalles()) {
                PdfPCell codigo = numero(d.getArticuloCodigo());
                codigo.setHorizontalAlignment(Element.ALIGN_LEFT);
                items.addCell(codigo);
                items.addCell(celda(d.getDescripcion(), Element.ALIGN_LEFT));
                items.addCell(numero(String.format(AR, "%,.2f", d.getCantidad())));
                items.addCell(numero(moneda(simbolo, d.getPrecioUnitario())));
                items.addCell(numero(String.format(AR, "%,.2f", d.getPorcentajeBonificacion())));
                items.addCell(numero(moneda(simbolo, d.getImporteNeto())));
                items.addCell(numero(moneda(simbolo, d.getImporteIva())));
                items.addCell(numero(moneda(simbolo, d.getImporteSubtotal())));
            }
            documento.add(items);

            // ---- Totales ----
            PdfPTable totales = new PdfPTable(2);
            totales.setWidthPercentage(50);
            totales.setWidths(new float[]{1f, 1.5f});
            totales.setHorizontalAlignment(Element.ALIGN_RIGHT);
            totales.setSpacingBefore(10);
            filaTotal(totales, "Importe neto", moneda(simbolo, f.getImporteNeto()), NORMAL);
            filaTotal(totales, String.format(AR, "IVA %.0f %%", FacturaService.ALICUOTA_IVA),
                    moneda(simbolo, f.getImporteIva()), NORMAL);
            filaTotal(totales, "TOTAL", moneda(simbolo, f.getImporteTotal()), new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
            documento.add(totales);

            if (f.getObservaciones() != null) {
                Paragraph obs = new Paragraph("Observaciones: " + f.getObservaciones(), NORMAL);
                obs.setSpacingBefore(10);
                documento.add(obs);
            }

            // ---- Pie: CAE ----
            String textoCae;
            if (f.getCae() != null) {
                textoCae = "CAE: " + f.getCae() + (f.getCaeFechaVencimiento() == null ? ""
                        : "     Vencimiento del CAE: " + sdf.format(f.getCaeFechaVencimiento()));
            } else if (f.getNumeroFactura() == null) {
                textoCae = "Borrador no autorizado por ARCA: no tiene número ni CAE y no es válido como factura. "
                        + "Al autorizarse se emitirá como Factura " + f.getLetra() + ".";
                if (f.getMotivoRechazo() != null) {
                    textoCae += " Último intento: " + f.getMotivoRechazo();
                }
            } else {
                textoCae = "Comprobante sin CAE: no fue autorizado por ARCA y no es válido como factura.";
            }
            Paragraph cae = new Paragraph(textoCae, NEGRITA);
            cae.setSpacingBefore(18);
            documento.add(cae);
            if (f.getFechaAnulacion() != null) {
                documento.add(new Paragraph("Comprobante anulado el " + sdf.format(f.getFechaAnulacion()), NORMAL));
            }

            documento.close();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo generar el PDF del comprobante", e);
        }
        return salida.toByteArray();
    }

    // =====================================================================
    // Excel (.xlsx): importes como numeros y fechas como fechas, para poder sumar y filtrar en Excel
    // =====================================================================
    public byte[] generarExcel(List<FacturaReporteDTO> reporte) {
        try (XSSFWorkbook libro = new XSSFWorkbook(); ByteArrayOutputStream salida = new ByteArrayOutputStream()) {
            Sheet hoja = libro.createSheet("Comprobantes");
            CreationHelper ayuda = libro.getCreationHelper();

            org.apache.poi.ss.usermodel.Font negrita = libro.createFont();
            negrita.setBold(true);
            CellStyle estiloEncabezado = libro.createCellStyle();
            estiloEncabezado.setFont(negrita);
            estiloEncabezado.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            estiloEncabezado.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            CellStyle estiloFecha = libro.createCellStyle();
            estiloFecha.setDataFormat(ayuda.createDataFormat().getFormat("dd/mm/yyyy"));
            CellStyle estiloImporte = libro.createCellStyle();
            estiloImporte.setDataFormat(ayuda.createDataFormat().getFormat("\"$\" #,##0.00"));
            CellStyle estiloTotal = libro.createCellStyle();
            estiloTotal.cloneStyleFrom(estiloImporte);
            estiloTotal.setFont(negrita);

            Row encabezado = hoja.createRow(0);
            for (int i = 0; i < ENCABEZADOS_EXCEL.length; i++) {
                Cell celda = encabezado.createCell(i);
                celda.setCellValue(ENCABEZADOS_EXCEL[i]);
                celda.setCellStyle(estiloEncabezado);
            }

            int fila = 1;
            double total = 0;
            for (FacturaReporteDTO dto : reporte) {
                Row r = hoja.createRow(fila++);
                r.createCell(0).setCellValue(comprobante(dto));
                Cell fecha = r.createCell(1);
                fecha.setCellValue(dto.getFechaEmision());
                fecha.setCellStyle(estiloFecha);
                r.createCell(2).setCellValue(dto.getClienteDenominacion());
                r.createCell(3).setCellValue(dto.getCondicionIva());
                r.createCell(4).setCellValue(dto.getPuntoVentaDescripcion());
                Cell importe = r.createCell(5);
                importe.setCellValue(dto.getImporteTotal());
                importe.setCellStyle(estiloImporte);
                r.createCell(6).setCellValue(dto.getCantidadItems());
                r.createCell(7).setCellValue(dto.getEstado());
                r.createCell(8).setCellValue(esFacturaValida(dto) ? dto.getCae() : "");
                if (sumaAlTotalFacturado(dto)) {
                    total += dto.getImporteTotal();
                }
            }

            Row pie = hoja.createRow(fila + 1);
            pie.createCell(4).setCellValue("Total facturado (emitidas con CAE)");
            pie.getCell(4).setCellStyle(estiloEncabezado);
            Cell celdaTotal = pie.createCell(5);
            celdaTotal.setCellValue(total);
            celdaTotal.setCellStyle(estiloTotal);

            hoja.setAutoFilter(new CellRangeAddress(0, Math.max(0, fila - 1), 0, ENCABEZADOS_EXCEL.length - 1));
            hoja.createFreezePane(0, 1);
            for (int i = 0; i < ENCABEZADOS_EXCEL.length; i++) {
                hoja.autoSizeColumn(i);
            }
            libro.write(salida);
            return salida.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo generar el Excel", e);
        }
    }

    // =====================================================================
    // Auxiliares
    // =====================================================================

    // Total facturado: solo facturas autorizadas por ARCA y vigentes (las anuladas y los borradores no suman)
    static boolean sumaAlTotalFacturado(FacturaReporteDTO dto) {
        return esFacturaValida(dto) && "EMITIDA".equals(dto.getEstado());
    }

    // Solo es una factura valida si ARCA la autorizo (tiene CAE)
    public static boolean esFacturaValida(FacturaReporteDTO dto) {
        return dto.getCae() != null && !dto.getCae().isBlank();
    }

    // "A 0001-00001009" si tiene CAE; "Borrador" o "Sin CAE (0001-...)" si no es una factura valida
    public static String comprobante(FacturaReporteDTO dto) {
        if (esFacturaValida(dto)) {
            return dto.getLetra() + " " + numeroComprobante(dto.getPuntoVentaNumero(), dto.getNumeroFactura());
        }
        return dto.getNumeroFactura() == null ? "Borrador"
                : "Sin CAE (" + numeroComprobante(dto.getPuntoVentaNumero(), dto.getNumeroFactura()) + ")";
    }

    // 0001-00001009 (formato de ARCA); los borradores todavia no tienen numero
    public static String numeroComprobante(int puntoVenta, Long numero) {
        return numero == null ? "Borrador (sin número)" : String.format("%04d-%08d", puntoVenta, numero);
    }

    private static String moneda(double importe) {
        return moneda("$", importe);
    }

    private static String moneda(String simbolo, double importe) {
        return String.format(AR, "%s %,.2f", simbolo, importe);
    }

    private static PdfPCell celdaCabecera(String texto) {
        PdfPCell c = new PdfPCell(new Phrase(texto, CABECERA_TABLA));
        c.setBackgroundColor(BaseColor.DARK_GRAY);
        c.setPadding(5);
        return c;
    }

    // Importes: letra un poco mas chica y sin cortar la linea
    private static PdfPCell numero(String texto) {
        PdfPCell c = new PdfPCell(new Phrase(texto, NUMERO));
        c.setHorizontalAlignment(Element.ALIGN_RIGHT);
        c.setNoWrap(true);
        c.setPadding(4);
        return c;
    }

    private static PdfPCell celda(String texto, int alineacion) {
        PdfPCell c = new PdfPCell(new Phrase(texto == null ? "" : texto, NORMAL));
        c.setHorizontalAlignment(alineacion);
        c.setPadding(4);
        return c;
    }

    private static void filaTotal(PdfPTable tabla, String etiqueta, String valor, Font fuente) {
        PdfPCell e = new PdfPCell(new Phrase(etiqueta, fuente));
        e.setBorder(Rectangle.NO_BORDER);
        e.setPadding(3);
        PdfPCell v = new PdfPCell(new Phrase(valor, fuente));
        v.setBorder(Rectangle.NO_BORDER);
        v.setHorizontalAlignment(Element.ALIGN_RIGHT);
        v.setPadding(3);
        tabla.addCell(e);
        tabla.addCell(v);
    }

    private static void marcaDeAgua(PdfWriter writer, String texto, BaseColor color) {
        PdfContentByte lienzo = writer.getDirectContentUnder();
        PdfGState transparencia = new PdfGState();
        transparencia.setFillOpacity(0.18f);
        lienzo.saveState();
        lienzo.setGState(transparencia);
        Font fuente = new Font(Font.FontFamily.HELVETICA, texto.length() > 12 ? 34 : 64, Font.BOLD, color);
        Rectangle pagina = writer.getPageSize();
        ColumnText.showTextAligned(lienzo, Element.ALIGN_CENTER, new Phrase(texto, fuente),
                pagina.getWidth() / 2, pagina.getHeight() / 2, 45);
        lienzo.restoreState();
    }
}
