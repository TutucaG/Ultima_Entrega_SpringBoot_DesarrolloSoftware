package com.example.service;

import com.example.dto.FacturaCompletaDTO;
import com.example.dto.FacturaItemDTO;
import com.example.dto.FacturaReporteDTO;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;


@Service
public class ReporteService {

    private static final String[] ENCABEZADOS = {
            "Comprobante", "Fecha Emisión", "Cliente", "Condición IVA", "Punto Venta", "Importe Total",
            "Cant. Items", "Estado"
    };
    private static final Locale AR = Locale.forLanguageTag("es-AR");

    private static final Font TITULO = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
    private static final Font NEGRITA = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
    private static final Font NORMAL = new Font(Font.FontFamily.HELVETICA, 9);
    private static final Font CABECERA_TABLA = new Font(Font.FontFamily.HELVETICA, 9, Font.BOLD, BaseColor.WHITE);

    // Datos del emisor (application.properties)
    @Value("${app.empresa.razon-social:Mi Empresa S.A.}")
    private String razonSocial;
    @Value("${app.empresa.cuit:30-00000000-0}")
    private String cuitEmpresa;
    @Value("${app.empresa.domicilio:}")
    private String domicilioEmpresa;
    @Value("${app.empresa.condicion-iva:IVA Responsable Inscripto}")
    private String condicionIvaEmpresa;

    // =====================================================================
    // Reporte de ventas (listado filtrado)
    // =====================================================================
    public byte[] generarPdf(List<FacturaReporteDTO> reporte) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        Document documento = new Document(PageSize.A4.rotate());
        try {
            PdfWriter.getInstance(documento, salida);
            documento.open();

            Paragraph titulo = new Paragraph("Reporte Ejecutivo de Ventas", TITULO);
            titulo.setSpacingAfter(4);
            documento.add(titulo);
            Paragraph emitido = new Paragraph(razonSocial + "  ·  Generado el " +
                    new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date()), NORMAL);
            emitido.setSpacingAfter(12);
            documento.add(emitido);

            PdfPTable tabla = new PdfPTable(ENCABEZADOS.length);
            tabla.setWidthPercentage(100);
            tabla.setWidths(new float[]{1.7f, 1.3f, 2.6f, 2.4f, 2.2f, 1.7f, 1.0f, 1.3f});
            tabla.setHeaderRows(1);

            for (String h : ENCABEZADOS) {
                tabla.addCell(celdaCabecera(h));
            }

            double total = 0;
            for (FacturaReporteDTO dto : reporte) {
                tabla.addCell(celda(dto.getLetra() + " " + numeroComprobante(dto.getPuntoVentaNumero(), dto.getNumeroFactura()), Element.ALIGN_LEFT));
                tabla.addCell(celda(sdf.format(dto.getFechaEmision()), Element.ALIGN_LEFT));
                tabla.addCell(celda(dto.getClienteDenominacion(), Element.ALIGN_LEFT));
                tabla.addCell(celda(dto.getCondicionIva(), Element.ALIGN_LEFT));
                tabla.addCell(celda(dto.getPuntoVentaDescripcion(), Element.ALIGN_LEFT));
                tabla.addCell(celda(moneda(dto.getImporteTotal()), Element.ALIGN_RIGHT));
                tabla.addCell(celda(String.valueOf(dto.getCantidadItems()), Element.ALIGN_RIGHT));
                tabla.addCell(celda(dto.getEstado(), Element.ALIGN_LEFT));
                if (FacturaService.EMITIDA.equals(dto.getEstado())) {
                    total += dto.getImporteTotal();
                }
            }
            documento.add(tabla);

            Paragraph pie = new Paragraph(
                    String.format(AR, "Comprobantes listados: %d  |  Total facturado (solo emitidas): %s",
                            reporte.size(), moneda(total)),
                    NEGRITA);
            pie.setSpacingBefore(15);
            documento.add(pie);

            documento.close();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo generar el PDF", e);
        }
        return salida.toByteArray();
    }

    // =====================================================================
    // Comprobante individual (la factura impresa)
    // =====================================================================
    public byte[] generarComprobantePdf(FacturaCompletaDTO f) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String simbolo = f.getSimboloMoneda() == null ? "$" : f.getSimboloMoneda();

        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        Document documento = new Document(PageSize.A4, 36, 36, 36, 36);
        try {
            PdfWriter writer = PdfWriter.getInstance(documento, salida);

            // Marca de agua en cada pagina para los comprobantes sin validez
            String marca = FacturaService.BORRADOR.equals(f.getEstado()) ? "BORRADOR - SIN VALIDEZ FISCAL"
                    : FacturaService.ANULADA.equals(f.getEstado()) ? "ANULADA" : null;
            if (marca != null) {
                BaseColor color = FacturaService.ANULADA.equals(f.getEstado()) ? BaseColor.RED : BaseColor.GRAY;
                writer.setPageEvent(new PdfPageEventHelper() {
                    @Override
                    public void onEndPage(PdfWriter w, Document d) {
                        marcaDeAgua(w, marca, color);
                    }
                });
            }
            documento.open();

            // ---- Encabezado: emisor | comprobante ----
            PdfPTable encabezado = new PdfPTable(2);
            encabezado.setWidthPercentage(100);
            encabezado.setWidths(new float[]{1.2f, 1f});

            PdfPCell emisor = new PdfPCell();
            emisor.setPadding(8);
            emisor.addElement(new Paragraph(razonSocial, TITULO));
            emisor.addElement(new Paragraph("CUIT: " + cuitEmpresa, NORMAL));
            if (!domicilioEmpresa.isBlank()) {
                emisor.addElement(new Paragraph(domicilioEmpresa, NORMAL));
            }
            emisor.addElement(new Paragraph(condicionIvaEmpresa, NORMAL));
            encabezado.addCell(emisor);

            PdfPCell comprobante = new PdfPCell();
            comprobante.setPadding(8);
            comprobante.addElement(new Paragraph("FACTURA " + f.getLetra(), TITULO));
            comprobante.addElement(new Paragraph(String.format("Código ARCA %02d", f.getCodigoComprobante()), NORMAL));
            comprobante.addElement(new Paragraph("Nº " + numeroComprobante(f.getPuntoVentaNumero(), f.getNumeroFactura()), NEGRITA));
            comprobante.addElement(new Paragraph("Fecha de emisión: " + sdf.format(f.getFechaEmision()), NORMAL));
            comprobante.addElement(new Paragraph("Punto de venta: " + f.getPuntoVentaDescripcion(), NORMAL));
            comprobante.addElement(new Paragraph("Estado: " + f.getEstado(), NORMAL));
            encabezado.addCell(comprobante);
            documento.add(encabezado);

            // ---- Receptor ----
            PdfPTable receptor = new PdfPTable(1);
            receptor.setWidthPercentage(100);
            receptor.setSpacingBefore(8);
            PdfPCell datosReceptor = new PdfPCell();
            datosReceptor.setPadding(8);
            datosReceptor.addElement(new Paragraph("Cliente: " + f.getClienteDenominacion(), NEGRITA));
            if (f.getClienteCuitCuil() != null) {
                datosReceptor.addElement(new Paragraph("CUIT/CUIL: " + f.getClienteCuitCuil(), NORMAL));
            }
            if (f.getClienteDomicilio() != null && !f.getClienteDomicilio().isBlank()) {
                datosReceptor.addElement(new Paragraph("Domicilio: " + f.getClienteDomicilio(), NORMAL));
            }
            datosReceptor.addElement(new Paragraph("Condición frente al IVA: " + f.getCondicionIva()
                    + "   ·   Moneda: " + f.getTipoMoneda()
                    + (f.getListaPrecio() == null ? "" : "   ·   Lista de precios: " + f.getListaPrecio()), NORMAL));
            receptor.addCell(datosReceptor);
            documento.add(receptor);

            // ---- Items ----
            String[] columnas = {"Código", "Descripción", "Cant.", "Precio unit.", "Bonif. %", "Neto", "IVA", "Subtotal"};
            PdfPTable items = new PdfPTable(columnas.length);
            items.setWidthPercentage(100);
            items.setSpacingBefore(12);
            items.setWidths(new float[]{1.1f, 3.2f, 0.8f, 1.3f, 0.9f, 1.3f, 1.1f, 1.4f});
            items.setHeaderRows(1);
            for (String c : columnas) {
                items.addCell(celdaCabecera(c));
            }
            for (FacturaItemDTO d : f.getDetalles()) {
                items.addCell(celda(d.getArticuloCodigo(), Element.ALIGN_LEFT));
                items.addCell(celda(d.getDescripcion(), Element.ALIGN_LEFT));
                items.addCell(celda(String.format(AR, "%,.2f", d.getCantidad()), Element.ALIGN_RIGHT));
                items.addCell(celda(moneda(simbolo, d.getPrecioUnitario()), Element.ALIGN_RIGHT));
                items.addCell(celda(String.format(AR, "%,.2f", d.getPorcentajeBonificacion()), Element.ALIGN_RIGHT));
                items.addCell(celda(moneda(simbolo, d.getImporteNeto()), Element.ALIGN_RIGHT));
                items.addCell(celda(moneda(simbolo, d.getImporteIva()), Element.ALIGN_RIGHT));
                items.addCell(celda(moneda(simbolo, d.getImporteSubtotal()), Element.ALIGN_RIGHT));
            }
            documento.add(items);

            // ---- Totales ----
            PdfPTable totales = new PdfPTable(2);
            totales.setWidthPercentage(40);
            totales.setHorizontalAlignment(Element.ALIGN_RIGHT);
            totales.setSpacingBefore(10);
            filaTotal(totales, "Importe neto", moneda(simbolo, f.getImporteNeto()), NORMAL);
            filaTotal(totales, String.format(AR, "IVA %.0f %%", FacturaService.ALICUOTA_IVA),
                    moneda(simbolo, f.getImporteIva()), NORMAL);
            filaTotal(totales, "TOTAL", moneda(simbolo, f.getImporteTotal()), new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
            documento.add(totales);

            if (f.getObservaciones() != null) {
                Paragraph obs = new Paragraph("Observaciones: " + f.getObservaciones(), NORMAL);
                obs.setSpacingBefore(10);
                documento.add(obs);
            }

            // ---- Pie: CAE ----
            String textoCae;
            if (f.getCae() != null) {
                textoCae = "CAE: " + f.getCae() + (f.getCaeFechaVencimiento() == null ? ""
                        : "     Vencimiento del CAE: " + sdf.format(f.getCaeFechaVencimiento()));
            } else if (f.getNumeroFactura() == null) {
                textoCae = "Comprobante no autorizado por ARCA (borrador sin número ni CAE).";
                if (f.getMotivoRechazo() != null) {
                    textoCae += " Último intento: " + f.getMotivoRechazo();
                }
            } else {
                textoCae = "Comprobante sin CAE registrado.";
            }
            Paragraph cae = new Paragraph(textoCae, NEGRITA);
            cae.setSpacingBefore(18);
            documento.add(cae);
            if (f.getFechaAnulacion() != null) {
                documento.add(new Paragraph("Comprobante anulado el " + sdf.format(f.getFechaAnulacion()), NORMAL));
            }

            documento.close();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo generar el PDF del comprobante", e);
        }
        return salida.toByteArray();
    }

    // =====================================================================
    // "Excel" (texto separado por tabulaciones)
    // =====================================================================
    public byte[] generarExcelTxt(List<FacturaReporteDTO> reporte) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        StringBuilder sb = new StringBuilder("﻿");
        sb.append(String.join("\t", ENCABEZADOS)).append("\r\n");

        for (FacturaReporteDTO dto : reporte) {
            sb.append(String.join("\t",
                            dto.getLetra() + " " + numeroComprobante(dto.getPuntoVentaNumero(), dto.getNumeroFactura()),
                            sdf.format(dto.getFechaEmision()),
                            dto.getClienteDenominacion(),
                            dto.getCondicionIva(),
                            dto.getPuntoVentaDescripcion(),
                            String.format(AR, "%.2f", dto.getImporteTotal()),
                            String.valueOf(dto.getCantidadItems()),
                            dto.getEstado()))
                    .append("\r\n");
        }
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    // =====================================================================
    // Auxiliares
    // =====================================================================

    // 0001-00001009 (formato de ARCA); los borradores todavia no tienen numero
    public static String numeroComprobante(int puntoVenta, Long numero) {
        return numero == null ? "Borrador (sin número)" : String.format("%04d-%08d", puntoVenta, numero);
    }

    private static String moneda(double importe) {
        return moneda("$", importe);
    }

    private static String moneda(String simbolo, double importe) {
        return String.format(AR, "%s %,.2f", simbolo, importe);
    }

    private static PdfPCell celdaCabecera(String texto) {
        PdfPCell c = new PdfPCell(new Phrase(texto, CABECERA_TABLA));
        c.setBackgroundColor(BaseColor.DARK_GRAY);
        c.setPadding(5);
        return c;
    }

    private static PdfPCell celda(String texto, int alineacion) {
        PdfPCell c = new PdfPCell(new Phrase(texto == null ? "" : texto, NORMAL));
        c.setHorizontalAlignment(alineacion);
        c.setPadding(4);
        return c;
    }

    private static void filaTotal(PdfPTable tabla, String etiqueta, String valor, Font fuente) {
        PdfPCell e = new PdfPCell(new Phrase(etiqueta, fuente));
        e.setBorder(Rectangle.NO_BORDER);
        e.setPadding(3);
        PdfPCell v = new PdfPCell(new Phrase(valor, fuente));
        v.setBorder(Rectangle.NO_BORDER);
        v.setHorizontalAlignment(Element.ALIGN_RIGHT);
        v.setPadding(3);
        tabla.addCell(e);
        tabla.addCell(v);
    }

    private static void marcaDeAgua(PdfWriter writer, String texto, BaseColor color) {
        PdfContentByte lienzo = writer.getDirectContentUnder();
        PdfGState transparencia = new PdfGState();
        transparencia.setFillOpacity(0.18f);
        lienzo.saveState();
        lienzo.setGState(transparencia);
        Font fuente = new Font(Font.FontFamily.HELVETICA, texto.length() > 12 ? 34 : 64, Font.BOLD, color);
        Rectangle pagina = writer.getPageSize();
        ColumnText.showTextAligned(lienzo, Element.ALIGN_CENTER, new Phrase(texto, fuente),
                pagina.getWidth() / 2, pagina.getHeight() / 2, 45);
        lienzo.restoreState();
    }
}
