package com.example.service;

import com.example.arca.*;
import com.example.dto.ArcaEstadoDTO;
import com.example.entidades.FacturaVenta;
import com.example.entidades.FacturaVentaDetalle;
import com.example.exception.ReglaNegocioException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.function.LongSupplier;

// Autorizacion de comprobantes en ARCA (ex AFIP).
//
//  modo simulado     -> aplica las mismas validaciones basicas que ARCA y genera un CAE de prueba.
//  modo homologacion -> flujo real de la guia: WSAA (Token y Sign) -> FECompUltimoAutorizado
//                       (numero siguiente) -> FECAESolicitar (CAE y vencimiento).
@Service
@RequiredArgsConstructor
public class ArcaService {

    public static final int DIAS_VIGENCIA_CAE_SIMULADO = 10;
    // ARCA acepta para "productos" una fecha de hasta 5 dias antes o despues de hoy
    public static final int DIAS_TOLERANCIA_FECHA = 5;

    private final ArcaConfig config;
    private final WsaaClient wsaaClient;
    private final WsfeClient wsfeClient;
    private final SecureRandom random = new SecureRandom();

    public record Autorizacion(long numero, String cae, Date fechaVencimiento) {
    }

    // siguienteNumeroLocal: proximo numero segun la base (solo se usa en modo simulado;
    // en homologacion el numero lo informa ARCA con FECompUltimoAutorizado)
    public Autorizacion autorizar(FacturaVenta factura, LongSupplier siguienteNumeroLocal) {
        validar(factura);
        TipoComprobante tipo = TipoComprobante.para(factura.getCondicionIva());

        if (!config.esModoReal()) {
            return new Autorizacion(siguienteNumeroLocal.getAsLong(), caeSimulado(),
                    java.sql.Date.valueOf(aLocalDate(factura.getFechaEmision()).plusDays(DIAS_VIGENCIA_CAE_SIMULADO)));
        }

        WsaaClient.TicketAcceso ticket = wsaaClient.obtenerTicket();
        int puntoVenta = factura.getPuntoVenta().getNumero();
        long numero = wsfeClient.ultimoAutorizado(ticket, puntoVenta, tipo.getCodigoArca()) + 1;

        WsfeClient.RespuestaCae respuesta = wsfeClient.solicitarCae(ticket, armarSolicitud(factura, tipo, numero));
        if (!respuesta.aprobada()) {
            throw rechazo(respuesta.mensajes().isEmpty()
                    ? "resultado " + respuesta.resultado()
                    : String.join(" | ", respuesta.mensajes()));
        }
        LocalDate vencimiento = respuesta.vencimientoCae() != null
                ? respuesta.vencimientoCae()
                : aLocalDate(factura.getFechaEmision()).plusDays(DIAS_VIGENCIA_CAE_SIMULADO);
        return new Autorizacion(respuesta.numero() > 0 ? respuesta.numero() : numero, respuesta.cae(),
                java.sql.Date.valueOf(vencimiento));
    }

    public ArcaEstadoDTO estado() {
        if (!config.esModoReal()) {
            return new ArcaEstadoDTO(ArcaConfig.MODO_SIMULADO, null, null, null,
                    "Modo simulado: los CAE se generan localmente, sin conectarse a ARCA.");
        }
        try {
            WsfeClient.EstadoServidores e = wsfeClient.consultarEstado();
            return new ArcaEstadoDTO(ArcaConfig.MODO_HOMOLOGACION, config.getCuit(), config.getWsfeUrl(), e.todosOk(),
                    String.format("AppServer %s · DbServer %s · AuthServer %s", e.appServer(), e.dbServer(), e.authServer()));
        } catch (ArcaException ex) {
            return new ArcaEstadoDTO(ArcaConfig.MODO_HOMOLOGACION, config.getCuit(), config.getWsfeUrl(), false,
                    ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ auxiliares

    // Validaciones previas (las mismas que haria ARCA) para avisar antes de enviar
    private void validar(FacturaVenta factura) {
        if (factura.getDetalles() == null || factura.getDetalles().isEmpty()) {
            throw rechazo("el comprobante no tiene ítems");
        }
        if (factura.getImporteTotal() <= 0) {
            throw rechazo("el importe total debe ser mayor a 0");
        }
        if (TipoComprobante.para(factura.getCondicionIva()) == TipoComprobante.FACTURA_A && cuit(factura) == 0) {
            throw rechazo("una Factura A requiere un receptor Responsable Inscripto identificado con CUIT (elegir un cliente)");
        }
        long dias = Math.abs(ChronoUnit.DAYS.between(LocalDate.now(), aLocalDate(factura.getFechaEmision())));
        if (dias > DIAS_TOLERANCIA_FECHA) {
            throw rechazo("la fecha de emisión debe estar dentro de los " + DIAS_TOLERANCIA_FECHA
                    + " días anteriores o posteriores a hoy (editá la fecha del borrador)");
        }
    }

    private WsfeClient.SolicitudCae armarSolicitud(FacturaVenta f, TipoComprobante tipo, long numero) {
        double neto = redondear(f.getDetalles().stream().mapToDouble(FacturaVentaDetalle::getImporteNeto).sum());
        double iva = redondear(f.getDetalles().stream().mapToDouble(FacturaVentaDetalle::getImporteIva).sum());
        long cuit = cuit(f);
        return new WsfeClient.SolicitudCae(
                f.getPuntoVenta().getNumero(), tipo.getCodigoArca(), numero, aLocalDate(f.getFechaEmision()),
                cuit == 0 ? WsfeClient.DOC_SIN_IDENTIFICAR : WsfeClient.DOC_CUIT, cuit,
                f.getCondicionIva().getCodigoAfip(), neto, iva, f.getTipoMoneda().getCodigoAfip());
    }

    // CUIT del cliente solo con digitos (0 si es Consumidor Final o no es un CUIT valido)
    private static long cuit(FacturaVenta f) {
        if (f.getCliente() == null || f.getCliente().getCuitCuil() == null) {
            return 0;
        }
        String digitos = f.getCliente().getCuitCuil().replaceAll("\\D", "");
        return digitos.length() == 11 ? Long.parseLong(digitos) : 0;
    }

    private String caeSimulado() {
        StringBuilder cae = new StringBuilder("7"); // los CAE reales tienen 14 digitos
        for (int i = 0; i < 13; i++) {
            cae.append(random.nextInt(10));
        }
        return cae.toString();
    }

    private static ReglaNegocioException rechazo(String motivo) {
        return new ReglaNegocioException("ARCA rechazó el comprobante: " + motivo);
    }

    // Hibernate devuelve java.sql.Date para columnas DATE (y su toInstant() no esta soportado)
    private static LocalDate aLocalDate(Date fecha) {
        if (fecha instanceof java.sql.Date fechaSql) {
            return fechaSql.toLocalDate();
        }
        return fecha.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
