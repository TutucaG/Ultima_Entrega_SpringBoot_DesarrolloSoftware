package com.example.controller;

import com.example.dto.FacturaCompletaDTO;
import com.example.dto.FacturaFiltrosDTO;
import com.example.dto.FacturaReporteDTO;
import com.example.dto.FacturaRequestDTO;
import com.example.service.FacturaService;
import com.example.service.ReporteService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/facturas")
@RequiredArgsConstructor
public class FacturaRestController {

    private final FacturaService facturaService;
    private final ReporteService reporteService;

    // =================== Lectura ===================

    // GET /api/facturas?fechaDesde=&fechaHasta=&estado=&montoMinimo=&montoMaximo=&clienteId=&puntoVentaId=&numero=  -> JSON
    // Los query params se cargan en FacturaFiltrosDTO (todos opcionales)
    @GetMapping
    public List<FacturaReporteDTO> obtenerFacturasFiltradas(FacturaFiltrosDTO filtros) {
        return facturaService.buscarFacturasFiltradas(filtros);
    }

    // GET /api/facturas/{id}  -> 200 OK con cabecera + items, o 404 Not Found
    @GetMapping("/{id:\\d+}")
    public FacturaCompletaDTO obtenerFactura(@PathVariable Long id) {
        return facturaService.buscarPorId(id);
    }

    // GET /api/facturas/{id}/pdf  -> la factura impresa (comprobante individual)
    @GetMapping("/{id:\\d+}/pdf")
    public ResponseEntity<byte[]> imprimirFactura(@PathVariable Long id) {
        FacturaCompletaDTO factura = facturaService.buscarPorId(id);
        byte[] pdf = reporteService.generarComprobantePdf(factura);

        String nombre = factura.getNumeroFactura() == null
                ? "factura_borrador_" + id + ".pdf"
                : String.format("factura_%s_%04d-%08d.pdf", factura.getLetra(),
                factura.getPuntoVentaNumero(), factura.getNumeroFactura());
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=" + nombre)
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }

    // GET /api/facturas/pdf  -> archivo PDF
    @GetMapping("/pdf")
    public ResponseEntity<byte[]> descargarPdf(FacturaFiltrosDTO filtros) {
        byte[] pdf = reporteService.generarPdf(facturaService.buscarFacturasFiltradas(filtros));

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=reporte_ventas.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }

    // GET /api/facturas/excel  -> archivo de texto separado por tabulaciones
    @GetMapping("/excel")
    public ResponseEntity<byte[]> descargarExcel(FacturaFiltrosDTO filtros) {
        byte[] datos = reporteService.generarExcelTxt(facturaService.buscarFacturasFiltradas(filtros));

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte_ventas.txt")
                .contentType(MediaType.parseMediaType("text/tab-separated-values;charset=UTF-8"))
                .body(datos);
    }

    // =================== Escritura ===================

    // POST /api/facturas  -> 201 Created + la factura creada como BORRADOR (sin numero)
    @PostMapping
    public ResponseEntity<FacturaReporteDTO> crearFactura(@RequestBody FacturaRequestDTO request) {
        FacturaReporteDTO creada = facturaService.crear(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .header(HttpHeaders.LOCATION, "/api/facturas/" + creada.getId())
                .body(creada);
    }

    // PUT /api/facturas/{id}  -> 200 OK (404 si no existe)
    // Borrador: se pueden cambiar cabecera e items. Emitida: solo {"estado": "ANULADA", "observaciones": "..."}
    @PutMapping("/{id:\\d+}")
    public ResponseEntity<FacturaReporteDTO> actualizarFactura(@PathVariable Long id,
                                                               @RequestBody FacturaRequestDTO request) {
        return ResponseEntity.ok(facturaService.actualizar(id, request));
    }

    // POST /api/facturas/{id}/autorizar  -> 200 OK: ARCA asigna numero y CAE (BORRADOR -> EMITIDA)
    @PostMapping("/{id:\\d+}/autorizar")
    public ResponseEntity<FacturaReporteDTO> autorizarFactura(@PathVariable Long id) {
        return ResponseEntity.ok(facturaService.autorizar(id));
    }

    // DELETE /api/facturas/{id}  -> 204 No Content (404 si no existe, 409 si ya tiene numero)
    @DeleteMapping("/{id:\\d+}")
    public ResponseEntity<Void> eliminarFactura(@PathVariable Long id) {
        facturaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
