package com.example.repository;

import com.example.entidades.Cliente;
import com.example.entidades.CondicionIva;
import com.example.entidades.ListaPrecioArticulo;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

// Acceso a las entidades "de soporte" que usa la factura
// (PuntoVenta, CondicionIva, TipoMoneda, Cliente, Usuario, ListaPrecio, ListaPrecioArticulo).
@Repository
public class CatalogoRepository {

    @PersistenceContext
    private EntityManager em;

    public <T> Optional<T> buscarPorId(Class<T> clase, Long id) {
        if (id == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(em.find(clase, id));
    }

    // Entidades activas (sin fecha de baja) ordenadas por id
    public <T> List<T> listarActivos(Class<T> clase) {
        return em.createQuery(
                        "SELECT e FROM " + clase.getSimpleName() + " e WHERE e.fechaBaja IS NULL ORDER BY e.id", clase)
                .getResultList();
    }

    public Optional<CondicionIva> buscarCondicionPorCodigo(int codigoAfip) {
        return em.createQuery("SELECT c FROM CondicionIva c WHERE c.codigoAfip = :codigo ORDER BY c.id", CondicionIva.class)
                .setParameter("codigo", codigoAfip)
                .setMaxResults(1)
                .getResultStream()
                .findFirst();
    }

    public <T> Optional<T> primero(Class<T> clase) {
        return em.createQuery("SELECT e FROM " + clase.getSimpleName() + " e ORDER BY e.id", clase)
                .setMaxResults(1)
                .getResultStream()
                .findFirst();
    }

    // Precio del articulo en la lista elegida (la ListaPrecioArticulo que va en el detalle)
    public Optional<ListaPrecioArticulo> buscarPrecio(Long listaPrecioId, Long articuloId) {
        return em.createQuery(
                        "SELECT lpa FROM ListaPrecioArticulo lpa " +
                                "WHERE lpa.listaPrecio.id = :lista AND lpa.articulo.id = :articulo " +
                                "AND lpa.fechaBaja IS NULL ORDER BY lpa.id", ListaPrecioArticulo.class)
                .setParameter("lista", listaPrecioId)
                .setParameter("articulo", articuloId)
                .setMaxResults(1)
                .getResultStream()
                .findFirst();
    }

    // Explorer de articulos: los de UNA lista de precios, filtrando por codigo, denominacion, rubro o marca
    public List<ListaPrecioArticulo> buscarArticulosDeLista(Long listaPrecioId, String texto, int maximo) {
        return em.createQuery(
                        "SELECT lpa FROM ListaPrecioArticulo lpa JOIN FETCH lpa.articulo a " +
                                "LEFT JOIN FETCH a.rubro r LEFT JOIN FETCH a.marca m " +
                                "WHERE lpa.listaPrecio.id = :lista AND lpa.fechaBaja IS NULL AND a.fechaBaja IS NULL " +
                                "AND (:texto = '' OR LOWER(a.codigo) LIKE :patron ESCAPE '!' OR LOWER(a.denominacion) LIKE :patron ESCAPE '!' " +
                                "OR LOWER(r.denominacion) LIKE :patron ESCAPE '!' OR LOWER(m.denominacion) LIKE :patron ESCAPE '!') " +
                                "ORDER BY a.denominacion", ListaPrecioArticulo.class)
                .setParameter("lista", listaPrecioId)
                .setParameter("texto", texto)
                .setParameter("patron", patron(texto))
                .setMaxResults(maximo)
                .getResultList();
    }

    // Explorer de clientes: filtra por razon social o CUIT (con o sin guiones)
    public List<Cliente> buscarClientes(String texto, int maximo) {
        String digitos = texto.replaceAll("\\D", "");
        return em.createQuery(
                        "SELECT c FROM Cliente c LEFT JOIN FETCH c.domicilio LEFT JOIN FETCH c.contacto " +
                                "LEFT JOIN FETCH c.condicionIva " +
                                "WHERE c.fechaBaja IS NULL AND (:texto = '' OR LOWER(c.denominacion) LIKE :patron ESCAPE '!' " +
                                "OR c.cuitCuil LIKE :patron ESCAPE '!' " +
                                "OR (:digitos <> '' AND REPLACE(c.cuitCuil, '-', '') LIKE :patronDigitos)) " +
                                "ORDER BY c.denominacion", Cliente.class)
                .setParameter("texto", texto)
                .setParameter("patron", patron(texto))
                .setParameter("digitos", digitos)
                .setParameter("patronDigitos", "%" + digitos + "%")
                .setMaxResults(maximo)
                .getResultList();
    }

    // Patron LIKE "contiene": escapa los comodines para que "%" o "_" se busquen como texto literal
    private static String patron(String texto) {
        return "%" + texto.replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%";
    }
}
