# Spring Boot - Trabajo Grupal (CRUD Factura de Venta)

API REST con Spring Boot 4, Spring Data JPA (Hibernate), MySQL y Lombok, más un frontend
en **TypeScript + HTML5** con formato *explorer* (grilla con selección + modales) que la consume.

- **TP anterior:** reporte de facturas como DTO (`FacturaReporteDTO`) con filtros, descarga en PDF y Excel.
- **TP actual (escritura):** DTOs de entrada, alta en cascada, actualización, autorización en ARCA,
  anulación / eliminación (`POST`, `PUT`, `DELETE`), impresión de cada factura en PDF y frontend CRUD.

## Requisitos

- **JDK 17 o superior** (Spring Boot 4 no funciona con Java 8). En IntelliJ: *File > Project Structure > SDK*.
- MySQL / MariaDB en `localhost:3306` (sirve el de XAMPP: *XAMPP Control Panel → MySQL → Start*).
- Node.js **solo si se modifica el TypeScript** (el JS compilado ya está incluido).

## Cómo ejecutar

1. Iniciar MySQL.
2. Credenciales por variables de entorno (la contraseña **no** se escribe en el código):
   - `DB_USER` (por defecto `root`)
   - `DB_PASSWORD` (por defecto vacía, como en XAMPP)
   - `DB_NAME` (por defecto `facturacion_tp`)

   En IntelliJ: *Run > Edit Configurations > Environment variables* → `DB_USER=miusuario;DB_PASSWORD=micontraseña`.
3. Ejecutar `Main` (o `./gradlew bootRun`).
4. Abrir **http://localhost:8080/** → explorador de facturas. La API queda en `http://localhost:8080/api/facturas`.

La base y las tablas se crean solas (`createDatabaseIfNotExist` y `ddl-auto=update`). Al iniciar se crean
(o se corrigen) los datos base que falten:

- 2 puntos de venta (0001 Central y 0002 Godoy Cruz) y 4 condiciones de IVA (Responsable Inscripto,
  Exento, Consumidor Final, Monotributo).
- 15 clientes, **cada uno con su condición frente al IVA** y CUIT con dígito verificador válido.
- 60 artículos de 6 rubros y 19 marcas, y 3 listas de precios: *General* (todos), *Mayorista*
  (15 % menos, sin cervezas ni perfumería) y *Supermercados* (10 % menos, solo almacén, lácteos y limpieza).
- Si la base no tiene comprobantes: 15 de ejemplo calculados con los precios reales de cada lista
  (Facturas A y B emitidas con CAE en los dos puntos de venta, 2 anuladas y 3 borradores, uno de ellos
  rechazado por ARCA).

La carga es idempotente (se puede arrancar las veces que se quiera) y se desactiva con `app.cargar-datos-prueba=false`.
Para empezar de cero con los datos de ejemplo: borrar la base (`DROP DATABASE facturacion_tp;` en phpMyAdmin)
y volver a ejecutar la aplicación. Los datos de la empresa emisora que salen impresos en el
PDF se configuran en `application.properties` (`app.empresa.*`).

## Ciclo de vida de un comprobante

> Un comprobante **solo es una factura cuando ARCA lo autoriza** (tiene CAE). Hasta ese momento es un
> *borrador*: en la grilla, en *Ver* y en el PDF no se lo llama "Factura A/B", no muestra letra ni código
> ARCA y el PDF lleva la marca **"SIN VALIDEZ FISCAL"**. Lo mismo vale para cualquier comprobante sin CAE
> (por ejemplo los cargados por versiones anteriores del TP): se muestra como *"Comprobante sin CAE"*.

```
  POST /api/facturas            POST /api/facturas/{id}/autorizar        PUT {"estado":"ANULADA"}
 ───────────────────► BORRADOR ─────────────────────────────────► EMITIDA ─────────────────────────► ANULADA
                     (sin número,                                (número correlativo                (fechaAnulacion
                      sin CAE)                                    + CAE de ARCA)                     = hoy)
                         │
                         └── DELETE /api/facturas/{id}  (se puede borrar porque no tiene número)
```

| Estado | Editar | Autorizar en ARCA | Anular | Eliminar | Imprimir PDF |
|---|---|---|---|---|---|
| BORRADOR (sin número ni CAE) | ✔ | ✔ | ✘ (se elimina) | ✔ | ✔ (título "BORRADOR", marca "SIN VALIDEZ FISCAL") |
| EMITIDA (con número y CAE) | ✘ | ✘ | ✔ | ✘ (se anula) | ✔ |
| ANULADA | ✘ | ✘ | ✘ | ✘ | ✔ (marca "ANULADA") |

**Regla principal:** una factura **sin número de comprobante** se puede eliminar; si **ya tiene número**
es un comprobante fiscal y solo puede **anularse**. Si se intenta lo contrario la API responde `409 Conflict`.

**Tipo de comprobante:** el emisor es Responsable Inscripto, así que la factura es **A** (código ARCA 01)
si el receptor es Responsable Inscripto y **B** (código 06) en cualquier otro caso. Como en ARCA, la
numeración es correlativa **por punto de venta y por tipo** (las A y las B tienen su propio contador).

**Condición de IVA:** la define el cliente. Sin cliente (Consumidor Final) solo puede ser *Consumidor Final*;
con cliente, es la condición cargada en el cliente (si se manda otra, la API responde `400`). Al cambiar
de cliente la condición se actualiza sola, también en un `PUT`.

Si ARCA rechaza un borrador, se guarda el resultado (`R`) y el motivo, que se ven en *Ver* y en la grilla
("Rechazado por ARCA"). Al editar el borrador el rechazo se limpia y se puede volver a autorizar.

**Concurrencia:** las escrituras bloquean la fila de la factura (`SELECT … FOR UPDATE`) y trabajan en
`READ COMMITTED`; la autorización además bloquea el punto de venta. Así dos autorizaciones simultáneas
nunca toman el mismo número y una factura no se puede autorizar dos veces a la vez.

## Integración con ARCA (ex AFIP)

La autorización se hace en `ArcaService` y tiene dos modos (`app.arca.modo` en `application.properties`
o variable de entorno `ARCA_MODO`):

| Modo | Qué hace | Necesita |
|---|---|---|
| `simulado` (por defecto) | Aplica las validaciones básicas de ARCA y genera un CAE de prueba de 14 dígitos | Nada |
| `homologacion` | Usa los **webservices reales de testing** de ARCA: WSAA + WSFEv1 | Certificado y clave privada del CUIT |

Flujo en modo `homologacion` (siguiendo la *Guía integral de facturación ARCA/AFIP – Homologación*):

1. **WSAA** (`arca/WsaaClient`): arma el TRA (`loginTicketRequest` para el servicio `wsfe`), lo firma en
   **CMS / PKCS#7 con SHA256withRSA** usando BouncyCastle y lo envía a `loginCms`. Recibe el **Token y Sign**.
   El ticket dura 12 h y WSAA no entrega otro mientras siga vigente, por eso se guarda en disco
   (`app.arca.ticket-cache`) y se reutiliza.
2. **WSFEv1** (`arca/WsfeClient`):
   - `FECompUltimoAutorizado` → último número del punto de venta y tipo; se emite el siguiente.
   - `FECAESolicitar` → envía la factura (concepto 1 = productos, DocTipo 80 = CUIT o 99 = Consumidor
     Final, importes neto / IVA 21 % / total, moneda `PES`, condición de IVA del receptor) y recibe el
     **CAE y su vencimiento**, o los errores/observaciones si la rechaza.
   - `FEDummy` → estado de los servidores; se ve en `GET /api/arca/estado` y en el indicador del encabezado.

Los mensajes SOAP se arman a mano con el orden de campos del WSDL oficial (no hace falta `wsimport`).

### Cómo activar el modo homologación

1. **Generar la clave y el pedido de certificado** (Paso 1 de la guía). En **Git Bash** hay que anteponer
   `MSYS_NO_PATHCONV=1`; si no, Git Bash convierte el `/C=AR/...` en una ruta de Windows y `openssl` falla:

   ```bash
   openssl genrsa -out privada_test.key 2048
   ```

   ```bash
   MSYS_NO_PATHCONV=1 openssl req -new -key privada_test.key -subj "/C=AR/O=TEST/serialNumber=CUIT 20111111112/CN=TEST" -out solicitud_test.csr
   ```

   (reemplazar `20111111112` por el CUIT con el que se entra a ARCA).
2. **En la web de ARCA** con Clave Fiscal (Paso 2 de la guía): servicio *WSASS – Autoservicio de Acceso
   a WebServices (homologación)* → crear un alias, pegar el contenido de `solicitud_test.csr` y descargar
   el certificado (`.crt`). Después, en *Administrador de Relaciones*, asociar ese alias al servicio
   **Facturación Electrónica (wsfe)**.
3. **Configurar la aplicación** con variables de entorno (IntelliJ: *Run > Edit Configurations >
   Environment variables*):

   ```
   ARCA_MODO=homologacion;ARCA_CUIT=20111111112;ARCA_CERTIFICADO=C:/ARCA/certificado_test.crt;ARCA_CLAVE_PRIVADA=C:/ARCA/privada_test.key
   ```

4. Iniciar la app: el encabezado muestra *"ARCA homologación · servidores OK"* y el botón
   **Autorizar en ARCA** pide el CAE real de testing.

> La clave privada y el certificado **no se suben al repositorio** (`.gitignore` excluye `*.key`, `*.crt`,
> `*.csr`, `*.pfx`). Para producción se cambian `app.arca.wsaa-url` y `app.arca.wsfe-url` por
> `https://wsaa.afip.gov.ar/ws/services/LoginCms` y `https://servicios1.afip.gov.ar/wsfev1/service.asmx`.

Errores: si ARCA **rechaza** el comprobante → `409` con los códigos y mensajes de ARCA; si **no se puede
comunicar** o falta el certificado → `502 Bad Gateway`. En ambos casos la factura sigue como borrador.

Verificado contra los servidores de homologación: `FEDummy` responde `OK` y WSAA recibe el pedido firmado
(con un certificado autofirmado responde *"Certificado no emitido por AC de confianza"*, que es lo esperado:
el certificado tiene que emitirlo ARCA en el paso 2).

## Endpoints

| Método | URL | Cuerpo | Respuesta |
|---|---|---|---|
| GET | `/api/facturas?filtros` | – | `200` lista de `FacturaReporteDTO` |
| GET | `/api/facturas/{id}` | – | `200` `FacturaCompletaDTO` (cabecera + ítems) o `404` |
| GET | `/api/facturas/{id}/pdf` | – | PDF de la factura (comprobante individual) |
| GET | `/api/facturas/pdf?filtros` / `/excel?filtros` | – | reporte PDF / Excel (.xlsx) con los mismos filtros |
| **POST** | `/api/facturas` | `FacturaRequestDTO` | **`201 Created`** + `FacturaReporteDTO` (BORRADOR) + header `Location` |
| **PUT** | `/api/facturas/{id}` | `FacturaRequestDTO` (parcial) | **`200 OK`** + `FacturaReporteDTO` / `404` / `409` |
| POST | `/api/facturas/{id}/autorizar` | – | `200 OK` con número y CAE / `409` si ARCA la rechaza |
| **DELETE** | `/api/facturas/{id}` | – | **`204 No Content`** / `404` / `409` si tiene número |
| GET | `/api/catalogos` | – | combos chicos: condiciones de IVA, puntos de venta, monedas y listas de precios |
| GET | `/api/clientes?q=` | – | explorer de clientes (busca por razón social o CUIT, con o sin guiones) |
| GET | `/api/listas-precio/{id}/articulos?q=` | – | explorer de artículos **de esa lista**, con su precio (código, descripción, rubro o marca) |
| GET | `/api/arca/estado` | – | modo de ARCA y, en homologación, estado de los servidores (`FEDummy`) |

**Filtros** (todos opcionales, se combinan): `fechaDesde`, `fechaHasta` (`yyyy-MM-dd`), `estado`
(`BORRADOR`, `EMITIDA`, `ANULADA`), `clienteId` (`0` = Consumidor Final), `puntoVentaId`, `numero`,
`montoMinimo`, `montoMaximo`. Ej.: `/api/facturas?estado=EMITIDA&montoMinimo=10000&fechaDesde=2026-04-01`.

Errores (`GlobalExceptionHandler`): `400` datos inválidos (JSON roto, fechas inexistentes como `2026-02-30`,
cantidades fuera de rango, textos de más de 255 caracteres, filtros inválidos…), `404` recurso inexistente,
`405` método no permitido, `409` regla de negocio o rechazo de ARCA, `415` cuerpo que no es JSON y `502` sin
comunicación con ARCA. **Ninguna excepción sale como un 500 sin controlar**: si ocurriera algo inesperado,
se registra en el log y se devuelve el mismo formato de error.
Cuerpo: `{"timestamp": "...", "status": 404, "error": "Not Found", "mensaje": "Factura con id 99 no existe"}`.

### Ejemplo POST

```json
{
  "fechaEmision": "2026-10-20",
  "clienteId": 2,
  "condicionIvaId": 1,
  "puntoVentaId": 1,
  "tipoMonedaId": 1,
  "listaPrecioId": 2,
  "observaciones": "Venta mostrador",
  "detalles": [
    { "articuloId": 1, "cantidad": 2 },
    { "articuloId": 4, "cantidad": 3, "porcentajeBonificacion": 10 }
  ]
}
```

- Las relaciones viajan como **IDs**, nunca como entidades anidadas.
- `clienteId` null, omitido o `0` = Consumidor Final. `fechaEmision` omitida = hoy.
- `condicionIvaId` es opcional: si no viene se toma la del cliente (o Consumidor Final).
- Validaciones: al menos 1 y como máximo 100 renglones, sin artículos repetidos, cantidad entera entre 1 y
  99.999 y bonificación entre 0 y 100 (hasta 2 decimales), observaciones de hasta 255 caracteres y fecha
  entre 2000 y 2099.
- **Primero se determina la lista de precios** (`listaPrecioId`) y los artículos se eligen de esa lista.
  Por cada ítem se busca la `ListaPrecioArticulo` (artículo + lista elegida), que es lo que guarda el
  detalle; si el artículo no está en esa lista responde `404`. Con ese precio se calcula:
  `neto = cantidad × precio − bonificación`, `IVA = neto × 21 %`, `subtotal = neto + IVA`;
  `importeTotal` = suma de subtotales. Los detalles se guardan **en cascada** (`CascadeType.ALL`).

### PUT (actualización parcial)

Solo se modifica lo que viene distinto de `null`:

```json
{ "clienteId": 1, "detalles": [ { "articuloId": 3, "cantidad": 5 } ] }   // borrador: cabecera + ítems
{ "estado": "ANULADA", "observaciones": "Error de carga" }               // emitida: anulación lógica
```

- Si vienen `detalles`, reemplazan a los anteriores (`orphanRemoval`) y se recalculan los importes.
- `clienteId: 0` pasa la factura a Consumidor Final.
- `{"listaPrecioId": 1}` sin `detalles` vuelve a cotizar los mismos artículos con la otra lista.
- Anular pone `estado = "ANULADA"` y `fechaAnulacion = new Date()`. El motivo se **agrega** a las
  observaciones que ya tenía el comprobante ("… | Motivo de anulación: …"), no las reemplaza.

## Frontend (explorer en TypeScript + HTML5)

- **Filtros** arriba de la grilla (el cliente se elige con el explorer de clientes).
- **Explorers de selección** para **Cliente** y **Artículo** (no son combos): un modal con buscador y
  grilla que busca en el servidor mientras se escribe; flechas ↑/↓, Enter o doble clic para elegir.
  El de clientes trae primero la opción *Consumidor Final* y muestra la condición de IVA de cada cliente.
  El de artículos muestra **solo los de la lista de precios elegida** con su precio.
- **Cambio de lista de precios sin perder nada:** los ítems ya cargados **no se quitan ni se recalculan
  solos**. Los que no están en la lista nueva se marcan en rojo ("No está en LP-02") y los que tienen otro
  precio, en amarillo. El usuario decide: los quita a mano, vuelve a la lista anterior (y todo queda como
  estaba) o toca *Recalcular con LP-xx*. No se puede guardar hasta resolverlo.
- **Condición de IVA automática:** se toma del cliente elegido (o Consumidor Final) y el formulario indica
  si al autorizarse será Factura A o B.
- **Protecciones:** Enter dentro del formulario no guarda (en cantidad/bonificación agrega el ítem); cerrar
  con cambios sin guardar pide confirmación; no se puede cargar dos veces el mismo artículo; los botones
  no envían dos veces la misma operación; una cantidad o bonificación inválida en la tabla de ítems
  queda marcada en rojo y no deja guardar hasta corregirla.
- **Barra de acciones** que se habilita según el comprobante seleccionado: *Nuevo borrador, Ver, Editar,
  Autorizar en ARCA, Imprimir PDF, Anular, Eliminar*, más *Reporte PDF* y *Exportar Excel*.
- **Grilla** con selección por clic; doble clic o Enter abre la factura; flechas ↑/↓ mueven la
  selección; Supr elimina un borrador. Orden: más recientes primero y, en el mismo día, borradores arriba
  y después por punto de venta y número. La barra de acciones queda fija al bajar por la grilla.
- Si otra pestaña elimina o autoriza el comprobante seleccionado, la grilla se actualiza sola al intentar
  operar sobre él. Antes de autorizar un borrador con fecha fuera de los ±5 días que acepta ARCA, se avisa.
- **Modal de alta / edición** (oculto hasta tocar *Nuevo borrador* o *Editar*): cabecera, lista de precios,
  tabla dinámica de ítems y vista previa de neto, IVA y total.
- **Modal Ver** con tipo de comprobante (A/B), cabecera, ítems, totales, CAE y motivo del último rechazo de ARCA.
- **Indicador de ARCA** en el encabezado (modo simulado u homologación y estado de los servidores).

```
frontend/
├── package.json / tsconfig.json    (tsc compila a src/main/resources/static/js)
└── src/
    ├── models/factura.dto.ts       interfaces espejo de los DTOs Java
    ├── services/FacturaService.ts  obtenerFacturas, crearFactura, actualizarEstado, eliminarFactura
    │                               (+ obtenerFactura, actualizarFactura, autorizarFactura, URLs de PDF)
    ├── services/CatalogoService.ts combos y búsquedas de los explorers (clientes / artículos de una lista)
    ├── services/ArcaService.ts     estado de ARCA para el indicador del encabezado
    ├── services/ApiError.ts        manejo de errores HTTP
    └── app.ts                      explorer: DOM, selección, modales, ítems en memoria y eventos
src/main/resources/static/
├── index.html                      filtros · barra de acciones · grilla · modales
├── css/styles.css
└── js/                             JS compilado (no editar a mano)
```

Para recompilar después de cambiar el TypeScript:

```bash
cd frontend
npm install
npm run build      # o "npm run watch" mientras se desarrolla
```

## Tests

```bash
./gradlew test
```

Sin base de datos ni conexión a ARCA (Mockito y datos de ejemplo):

- `ReporteServiceTest` (2): el total facturado solo suma facturas emitidas con CAE (no anuladas ni borradores)
  y un comprobante solo se llama "factura" si tiene CAE.
- `FacturaServiceTest` (36): cálculo de neto/IVA/total, precio según la lista elegida, artículo que no está
  en la lista, recotizar al cambiar de lista, alta como borrador, autorización (numeración A/B, bloqueo del
  punto de venta), rechazo de ARCA registrado, CUIT inválido, eliminar solo sin número, anular solo
  emitidas, condición de IVA coherente con el cliente y todas las validaciones de datos y filtros.
- `ArcaServiceTest` (5): flujo de homologación (último número + 1, Factura A con CUIT, Factura B a
  Consumidor Final, rechazo con los mensajes de ARCA) y dígito verificador del CUIT.
- `WsaaClientTest`: TRA, firma CMS verificada con un certificado autofirmado, lectura del ticket y de
  claves PKCS#8 y PKCS#1.
- `WsfeClientTest`: XML de `FECAESolicitar` en el orden del WSDL y lectura de respuestas aprobadas,
  rechazadas, de `FECompUltimoAutorizado` y `FEDummy`.

## Estructura del backend

```
src/main/java/com/example
├── controller   FacturaRestController   (GET, POST, PUT, DELETE, autorizar, PDF)
│                CatalogoRestController  (GET /api/catalogos, explorers de clientes y de artículos por lista)
│                ArcaRestController      (GET /api/arca/estado)
├── arca         WsaaClient              (Token y Sign: TRA firmado en CMS con BouncyCastle)
│                WsfeClient              (FEDummy, FECompUltimoAutorizado, FECAESolicitar)
│                TipoComprobante, ArcaConfig, ArcaException, Soap
├── service      FacturaService          (@Transactional: crear, actualizar, autorizar, eliminar, búsquedas)
│                ArcaService             (autorización en ARCA: modo simulado u homologación)
│                ReporteService          (reporte PDF/Excel .xlsx y PDF de cada factura)
│                CatalogoService
├── repository   FacturaVentaRepository  (JPQL dinámica + persist/merge/remove)
│                CatalogoRepository      (búsqueda por ID de entidades asociadas)
├── dto          FacturaRequestDTO, FacturaDetalleRequestDTO, FacturaReporteDTO, FacturaCompletaDTO,
│                FacturaItemDTO, FacturaFiltrosDTO, CatalogoDTO, ItemCatalogoDTO, ArcaEstadoDTO,
│                ClienteExplorerDTO, ArticuloPrecioDTO
├── exception    RecursoNoEncontradoException (404), ReglaNegocioException (409), GlobalExceptionHandler
├── config       CargaDatosInicial (datos de prueba), CorsConfig
└── entidades    (entidades JPA con Lombok)
```

Flujo: `Controller -> Service -> Repository -> Base de datos`.
