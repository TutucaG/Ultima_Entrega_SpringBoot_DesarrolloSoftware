-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: facturacion_tp
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articulo`
--

DROP TABLE IF EXISTS `articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `codigo` varchar(255) NOT NULL,
  `denominacion` varchar(255) NOT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  `marca_id` bigint(20) DEFAULT NULL,
  `rubro_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKk9sgx2vvfn1t1t0lnewqtnwo9` (`usuarioBaja_id`),
  KEY `FK94yajrpoe455saug0pw2kkclw` (`usuarioCarga_id`),
  KEY `FKkmase16lcdwaoxjgh5plp3gxd` (`usuarioModificacion_id`),
  KEY `FKkc7g1efsj3815e1bgrsyl1p6w` (`marca_id`),
  KEY `FKs90nu8meysg24ocgu0t9aod0i` (`rubro_id`),
  CONSTRAINT `FK94yajrpoe455saug0pw2kkclw` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKk9sgx2vvfn1t1t0lnewqtnwo9` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKkc7g1efsj3815e1bgrsyl1p6w` FOREIGN KEY (`marca_id`) REFERENCES `marca` (`id`),
  CONSTRAINT `FKkmase16lcdwaoxjgh5plp3gxd` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKs90nu8meysg24ocgu0t9aod0i` FOREIGN KEY (`rubro_id`) REFERENCES `rubro` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulo`
--

LOCK TABLES `articulo` WRITE;
/*!40000 ALTER TABLE `articulo` DISABLE KEYS */;
INSERT INTO `articulo` VALUES (1,'2026-10-21 00:43:33.000000',NULL,'2026-10-21 00:43:33.000000','ART-001','Gaseosa 500ml',NULL,1,1,1,1),(2,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000','ART-002','Agua mineral 1.5L',NULL,1,1,1,1),(3,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000','ART-003','Jugo de naranja 1L',NULL,1,1,1,1),(4,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000','ART-004','Cerveza lata 473ml',NULL,1,1,1,1),(5,'2026-11-18 19:21:00.000000',NULL,'2026-11-18 19:21:00.000000','ART-005','Gaseosa 2.25L',NULL,1,1,1,1),(6,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000','ART-006','Agua saborizada 1.5L',NULL,1,1,1,1),(7,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000','ART-007','Bebida isotónica 500ml',NULL,1,1,1,1),(8,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000','ART-008','Soda sifón 2L',NULL,1,1,1,1);
/*!40000 ALTER TABLE `articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `cuitCuil` varchar(255) NOT NULL,
  `denominacion` varchar(255) NOT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  `contacto_id` bigint(20) NOT NULL,
  `domicilio_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKqlkmu8wduq25uw6qfpudrmtlh` (`contacto_id`),
  UNIQUE KEY `UK7ob9xg3niaibhhmj5iw311ygb` (`domicilio_id`),
  KEY `FKq2636gk7qk2da6qh6ihki0qrm` (`usuarioBaja_id`),
  KEY `FKiihlotx8hxh3dxsbvdk3h8s04` (`usuarioCarga_id`),
  KEY `FK2nmjxhnjj16ipnb3aed4m1jr3` (`usuarioModificacion_id`),
  CONSTRAINT `FK2nmjxhnjj16ipnb3aed4m1jr3` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKfhaklodto1bt1o9ntt390cw0h` FOREIGN KEY (`contacto_id`) REFERENCES `contacto` (`id`),
  CONSTRAINT `FKhnfwgi8xk38mge49a8twpxtxv` FOREIGN KEY (`domicilio_id`) REFERENCES `domicilio` (`id`),
  CONSTRAINT `FKiihlotx8hxh3dxsbvdk3h8s04` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKq2636gk7qk2da6qh6ihki0qrm` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'2026-10-21 00:43:33.000000',NULL,'2026-10-21 00:43:33.000000','30-12345678-9','Empresa Tech S.A.',NULL,1,1,1,1),(2,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000','20-30111222-3','Comercial Andina S.R.L.',NULL,1,1,2,2),(3,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000','30-70984512-4','Supermercado El Sol S.A.',NULL,1,1,3,3),(4,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000','20-28456123-7','Pérez Juan Carlos',NULL,1,1,4,4),(5,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000','27-33214567-2','Gómez María Laura',NULL,1,1,5,5),(6,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000','30-71566890-1','Distribuidora Cuyo S.R.L.',NULL,1,1,6,6);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `condicion_iva`
--

DROP TABLE IF EXISTS `condicion_iva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `condicion_iva` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `codigoAfip` int(11) NOT NULL,
  `denominacion` varchar(255) NOT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKioscgh4fr9gqaqys74vnj1954` (`usuarioBaja_id`),
  KEY `FKmcjnh05qaa4t39i8lwti3lofb` (`usuarioCarga_id`),
  KEY `FKqu5qwgvkvs4hexggeoc52f2em` (`usuarioModificacion_id`),
  CONSTRAINT `FKioscgh4fr9gqaqys74vnj1954` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKmcjnh05qaa4t39i8lwti3lofb` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKqu5qwgvkvs4hexggeoc52f2em` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `condicion_iva`
--

LOCK TABLES `condicion_iva` WRITE;
/*!40000 ALTER TABLE `condicion_iva` DISABLE KEYS */;
INSERT INTO `condicion_iva` VALUES (1,'2026-10-21 00:43:33.000000',NULL,'2026-10-21 00:43:33.000000',1,'IVA Responsable Inscripto',NULL,1,1),(2,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',5,'Consumidor Final',NULL,1,1),(3,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',6,'Responsable Monotributo',NULL,1,1);
/*!40000 ALTER TABLE `condicion_iva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacto`
--

DROP TABLE IF EXISTS `contacto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacto` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `celular` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacto`
--

LOCK TABLES `contacto` WRITE;
/*!40000 ALTER TABLE `contacto` DISABLE KEYS */;
INSERT INTO `contacto` VALUES (1,'261-5000000','contacto@empresatech.com','0261-4000000'),(2,NULL,NULL,NULL),(3,NULL,NULL,NULL),(4,NULL,NULL,NULL),(5,NULL,NULL,NULL),(6,NULL,NULL,NULL);
/*!40000 ALTER TABLE `contacto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domicilio`
--

DROP TABLE IF EXISTS `domicilio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `domicilio` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombreCalle` varchar(255) DEFAULT NULL,
  `numeroCalle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domicilio`
--

LOCK TABLES `domicilio` WRITE;
/*!40000 ALTER TABLE `domicilio` DISABLE KEYS */;
INSERT INTO `domicilio` VALUES (1,'Belgrano','250'),(2,'Mitre','845'),(3,'Las Heras','1220'),(4,'San Juan','377'),(5,'Rivadavia','56'),(6,'Ruta 40 km','12');
/*!40000 ALTER TABLE `domicilio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_venta`
--

DROP TABLE IF EXISTS `factura_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_venta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `cae` varchar(255) DEFAULT NULL,
  `caeFechaVencimiento` date DEFAULT NULL,
  `estado` varchar(255) NOT NULL,
  `fechaAnulacion` date DEFAULT NULL,
  `fechaEmision` date NOT NULL,
  `importeCobrado` double DEFAULT NULL,
  `importeSaldo` double DEFAULT NULL,
  `importeTotal` double NOT NULL,
  `motivoRechazo` varchar(255) DEFAULT NULL,
  `numero` bigint(20) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `resultadoAfip` varchar(255) DEFAULT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  `cliente_id` bigint(20) DEFAULT NULL,
  `condicion_iva_id` bigint(20) NOT NULL,
  `punto_venta_id` bigint(20) NOT NULL,
  `tipo_moneda_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK50t3kmca0k24xlg6jagyqnw4q` (`usuarioBaja_id`),
  KEY `FK9cvt5cj0ok2j4abbxmv24vnsy` (`usuarioCarga_id`),
  KEY `FKc0vnl29c931h12p9mc79pik8n` (`usuarioModificacion_id`),
  KEY `FKhwuwudrv0r4sflktrji97ay8m` (`cliente_id`),
  KEY `FKfndl9uvnt5mh09ewi573mnybn` (`condicion_iva_id`),
  KEY `FKb6wyq1b7gxxh5p9qbahgww9q5` (`punto_venta_id`),
  KEY `FKltw3g1f6nmspv3l8inng4rv3y` (`tipo_moneda_id`),
  CONSTRAINT `FK50t3kmca0k24xlg6jagyqnw4q` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK9cvt5cj0ok2j4abbxmv24vnsy` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKb6wyq1b7gxxh5p9qbahgww9q5` FOREIGN KEY (`punto_venta_id`) REFERENCES `punto_venta` (`id`),
  CONSTRAINT `FKc0vnl29c931h12p9mc79pik8n` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKfndl9uvnt5mh09ewi573mnybn` FOREIGN KEY (`condicion_iva_id`) REFERENCES `condicion_iva` (`id`),
  CONSTRAINT `FKhwuwudrv0r4sflktrji97ay8m` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`),
  CONSTRAINT `FKltw3g1f6nmspv3l8inng4rv3y` FOREIGN KEY (`tipo_moneda_id`) REFERENCES `tipo_moneda` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_venta`
--

LOCK TABLES `factura_venta` WRITE;
/*!40000 ALTER TABLE `factura_venta` DISABLE KEYS */;
INSERT INTO `factura_venta` VALUES (1,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',NULL,NULL,'EMITIDA',NULL,'2026-03-15',0,1500,1500,NULL,1001,NULL,NULL,NULL,1,1,NULL,1,1,1),(2,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',NULL,NULL,'EMITIDA',NULL,'2026-03-20',0,85000.5,85000.5,NULL,1002,NULL,NULL,NULL,1,1,1,1,1,1),(3,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',NULL,NULL,'EMITIDA',NULL,'2026-04-02',0,12500,12500,NULL,1003,NULL,NULL,NULL,1,1,1,1,1,1),(4,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',NULL,NULL,'ANULADA','2026-04-10','2026-04-10',0,4300,4300,NULL,1004,NULL,NULL,NULL,1,1,NULL,1,1,1),(5,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',NULL,NULL,'EMITIDA',NULL,'2026-05-05',0,52000,52000,NULL,1005,NULL,NULL,NULL,1,1,1,1,1,1),(7,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',NULL,NULL,'ANULADA','2026-06-01','2026-06-01',0,23000,23000,NULL,1007,NULL,NULL,NULL,1,1,1,1,1,1),(8,'2026-10-21 19:37:40.000000',NULL,'2026-10-21 19:37:40.000000',NULL,NULL,'EMITIDA',NULL,'2026-10-21',0,1502.82,1502.82,NULL,1008,NULL,NULL,NULL,1,1,NULL,1,1,1),(9,'2026-10-21 19:39:54.000000',NULL,'2026-10-21 19:39:54.000000',NULL,NULL,'EMITIDA',NULL,'2026-10-21',0,1132.56,1132.56,NULL,1009,NULL,NULL,NULL,1,1,NULL,1,1,1),(10,'2026-11-18 19:22:03.000000',NULL,'2026-11-18 21:38:36.000000','78531921458053','2026-11-28','EMITIDA',NULL,'2026-11-18',0,1943.87,1943.87,NULL,2,NULL,'A',NULL,1,1,6,2,1,1),(11,'2026-11-18 21:30:15.000000',NULL,'2026-11-18 21:38:23.000000','73066420138063','2026-11-28','EMITIDA',NULL,'2026-11-18',0,18029,18029,NULL,1,NULL,'A',NULL,1,1,NULL,2,1,1);
/*!40000 ALTER TABLE `factura_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_venta_detalle`
--

DROP TABLE IF EXISTS `factura_venta_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_venta_detalle` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cantidad` double NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `importeIva` double NOT NULL,
  `importeNeto` double NOT NULL,
  `importeSubtotal` double NOT NULL,
  `porcentajeBonificacion` double NOT NULL,
  `precioUnitario` double NOT NULL,
  `factura_id` bigint(20) NOT NULL,
  `listaPrecioArticulo_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKq8ub7hx33xfj7yfaj4059npba` (`factura_id`),
  KEY `FK25795r2i5u03d052n5dwjj0g1` (`listaPrecioArticulo_id`),
  CONSTRAINT `FK25795r2i5u03d052n5dwjj0g1` FOREIGN KEY (`listaPrecioArticulo_id`) REFERENCES `lista_precio_articulo` (`id`),
  CONSTRAINT `FKq8ub7hx33xfj7yfaj4059npba` FOREIGN KEY (`factura_id`) REFERENCES `factura_venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_venta_detalle`
--

LOCK TABLES `factura_venta_detalle` WRITE;
/*!40000 ALTER TABLE `factura_venta_detalle` DISABLE KEYS */;
INSERT INTO `factura_venta_detalle` VALUES (1,1,'Gaseosa 500ml',130.17,619.83,750,0,619.83,1,1),(2,1,'Gaseosa 500ml',130.17,619.83,750,0,619.83,1,1),(3,1,'Gaseosa 500ml',2950.43,14049.67,17000.1,0,14049.67,2,1),(4,1,'Gaseosa 500ml',2950.43,14049.67,17000.1,0,14049.67,2,1),(5,1,'Gaseosa 500ml',2950.43,14049.67,17000.1,0,14049.67,2,1),(6,1,'Gaseosa 500ml',2950.43,14049.67,17000.1,0,14049.67,2,1),(7,1,'Gaseosa 500ml',2950.43,14049.67,17000.1,0,14049.67,2,1),(8,1,'Gaseosa 500ml',723.14,3443.53,4166.666666666667,0,3443.53,3,1),(9,1,'Gaseosa 500ml',723.14,3443.53,4166.666666666667,0,3443.53,3,1),(10,1,'Gaseosa 500ml',723.14,3443.53,4166.666666666667,0,3443.53,3,1),(11,1,'Gaseosa 500ml',746.28,3553.72,4300,0,3553.72,4,1),(12,1,'Gaseosa 500ml',4512.4,21487.6,26000,0,21487.6,5,1),(13,1,'Gaseosa 500ml',4512.4,21487.6,26000,0,21487.6,5,1),(15,1,'Gaseosa 500ml',1995.87,9504.13,11500,0,9504.13,7,1),(16,1,'Gaseosa 500ml',1995.87,9504.13,11500,0,9504.13,7,1),(17,1,'Cerveza lata 473ml',260.82,1242,1502.82,8,1350,8,4),(18,2,'Agua mineral 1.5L',196.56,936,1132.56,10,520,9,2),(19,1,'Gaseosa 2.25L',337.37,1606.5,1943.87,0,1606.5,10,12),(24,1,'Cerveza lata 473ml',283.5,1350,1633.5,0,1350,11,4),(25,10,'Jugo de naranja 1L',2058,9800,11858,0,980,11,3),(26,5,'Gaseosa 500ml',787.5,3750,4537.5,0,750,11,1);
/*!40000 ALTER TABLE `factura_venta_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lista_precio`
--

DROP TABLE IF EXISTS `lista_precio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lista_precio` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `codigo` varchar(255) NOT NULL,
  `denominacion` varchar(255) NOT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK26je6qljvk5ujl3g5s3wpuohc` (`usuarioBaja_id`),
  KEY `FKdbsm8096wwu1i9l1mytgv8o74` (`usuarioCarga_id`),
  KEY `FKbip872q0t3f0fnswfe2cwixdr` (`usuarioModificacion_id`),
  CONSTRAINT `FK26je6qljvk5ujl3g5s3wpuohc` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKbip872q0t3f0fnswfe2cwixdr` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKdbsm8096wwu1i9l1mytgv8o74` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lista_precio`
--

LOCK TABLES `lista_precio` WRITE;
/*!40000 ALTER TABLE `lista_precio` DISABLE KEYS */;
INSERT INTO `lista_precio` VALUES (1,'2026-10-21 00:43:33.000000',NULL,'2026-10-21 00:43:33.000000','LP-01','Lista General',NULL,1,1),(2,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000','LP-02','Lista Mayorista',NULL,1,1);
/*!40000 ALTER TABLE `lista_precio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lista_precio_articulo`
--

DROP TABLE IF EXISTS `lista_precio_articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lista_precio_articulo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `precioVenta` double NOT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  `articulo_id` bigint(20) NOT NULL,
  `listaPrecio_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5uimr4r82x3pund17im22ybtf` (`usuarioBaja_id`),
  KEY `FKq0m2kv9basp8n747p931d9u07` (`usuarioCarga_id`),
  KEY `FK3p0k5kjwkys7nskqfeq8kyrbw` (`usuarioModificacion_id`),
  KEY `FKnijaepxpdp4tsqsiofhnhbxor` (`articulo_id`),
  KEY `FKh0clsqk2mxo38a9xdvon5v1m4` (`listaPrecio_id`),
  CONSTRAINT `FK3p0k5kjwkys7nskqfeq8kyrbw` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK5uimr4r82x3pund17im22ybtf` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKh0clsqk2mxo38a9xdvon5v1m4` FOREIGN KEY (`listaPrecio_id`) REFERENCES `lista_precio` (`id`),
  CONSTRAINT `FKnijaepxpdp4tsqsiofhnhbxor` FOREIGN KEY (`articulo_id`) REFERENCES `articulo` (`id`),
  CONSTRAINT `FKq0m2kv9basp8n747p931d9u07` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lista_precio_articulo`
--

LOCK TABLES `lista_precio_articulo` WRITE;
/*!40000 ALTER TABLE `lista_precio_articulo` DISABLE KEYS */;
INSERT INTO `lista_precio_articulo` VALUES (1,'2026-10-21 00:43:33.000000',NULL,'2026-10-21 00:43:33.000000',750,NULL,1,1,1,1),(2,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',520,NULL,1,1,2,1),(3,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',980,NULL,1,1,3,1),(4,'2026-10-21 00:43:34.000000',NULL,'2026-10-21 00:43:34.000000',1350,NULL,1,1,4,1),(5,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',1890,NULL,1,1,5,1),(6,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',870,NULL,1,1,6,1),(7,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',1150,NULL,1,1,7,1),(8,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',640,NULL,1,1,8,1),(9,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',637.5,NULL,1,1,1,2),(10,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',442,NULL,1,1,2,2),(11,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',833,NULL,1,1,3,2),(12,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',1606.5,NULL,1,1,5,2),(13,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',739.5,NULL,1,1,6,2),(14,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',977.5,NULL,1,1,7,2),(15,'2026-11-18 19:21:01.000000',NULL,'2026-11-18 19:21:01.000000',544,NULL,1,1,8,2);
/*!40000 ALTER TABLE `lista_precio_articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marca`
--

DROP TABLE IF EXISTS `marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marca` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `codigo` int(11) NOT NULL,
  `denominacion` varchar(255) NOT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkylonjuf8vuql4oc29qedsmw9` (`usuarioBaja_id`),
  KEY `FKhpo884rbx0w98o7w5y4h9kwmf` (`usuarioCarga_id`),
  KEY `FKmo6xpfhuusfj1i0etnrx3l7pn` (`usuarioModificacion_id`),
  CONSTRAINT `FKhpo884rbx0w98o7w5y4h9kwmf` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKkylonjuf8vuql4oc29qedsmw9` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKmo6xpfhuusfj1i0etnrx3l7pn` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marca`
--

LOCK TABLES `marca` WRITE;
/*!40000 ALTER TABLE `marca` DISABLE KEYS */;
INSERT INTO `marca` VALUES (1,'2026-10-21 00:43:33.000000',NULL,'2026-10-21 00:43:33.000000',1,'Coca-Cola',NULL,1,1);
/*!40000 ALTER TABLE `marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `punto_venta`
--

DROP TABLE IF EXISTS `punto_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `punto_venta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `domicilioComercial` varchar(255) DEFAULT NULL,
  `numero` int(11) NOT NULL,
  `tipoEmision` varchar(255) DEFAULT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmmbqfi0yk5g6nx50g7gnuujmm` (`usuarioBaja_id`),
  KEY `FK9beqt9g3ukwxl79ibwhy9roc3` (`usuarioCarga_id`),
  KEY `FKsnyej7116mfberb1jcfxaktu3` (`usuarioModificacion_id`),
  CONSTRAINT `FK9beqt9g3ukwxl79ibwhy9roc3` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKmmbqfi0yk5g6nx50g7gnuujmm` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKsnyej7116mfberb1jcfxaktu3` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `punto_venta`
--

LOCK TABLES `punto_venta` WRITE;
/*!40000 ALTER TABLE `punto_venta` DISABLE KEYS */;
INSERT INTO `punto_venta` VALUES (1,'2026-10-21 00:43:33.000000',NULL,'2026-10-21 00:43:33.000000','Sucursal Central','Av. San Martin 100',1,'CAE',NULL,1,1);
/*!40000 ALTER TABLE `punto_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rubro`
--

DROP TABLE IF EXISTS `rubro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rubro` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `codigo` int(11) NOT NULL,
  `denominacion` varchar(255) NOT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqrtikr1hovnnfj6vm31fytmog` (`usuarioBaja_id`),
  KEY `FK31pb7wcxrtm2xa08ckmgj3f9w` (`usuarioCarga_id`),
  KEY `FK1gu719j5ek0vbboxp08bkw2q3` (`usuarioModificacion_id`),
  CONSTRAINT `FK1gu719j5ek0vbboxp08bkw2q3` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK31pb7wcxrtm2xa08ckmgj3f9w` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKqrtikr1hovnnfj6vm31fytmog` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rubro`
--

LOCK TABLES `rubro` WRITE;
/*!40000 ALTER TABLE `rubro` DISABLE KEYS */;
INSERT INTO `rubro` VALUES (1,'2026-10-21 00:43:33.000000',NULL,'2026-10-21 00:43:33.000000',1,'Bebidas',NULL,1,1);
/*!40000 ALTER TABLE `rubro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_moneda`
--

DROP TABLE IF EXISTS `tipo_moneda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_moneda` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fechaAlta` datetime(6) NOT NULL,
  `fechaBaja` datetime(6) DEFAULT NULL,
  `fechaModificacion` datetime(6) NOT NULL,
  `codigoAfip` varchar(255) NOT NULL,
  `denominacion` varchar(255) NOT NULL,
  `simbolo` varchar(255) NOT NULL,
  `usuarioBaja_id` bigint(20) DEFAULT NULL,
  `usuarioCarga_id` bigint(20) NOT NULL,
  `usuarioModificacion_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqndx1v0l2sb06w3he8ev84k13` (`usuarioBaja_id`),
  KEY `FKpds3ptgvop1467e6rhauhugxx` (`usuarioCarga_id`),
  KEY `FKobut9sb4oqyep56glci119u08` (`usuarioModificacion_id`),
  CONSTRAINT `FKobut9sb4oqyep56glci119u08` FOREIGN KEY (`usuarioModificacion_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKpds3ptgvop1467e6rhauhugxx` FOREIGN KEY (`usuarioCarga_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FKqndx1v0l2sb06w3he8ev84k13` FOREIGN KEY (`usuarioBaja_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_moneda`
--

LOCK TABLES `tipo_moneda` WRITE;
/*!40000 ALTER TABLE `tipo_moneda` DISABLE KEYS */;
INSERT INTO `tipo_moneda` VALUES (1,'2026-10-21 00:43:33.000000',NULL,'2026-10-21 00:43:33.000000','PES','Pesos Argentinos','$',NULL,1,1);
/*!40000 ALTER TABLE `tipo_moneda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `apellido` varchar(255) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Sistema','admin','Administrador','admin');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-19 23:50:46
